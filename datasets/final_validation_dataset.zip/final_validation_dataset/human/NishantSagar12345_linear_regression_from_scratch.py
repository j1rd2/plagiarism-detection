import pandas as pd
import matplotlib.pyplot as plt
data=pd.read_csv('studytime_scores.csv')
def gradient_descent(m_now,b_now,points,L):
    m_gradient=0
    b_gradient=0
    n=len(points)
    for i in range(n):
        x=points.iloc[i].studytime
        y=points.iloc[i].score
        m_gradient+=-(2/n)*x*(y-(m_now*x+b_now))
        b_gradient+=-(2/n)*(y-(m_now*x+b_now))
    m=m_now-m_gradient*L
    b=b_now-b_gradient*L
    return m,b
m=0
b=0
L=0.0001
epochs=700
#plt.scatter(data.studytime,data.score,color="black")
pred_score=[]
for i in range(epochs):
    m,b=gradient_descent(m,b,data,L)
    if i%100==0:
        print(f'Iterations:{i}')
    for i in range(len(data)):
        pred_score.append(m*data.studytime[i]+b)
    plt.scatter(data.studytime,data.score,color="black")
    plt.plot(data.studytime, pred_score, color='red', linewidth=2, label=f'Y={m}X+{b}')
    pred_score.clear()
    plt.ylabel('Y')
    plt.xlabel('X')
    plt.title("Regression Model from Scratch")
    plt.legend()
    plt.pause(0.001)
    plt.clf()
print(f'Line of best fit: Y={m}X+{b}')

