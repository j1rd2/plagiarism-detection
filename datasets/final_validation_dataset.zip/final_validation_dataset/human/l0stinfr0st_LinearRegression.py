import numpy as np
import math, copy

# Optional plot colors (in case you want to use them elsewhere)
dlc = dict(dlblue='#0096ff', dlorange='#FF9300', dldarkred='#C00000', dlmagenta='#FF40FF', dlpurple='#7030A0')

# Numpy print settings
np.set_printoptions(precision=2)

def zscore_normalize_features(x):
    """
    Applies z-score normalization to the features.
    
    Args:
        x (ndarray): shape (m, n) input data
    Returns:
        x_norm (ndarray): normalized features
        mu (ndarray): feature means
        sigma (ndarray): feature standard deviations
    """
    mu = np.mean(x, axis=0)
    sigma = np.std(x, axis=0)
    x_norm = (x - mu) / sigma
    return x_norm, mu, sigma

def compute_model_prediction(x, w, b):
    """
    Computes the linear model predictions.
    
    Args:
        x (ndarray): input features, shape (m, n) or (n,)
        w (ndarray): model parameters, shape (n,)
        b (scalar): bias term
        
    Returns:
        predictions (ndarray or float): predicted values
    """
    return np.dot(x, w) + b

def compute_cost(x, y, w, b):
    """
    Computes the cost function (Mean Squared Error).
    
    Args:
        x (ndarray): input features, shape (m, n)
        y (ndarray): target values, shape (m,)
        w (ndarray): model parameters, shape (n,)
        b (scalar): bias term
        
    Returns:
        cost (float): computed cost
    """
    m = x.shape[0]
    f_wb = compute_model_prediction(x, w, b)
    cost = (1 / (2 * m)) * np.sum((f_wb - y) ** 2)
    return cost

def compute_gradient(x, y, w, b):
    """
    Computes the gradient of the cost function w.r.t. w and b.
    
    Args:
        x (ndarray): input features, shape (m, n)
        y (ndarray): target values, shape (m,)
        w (ndarray): model parameters, shape (n,)
        b (scalar): bias term
        
    Returns:
        dj_dw (ndarray): gradient w.r.t. w, shape (n,)
        dj_db (scalar): gradient w.r.t. b
    """
    m = x.shape[0]
    f_wb = compute_model_prediction(x, w, b)
    error = f_wb - y
    dj_dw = (1 / m) * np.dot(x.T, error)
    dj_db = (1 / m) * np.sum(error)
    return dj_dw, dj_db

def gradient_descent(x, y, w_in, b_in, alpha, num_iters, cost_function, gradient_function):
    """
    Performs batch gradient descent to optimize w and b.
    
    Args:
        x (ndarray): input features, shape (m, n)
        y (ndarray): target values, shape (m,)
        w_in (ndarray): initial weights, shape (n,)
        b_in (scalar): initial bias
        alpha (float): learning rate
        num_iters (int): number of iterations
        cost_function (function): function to compute cost
        gradient_function (function): function to compute gradient
        
    Returns:
        w (ndarray): optimized weights
        b (scalar): optimized bias
        J_history (list): history of cost values over iterations
    """
    J_history = []
    w = copy.deepcopy(w_in)
    b = b_in

    for i in range(num_iters):
        dj_dw, dj_db = gradient_function(x, y, w, b)

        w -= alpha * dj_dw
        b -= alpha * dj_db

        if i < 100000:  # prevent memory issues
            J_history.append(cost_function(x, y, w, b))
        
    return w, b, J_history
