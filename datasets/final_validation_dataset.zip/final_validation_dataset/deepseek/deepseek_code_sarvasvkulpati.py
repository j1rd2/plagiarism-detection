from sklearn.datasets import make_regression
import matplotlib.pyplot as plt
import numpy as np

X, y = make_regression(n_samples=100, n_features=1, noise=0.4, bias=50)

def drawLine(a0, a1, X, y):
    max_x = np.max(X) + 100
    min_x = np.min(X) - 100
    xplot = np.linspace(min_x, max_x, 1000)
    yplot = a0 + a1 * xplot
    plt.plot(xplot, yplot, color='#58b970', label='Regression Line')
    plt.scatter(X, y)
    plt.axis([-10, 10, 0, 200])
    plt.show()

def predict(a0, a1, x):
    return a0 + (a1 * x)

def computeCost(a0, a1, X, y):
    costVal = 0
    for (xi, yi) in zip(X, y):
        costVal += 0.5 * ((predict(a0, a1, xi) - yi) ** 2)
    return costVal

def computeGradients(a0, a1, X, y):
    grad0 = 0
    grad1 = 0
    for (xi, yi) in zip(X, y):
        grad0 += predict(a0, a1, xi) - yi
        grad1 += (predict(a0, a1, xi) - yi) * xi
    grad0 /= len(X)
    grad1 /= len(X)
    return grad0, grad1

def updateParams(a0, a1, X, y, alpha):
    grad0, grad1 = computeGradients(a0, a1, X, y)
    a0 = a0 - (alpha * grad0)
    a1 = a1 - (alpha * grad1)
    return a0, a1

def fitLinearRegression(X, y):
    a0 = np.random.rand()
    a1 = np.random.rand()
    for i in range(0, 1000):
        if i % 100 == 0:
            drawLine(a0, a1, X, y)
        a0, a1 = updateParams(a0, a1, X, y, 0.005)

fitLinearRegression(X, y)