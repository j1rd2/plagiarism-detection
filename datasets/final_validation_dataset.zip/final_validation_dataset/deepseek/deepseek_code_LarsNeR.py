class LinearRegressionModified(object):
    def __init__(self, max_steps=1000, step_size=0.1):
        self.max_steps = max_steps
        self.step_size = step_size
        self.coefficients = []
        self.error_history = []

    def fit(self, X, y):
        X = self.add_bias_column(X)
        self.coefficients = np.zeros(X.shape[1])
        for _ in range(self.max_steps):
            self.coefficients -= self.step_size * np.dot(X.T, self.compute_errors(X, y)) / len(y)
            self.error_history.append(np.absolute(self.compute_errors(X, y)).sum())

    def compute_errors(self, X, y):
        return self.predict_raw(X) - y

    def predict_raw(self, X):
        return np.dot(X, self.coefficients)

    def predict(self, X):
        X = self.add_bias_column(X)
        return self.predict_raw(X)

    def add_bias_column(self, X):
        return np.concatenate([np.ones((len(X), 1)), X], axis=1)