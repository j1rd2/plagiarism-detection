def predict(theta, x):
    result = x[0] * theta[0] + x[1] * theta[1]
    return result

def compute_cost(X, Y, theta, m):
    total_sq_error = 0
    for i in range(m):
        x = X[i]
        h = predict(theta, x)
        y = Y[i]
        diff = h - y
        sq_error = diff ** 2
        total_sq_error += sq_error
    m = len(Y)
    factor = 1.0 / (2 * m)
    cost = factor * total_sq_error
    return cost

def compute_cost_derivative(X, Y, theta, j, m):
    total_error = 0
    for i in range(m):
        x = X[i]
        h = predict(theta, x)
        y = Y[i]
        diff = h - y
        error = diff * x[j]
        total_error += error
    m = len(Y)
    factor = 1.0 / m
    derivative = factor * total_error
    return derivative

def gradient_descent(X, Y, theta, m, alpha):
    new_theta = []
    factor = float(alpha) / m
    for j in range(len(theta)):
        derivative = compute_cost_derivative(X, Y, theta, j, m)
        new_theta_j = theta[j] - factor * derivative
        new_theta.append(new_theta_j)
    return new_theta

def linear_regression(X, Y, alpha, theta, num_iters):
    m = len(X)
    for iteration in range(num_iters):
        new_theta = gradient_descent(X, Y, theta, m, alpha)
        theta = new_theta
        if iteration % 100 == 0:
            print('theta ', theta)
            print('cost is ', compute_cost(X, Y, theta, m))
    return new_theta