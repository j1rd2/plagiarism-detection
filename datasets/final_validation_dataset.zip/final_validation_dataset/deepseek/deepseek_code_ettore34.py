from statistics import mean
import numpy as np
from matplotlib import style
import matplotlib.pyplot as plt

style.use('fivethirtyeight')

data_x = np.array([1,2,3,4,5,6], dtype=np.float64)
data_y = np.array([4,3,7,1,11,4], dtype=np.float64)

def compute_slope_and_intercept(x_vals, y_vals):
    slope = ((mean(x_vals)*mean(y_vals)) - (mean(x_vals*y_vals))) / ((mean(x_vals)*mean(x_vals)) - (mean(x_vals*x_vals)))
    intercept = mean(y_vals) - (slope*mean(x_vals))
    return slope, intercept

slope, intercept = compute_slope_and_intercept(data_x, data_y)

line_of_best_fit = [(slope*val) + intercept for val in data_x]

prediction_x = 9
prediction_y = slope*prediction_x + intercept

plt.scatter(prediction_x, prediction_y, color='r')
plt.scatter(data_x, data_y)
plt.plot(data_x, line_of_best_fit)
plt.show()