import numpy as np
import pandas as pd
from numpy.linalg import inv
from sklearn.datasets import load_boston
from statsmodels.regression.linear_model import OLS

boston_data = load_boston()
feature_matrix = boston_data.data
target = boston_data.target
intercept = np.ones(shape=target.shape)[..., None]
feature_matrix = np.concatenate((intercept, feature_matrix), 1)
coefficients = inv(feature_matrix.transpose().dot(feature_matrix)).dot(feature_matrix.transpose()).dot(target)
feature_labels = np.insert(boston_data.feature_names, 0, 'INT')
output_table = pd.DataFrame({'coeffs':coefficients}, index=feature_labels)
lm_coefficients = OLS(target, feature_matrix).fit().params
output_table['coeffs_lm'] = lm_coefficients
print(output_table.round(2))
print(output_table.round(2))