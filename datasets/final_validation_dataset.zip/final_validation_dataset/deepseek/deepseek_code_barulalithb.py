import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
import matplotlib.patches as mpatches

def compute_slope(x_vals, y_vals):
    n = len(x_vals)
    xy_sum = np.sum(x_vals * y_vals)
    x_sum = np.sum(x_vals)
    y_sum = np.sum(y_vals)
    x_sq_sum = np.sum(x_vals ** 2)
    slope_val = (n * xy_sum - x_sum * y_sum) / (n * x_sq_sum - x_sum ** 2)
    return slope_val

def compute_intercept(x_vals, y_vals):
    intercept_val = np.mean(y_vals) - compute_slope(x_vals, y_vals) * np.mean(x_vals)
    return intercept_val

def make_predictions(slope_val, x_input, intercept_val):
    preds = slope_val * x_input + intercept_val
    return preds

def r_squared(predicted, actual):
    ss_total = np.sum((actual - np.mean(actual)) ** 2)
    ss_res = np.sum((actual - predicted) ** 2)
    r2 = 1 - (ss_res / ss_total)
    return r2

def correlation_coefficient(predicted, actual):
    n = len(predicted)
    xy_sum = np.sum(predicted * actual)
    x_sum = np.sum(predicted)
    y_sum = np.sum(actual)
    x_sq_sum = np.sum(predicted ** 2)
    y_sq_sum = np.sum(actual ** 2)
    corr = (n * xy_sum - x_sum * y_sum) / np.sqrt((n * x_sq_sum - x_sum ** 2) * (n * y_sq_sum - y_sum ** 2))
    return corr

def compute_covariance(x_vals, y_vals):
    n = len(x_vals)
    xy_sum = np.sum(x_vals * y_vals)
    cov_val = xy_sum / n - np.mean(x_vals) * np.mean(y_vals)
    return cov_val

dataset = pd.read_csv('Salary_Data.csv')
array = dataset.values
X = array[:, 0]
print(X.shape)
Y = array[:, 1]
print(Y.shape)

left = 0.1
width = 0.8
ax1 = plt.axes([left, 0.5, width, 0.45])
ax1.boxplot(X)
ax1.set_title('Box plot for X')
plt.show()

ax2 = plt.axes([left, 0.5, width, 0.45])
ax2.boxplot(Y, '.-')
ax2.set_title('Distribution of Y Data')
plt.show()

print(compute_covariance(X, Y))

test_size = 0.10
seed = 7
X_train, X_validation, Y_train, Y_validation = train_test_split(X, Y, test_size=test_size, random_state=seed)

intercept_val = compute_intercept(X_train, Y_train)
slope_val = compute_slope(X_train, Y_train)
print(intercept_val, slope_val)
predictions = make_predictions(slope_val=slope_val, x_input=X_validation, intercept_val=intercept_val)
print(predictions)
print(r_squared(predicted=predictions, actual=Y_validation))
print(correlation_coefficient(predicted=predictions, actual=Y_validation))

y_line = slope_val * X + intercept_val

plt.scatter(X, Y, marker='^', color='k', alpha=0.55)
plt.plot(X, y_line, color='R', linewidth=2)
red_patch = mpatches.Patch(color='red', label='Regression Line')
plt.legend(loc=0, handles=[red_patch])
plt.title('Linear Regression Plot')
plt.tight_layout(pad=2)
plt.grid(False)
plt.show()

sns.set(style="whitegrid")
rs = np.random.RandomState(7)
sns.residplot(X, Y, lowess=True, color="r")
plt.title('Residual Plot')
plt.show()