import numpy
import matplotlib.pyplot as plot
import pandas as pd

info = pd.read_csv('Salary.csv')
print(info.shape)
print(info.head())

years = info['YearsExperience'].values
salary = info['Salary'].values

avg_years = numpy.mean(years)
avg_salary = numpy.mean(salary)

count = len(years)

top = 0
bottom = 0
for idx in range(count):
    top += (years[idx] - avg_years) * (salary[idx] - avg_salary)
    bottom += (years[idx] - avg_years) ** 2
slope = top / bottom
intercept = avg_salary - (slope * avg_years)

print("This is B1:", slope, "and this is B0:", intercept)

max_years = numpy.max(years) + 5
min_years = numpy.min(years) - 5

line_x = numpy.linspace(min_years, max_years, 1000)
line_y = intercept + slope * line_x

plot.plot(line_x, line_y, color='#58b970', label='Regression Line')
plot.scatter(years, salary, c='#ef5423', label='Scatter Plot')

plot.xlabel('YearsExperience')
plot.ylabel('Salary')
plot.legend()
plot.show()

rmse = 0
for idx in range(count):
    pred = intercept + slope * years[idx]
    rmse += (salary[idx] - pred) ** 2
rmse = numpy.sqrt(rmse / count)
print("This is Root Mean Square Error", rmse)

sst = 0
ssr = 0
for idx in range(count):
    pred = intercept + slope * years[idx]
    sst += (salary[idx] - avg_salary) ** 2
    ssr += (salary[idx] - pred) ** 2
r_squared = 1 - (ssr / sst)
print("This is the coefficient of determination", r_squared)