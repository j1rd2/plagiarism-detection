def compute_factorial(num):
    product = 1
    for j in range(2, num + 1):
        product = product * j
    return product

print(compute_factorial(5))