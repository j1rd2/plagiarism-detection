def combine(x, y):
    return x + y