import threading
import time

def display_values():
    for count in range(5):
        print(f"Thread 1: {count}")
        time.sleep(1)

def execute():
    worker = threading.Thread(target=display_values)
    worker.daemon = True
    worker.start()
    time.sleep(2)

if __name__ == "__main__":
    execute()