import psutil

def monitor_resources():
    cpu_percent = psutil.cpu_percent(interval=1)
    print(f"CPU Usage: {cpu_percent}%")
    
    mem_info = psutil.virtual_memory()
    print(f"Memory Usage: {mem_info.percent}%")
    
    disk_info = psutil.disk_usage('/')
    print(f"Disk Usage: {disk_info.percent}%")

def execute_monitoring():
    monitor_resources()

if __name__ == "__main__":
    execute_monitoring()