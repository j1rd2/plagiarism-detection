class FinancialTerminal:
    def __init__(self, initial_amount=0):
        self.account_total = initial_amount

    def show_total(self):
        print(f"Available funds: ${self.account_total:.2f}")

    def increase_funds(self, added_amount):
        if added_amount > 0:
            self.account_total += added_amount
            print(f"${added_amount:.2f} successfully deposited.")
        else:
            print("Deposit amount must be positive.")

    def decrease_funds(self, removed_amount):
        if removed_amount > self.account_total:
            print("Transaction declined due to insufficient funds.")
        elif removed_amount <= 0:
            print("Withdrawal amount must exceed zero.")
        else:
            self.account_total -= removed_amount
            print(f"${removed_amount:.2f} successfully withdrawn.")

    def display_menu(self):
        print("\n--- Financial Terminal ---")
        print("1. Check Account Total")
        print("2. Deposit Funds")
        print("3. Withdraw Funds")
        print("4. End Session")
        print("-------------------------\n")

def operate_terminal():
    terminal = FinancialTerminal(100)
    while True:
        terminal.display_menu()
        selection = input("Enter your choice (1-4): ")

        if selection == '1':
            terminal.show_total()
        elif selection == '2':
            deposit_value = float(input("Enter deposit amount: $"))
            terminal.increase_funds(deposit_value)
        elif selection == '3':
            withdrawal_value = float(input("Enter withdrawal amount: $"))
            terminal.decrease_funds(withdrawal_value)
        elif selection == '4':
            print("Session terminated. Thank you.")
            break
        else:
            print("Invalid input. Please select a valid option.")

if __name__ == "__main__":
    operate_terminal()