class Element:
    def __init__(self, value):
        self.value = value
        self.next = None

class Chain:
    def __init__(self):
        self.start = None

    def append(self, value):
        new_element = Element(value)
        if not self.start:
            self.start = new_element
            return
        current = self.start
        while current.next:
            current = current.next
        current.next = new_element

    def remove(self, target):
        current = self.start
        if current is not None:
            if current.value == target:
                self.start = current.next
                current = None
                return
        while current is not None:
            if current.value == target:
                break
            previous = current
            current = current.next
        if current is None:
            return
        previous.next = current.next
        current = None

    def display(self):
        current = self.start
        while current:
            print(current.value, end=" -> ")
            current = current.next
        print("None")

def execute():
    chain = Chain()
    chain.append(1)
    chain.append(2)
    chain.append(3)
    chain.display()
    chain.remove(2)
    chain.display()

if __name__ == "__main__":
    execute()