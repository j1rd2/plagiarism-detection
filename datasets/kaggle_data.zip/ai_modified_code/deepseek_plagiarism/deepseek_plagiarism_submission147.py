import matplotlib.pyplot as plt
import pandas as pd

def read_csv_data(filename):
    data_frame = pd.read_csv(filename)
    return data_frame

def compute_growth_rate(data_frame):
    data_frame['Growth'] = data_frame['Population'].pct_change() * 100
    return data_frame

def visualize_data(data_frame):
    plt.figure(figsize=(10, 6))

    plt.subplot(2, 1, 1)
    plt.plot(data_frame['Year'], data_frame['Population'], marker='o', linestyle='-')
    plt.title('Population Over Time')
    plt.xlabel('Year')
    plt.ylabel('Population')

    plt.subplot(2, 1, 2)
    plt.plot(data_frame['Year'], data_frame['Growth'], marker='o', linestyle='-', color='orange')
    plt.title('Population Growth Rate')
    plt.xlabel('Year')
    plt.ylabel('Growth Rate (%)')

    plt.tight_layout()
    plt.show()

def execute():
    filename = "population_data.csv"
    data_frame = read_csv_data(filename)
    data_frame = compute_growth_rate(data_frame)
    visualize_data(data_frame)

if __name__ == "__main__":
    execute()