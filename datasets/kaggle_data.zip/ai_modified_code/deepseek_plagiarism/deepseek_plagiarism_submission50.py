import csv

def load_pupil_marks(path_to_file):
    pupil_list = []
    with open(path_to_file, 'r') as f:
        csv_reader = csv.DictReader(f)
        for entry in csv_reader:
            pupil = {
                'Name': entry['Name'],
                'Score': float(entry['Score'])
            }
            pupil_list.append(pupil)
    return pupil_list

def compute_mean_mark(pupils):
    total = sum(pupil['Score'] for pupil in pupils)
    mean = total / len(pupils)
    return mean

def allocate_letter_grades(pupils, mean_mark):
    for pupil in pupils:
        if pupil['Score'] >= mean_mark:
            pupil['Grade'] = 'A'
        else:
            pupil['Grade'] = 'B'
    return pupils

def export_grades_to_file(pupils, result_file):
    with open(result_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['Name', 'Score', 'Grade'])
        writer.writeheader()
        for pupil in pupils:
            writer.writerow(pupil)

def execute():
    source = 'students.csv'
    destination = 'graded_students.csv'
    pupil_data = load_pupil_marks(source)
    mean_score = compute_mean_mark(pupil_data)
    graded_pupils = allocate_letter_grades(pupil_data, mean_score)
    export_grades_to_file(graded_pupils, destination)
    print(f"Processed student data written to {destination}")

if __name__ == "__main__":
    execute()