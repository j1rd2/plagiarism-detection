def verify_prime(num):
    if num <= 1:
        return False
    for d in range(2, num):
        if num % d == 0:
            return False
    return True

def collect_primes(limit):
    result = []
    for i in range(2, limit + 1):
        if verify_prime(i):
            result.append(i)
    return result

def execute():
    max_val = 50
    prime_numbers = collect_primes(max_val)
    print(f"Primes up to {max_val}: {prime_numbers}")

if __name__ == "__main__":
    execute()