import json

class Staff:
    def __init__(self, identifier, unit, pay):
        self.identifier = identifier
        self.unit = unit
        self.pay = pay

class UnitReport:
    def __init__(self, unit):
        self.unit = unit
        self.staff_list = []

    def include_staff(self, staff):
        if staff.unit == self.unit:
            self.staff_list.append(staff)

    def compute_mean_pay(self):
        if not self.staff_list:
            return 0
        total_pay = sum(person.pay for person in self.staff_list)
        return total_pay / len(self.staff_list)

    def convert_to_dict(self):
        return {
            'unit': self.unit,
            'mean_pay': self.compute_mean_pay(),
            'staff_quantity': len(self.staff_list)
        }

def load_staff(file_location):
    with open(file_location, 'r') as f:
        content = json.load(f)
    return [Staff(item['name'], item['department'], item['salary']) for item in content['employees']]

def store_report(report_data, destination_file):
    with open(destination_file, 'w') as f:
        json.dump(report_data, f, indent=4)

def execute():
    source_file = 'employees.json'
    result_file = 'department_summary.json'
    target_unit = 'Engineering'

    staff_members = load_staff(source_file)
    report = UnitReport(target_unit)
    
    for member in staff_members:
        report.include_staff(member)
    
    report_info = report.convert_to_dict()
    store_report(report_info, result_file)
    print(f"Department summary saved to {result_file}")

if __name__ == "__main__":
    execute()