def process_data(data):
    result = []
    for item in data:
        if item % 2 == 0:
            result.append(item * 2)
        else:
            result.append(item + 1)
    return result

def main():
    numbers = [1, 2, 3, 4, 5]
    processed = process_data(numbers)
    print(processed)

if __name__ == "__main__":
    main()