import sqlite3

def establish_link(db_path):
    link = sqlite3.connect(db_path)
    return link

def generate_table(link):
    table_sql = """CREATE TABLE IF NOT EXISTS users (
                        id integer PRIMARY KEY,
                        name text NOT NULL,
                        age integer
                    );"""
    try:
        executor = link.cursor()
        executor.execute(table_sql)
    except sqlite3.Error as err:
        print(err)

def add_person(link, person_data):
    insert_command = ''' INSERT INTO users(name, age)
                         VALUES(?,?) '''
    handler = link.cursor()
    handler.execute(insert_command, person_data)
    link.commit()
    return handler.lastrowid

def retrieve_all_people(link):
    handler = link.cursor()
    handler.execute("SELECT * FROM users")
    records = handler.fetchall()
    for record in records:
        print(record)

def execute_operations():
    storage = "test.db"
    link = establish_link(storage)
    with link:
        generate_table(link)
        person = ('John', 28)
        add_person(link, person)
        print("Users in the database:")
        retrieve_all_people(link)

if __name__ == '__main__':
    execute_operations()