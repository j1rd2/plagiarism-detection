class Gadget:
    def __init__(self, maker, name, system):
        self.maker = maker
        self.name = name
        self.system = system

    def show(self):
        print(f"Brand: {self.maker}, Model: {self.name}, OS Version: {self.system}")

def insert_gadget(collection, maker, name, system):
    new_gadget = Gadget(maker, name, system)
    collection.append(new_gadget)

def delete_gadget(collection, name):
    collection[:] = [g for g in collection if g.name != name]

def display_all(collection):
    for g in collection:
        g.show()

def execute():
    collection = []
    insert_gadget(collection, "Apple", "iPhone 13", "iOS 15")
    insert_gadget(collection, "Google", "Pixel 6", "Android 12")
    
    print("List of mobile devices before removal:")
    display_all(collection)
    
    delete_gadget(collection, "iPhone 13")
    
    print("List of mobile devices after removal:")
    display_all(collection)

if __name__ == "__main__":
    execute()