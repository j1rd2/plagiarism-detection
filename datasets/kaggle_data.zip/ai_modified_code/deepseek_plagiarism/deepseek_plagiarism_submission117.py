import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib
from sklearn.datasets import load_iris

def load_dataset():
    data = load_iris()
    features = data.data
    labels = data.target
    return features, labels

def split_data(inputs, outputs):
    X_tr, X_te, y_tr, y_te = train_test_split(inputs, outputs, test_size=0.3, random_state=42)
    return X_tr, X_te, y_tr, y_te

def train_model(train_X, train_y):
    classifier = RandomForestClassifier(n_estimators=100, random_state=42)
    classifier.fit(train_X, train_y)
    return classifier

def save_model(trained_model, filename):
    joblib.dump(trained_model, filename)

if __name__ == "__main__":
    X_data, y_data = load_dataset()
    X_train, X_test, y_train, y_test = split_data(X_data, y_data)
    rf_model = train_model(X_train, y_train)
    save_model(rf_model, 'random_forest_model.pkl')