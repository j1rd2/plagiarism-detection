import xml.etree.ElementTree as ET

def parse_books(file_name):
    tree = ET.parse(file_name)
    root = tree.getroot()
    parsed_books = []
    for item in root.findall('book'):
        parsed_books.append({
            'title': item.find('title').text,
            'author': item.find('author').text,
            'year': int(item.find('year').text),
            'price': float(item.find('price').text)
        })
    return parsed_books

def select_books_by_year(book_list, min_year):
    return [b for b in book_list if b['year'] > min_year]

def compute_average_cost(book_list):
    if len(book_list) == 0:
        return 0.0
    total = sum(b['price'] for b in book_list)
    return total / len(book_list)

def generate_output(book_list, avg_cost, out_file):
    root = ET.Element('bookSummary')
    avg_element = ET.SubElement(root, 'averagePrice')
    avg_element.text = str(avg_cost)
    for b in book_list:
        book_element = ET.SubElement(root, 'book')
        title_element = ET.SubElement(book_element, 'title')
        title_element.text = b['title']
        author_element = ET.SubElement(book_element, 'author')
        author_element.text = b['author']
        year_element = ET.SubElement(book_element, 'year')
        year_element.text = str(b['year'])
        price_element = ET.SubElement(book_element, 'price')
        price_element.text = str(b['price'])
    tree = ET.ElementTree(root)
    tree.write(out_file)

def execute():
    input_path = 'books.xml'
    output_path = 'recent_books.xml'
    threshold = 2000
    all_books = parse_books(input_path)
    selected_books = select_books_by_year(all_books, threshold)
    avg = compute_average_cost(selected_books)
    generate_output(selected_books, avg, output_path)
    print(f"XML output saved to {output_path}")

if __name__ == "__main__":
    execute()