import json

def load_employee_records(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data['employees']

def filter_by_department(records, target_dept):
    filtered = []
    for record in records:
        if record['department'] == target_dept:
            filtered.append(record)
    return filtered

def compute_mean_salary(records):
    if not records:
        return 0
    total = sum(record['salary'] for record in records)
    mean = total / len(records)
    return mean

def write_json_output(content, out_path):
    with open(out_path, 'w') as file:
        json.dump(content, file, indent=4)

def execute():
    input_path = 'employees.json'
    output_path = 'department_summary.json'
    department = 'Engineering'

    all_employees = load_employee_records(input_path)
    department_employees = filter_by_department(all_employees, department)
    mean_salary = compute_mean_salary(department_employees)
    
    result = {
        'department': department,
        'average_salary': mean_salary,
        'employee_count': len(department_employees)
    }

    write_json_output(result, output_path)
    print(f"Summary written to {output_path}")

if __name__ == "__main__":
    execute()