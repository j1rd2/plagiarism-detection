class Element:
    def __init__(self, value):
        self.value = value
        self.after = None
        self.before = None

class TwoWayChain:
    def __init__(self):
        self.start = None

    def append_value(self, value):
        fresh_element = Element(value)
        if not self.start:
            self.start = fresh_element
            return
        final_element = self.start
        while final_element.after:
            final_element = final_element.after
        final_element.after = fresh_element
        fresh_element.before = final_element

    def remove_value(self, target):
        current = self.start
        if current is not None:
            if current.value == target:
                self.start = current.after
                if self.start:
                    self.start.before = None
                current = None
                return
        while current is not None:
            if current.value == target:
                break
            current = current.after
        if current is None:
            return
        if current.after:
            current.after.before = current.before
        if current.before:
            current.before.after = current.after
        current = None

    def display_chain(self):
        current = self.start
        while current:
            print(current.value, end=" <-> ")
            current = current.after
        print("None")

def execute():
    chain = TwoWayChain()
    chain.append_value(1)
    chain.append_value(2)
    chain.append_value(3)
    chain.display_chain()
    chain.remove_value(2)
    chain.display_chain()

if __name__ == "__main__":
    execute()