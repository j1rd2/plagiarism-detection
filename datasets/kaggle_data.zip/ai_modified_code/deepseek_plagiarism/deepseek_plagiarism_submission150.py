import threading
import time

def custom_delay(label, interval):
    for step in range(5):
        print(f"{label}: {step}")
        time.sleep(interval)

def launch_threads():
    thread_a = threading.Thread(target=custom_delay, args=("Worker 1", 1.2))
    thread_b = threading.Thread(target=custom_delay, args=("Worker 2", 0.6))

    thread_b.start()
    thread_a.start()

    thread_b.join()
    thread_a.join()

if __name__ == "__main__":
    launch_threads()