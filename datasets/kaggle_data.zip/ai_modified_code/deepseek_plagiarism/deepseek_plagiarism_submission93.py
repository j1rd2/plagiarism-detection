class Stack:
    def __init__(self):
        self.items = []

    def push(self, element):
        self.items.append(element)

    def pop(self):
        if not self.is_empty():
            return self.items.pop(0)
        return None

    def peek(self):
        if not self.is_empty():
            return self.items[0]
        return None

    def is_empty(self):
        return len(self.items) == 0

    def length(self):
        return len(self.items)

def execute():
    stack = Stack()
    stack.push(1)
    stack.push(2)
    stack.push(3)
    print("Top element:", stack.peek())
    print("Stack length:", stack.length())
    stack.pop()
    print("Stack after pop:", stack.items)

if __name__ == "__main__":
    execute()