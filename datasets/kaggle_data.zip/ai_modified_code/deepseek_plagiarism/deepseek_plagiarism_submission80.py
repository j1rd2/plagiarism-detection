clients = {}
employees = {}

def register_client(client_num, client_name, funds):
    clients[client_num] = {"ClientName": client_name, "Funds": funds}

def hire_employee(emp_id, emp_name, role):
    employees[emp_id] = {"EmployeeName": emp_name, "Role": role}

def add_funds(client_num, value):
    if client_num in clients:
        clients[client_num]["Funds"] += value
    else:
        print("Client not found.")

def remove_funds(client_num, value):
    if client_num in clients:
        if clients[client_num]["Funds"] >= value:
            clients[client_num]["Funds"] -= value
        else:
            print("Insufficient funds.")
    else:
        print("Client not found.")

def display_clients():
    for client_num, details in clients.items():
        print(f"ID: {client_num}, Name: {details['ClientName']}, Balance: ${details['Funds']}")

def display_employees():
    for emp_id, details in employees.items():
        print(f"ID: {emp_id}, Name: {details['EmployeeName']}, Position: {details['Role']}")

def execute():
    register_client(1, "Emma", 3000)
    register_client(2, "John", 4000)

    hire_employee(101, "Lisa", "Manager")
    hire_employee(102, "Tom", "Teller")

    add_funds(1, 500)
    remove_funds(2, 1000)

    print("Customer List:")
    display_clients()

    print("\nStaff List:")
    display_employees()

if __name__ == "__main__":
    execute()