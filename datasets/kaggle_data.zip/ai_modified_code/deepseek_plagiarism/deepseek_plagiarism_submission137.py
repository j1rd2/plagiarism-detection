import threading
import time

def display_values():
    for count in range(5):
        print(f"Thread 1: {count}")
        time.sleep(1)

def execute_thread():
    worker = threading.Thread(target=display_values)
    worker.start()
    worker.join()

if __name__ == "__main__":
    execute_thread()