import xml.etree.ElementTree as ET

def parse_xml_data(file_name):
    tree = ET.parse(file_name)
    root = tree.getroot()
    return [
        {
            'title': item.find('title').text,
            'author': item.find('author').text,
            'year': int(item.find('year').text),
            'price': float(item.find('price').text)
        }
        for item in root.findall('book')
    ]

def filter_by_year(book_list, cutoff_year):
    return [b for b in book_list if b['year'] > cutoff_year]

def compute_average_cost(book_list):
    if not book_list:
        return 0
    total = sum(b['price'] for b in book_list)
    return total / len(book_list)

def generate_xml_report(book_list, avg_cost, output_path):
    root_element = ET.Element('booksReport')
    avg_element = ET.SubElement(root_element, 'averagePrice')
    avg_element.text = str(avg_cost)
    for entry in book_list:
        book_element = ET.SubElement(root_element, 'book')
        ET.SubElement(book_element, 'title').text = entry['title']
        ET.SubElement(book_element, 'author').text = entry['author']
        ET.SubElement(book_element, 'year').text = str(entry['year'])
        ET.SubElement(book_element, 'price').text = str(entry['price'])
    tree = ET.ElementTree(root_element)
    tree.write(output_path)

def execute():
    input_path = 'books.xml'
    output_path = 'filtered_books.xml'
    year_limit = 2000

    data = parse_xml_data(input_path)
    filtered_data = filter_by_year(data, year_limit)
    avg = compute_average_cost(filtered_data)
    generate_xml_report(filtered_data, avg, output_path)
    print(f"Books data written to {output_path}")

if __name__ == "__main__":
    execute()