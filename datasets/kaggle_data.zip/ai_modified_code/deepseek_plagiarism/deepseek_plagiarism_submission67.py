class MedicalRecord:
    def __init__(self, record_id, full_name, years, condition):
        self.record_id = record_id
        self.full_name = full_name
        self.years = years
        self.condition = condition

class Consultation:
    def __init__(self, consult_id, record, physician, day):
        self.consult_id = consult_id
        self.record = record
        self.physician = physician
        self.day = day

class ClinicSystem:
    def __init__(self):
        self.records = []
        self.consultations = []

    def register_record(self, record):
        self.records.append(record)

    def book_consultation(self, consultation):
        self.consultations.append(consultation)

    def display_records(self):
        for record in self.records:
            print(f"ID: {record.record_id}, Name: {record.full_name}, Age: {record.years}, Ailment: {record.condition}")

    def display_consultations(self):
        for consultation in self.consultations:
            print(f"Appointment ID: {consultation.consult_id}, Patient: {consultation.record.full_name}, Doctor: {consultation.physician}, Date: {consultation.day}")

def execute():
    clinic = ClinicSystem()

    record_a = MedicalRecord(1, "John Doe", 45, "Flu")
    record_b = MedicalRecord(2, "Jane Smith", 30, "Cough")

    clinic.register_record(record_a)
    clinic.register_record(record_b)

    consultation_a = Consultation(1, record_a, "Dr. Alice", "2024-09-15")
    consultation_b = Consultation(2, record_b, "Dr. Bob", "2024-09-16")

    clinic.book_consultation(consultation_a)
    clinic.book_consultation(consultation_b)

    print("Patient List:")
    clinic.display_records()

    print("\nAppointment List:")
    clinic.display_consultations()

if __name__ == "__main__":
    execute()