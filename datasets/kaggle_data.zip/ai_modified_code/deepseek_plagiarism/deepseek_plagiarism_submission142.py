import psutil

def monitor_processor():
    processor_load = psutil.cpu_percent(interval=1)
    print(f"Processor Load: {processor_load}%")

def execute():
    monitor_processor()

if __name__ == "__main__":
    execute()