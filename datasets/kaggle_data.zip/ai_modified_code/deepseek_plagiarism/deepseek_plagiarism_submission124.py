class Gadget:
    def __init__(self, maker, type, system, power):
        self.maker = maker
        self.type = type
        self.system = system
        self.power = power

    def show(self):
        print(f"Maker: {self.maker}, Type: {self.type}, System: {self.system}, Power: {self.power}mAh")

def insert_gadget(collection, maker, type, system, power):
    item = Gadget(maker, type, system, power)
    collection.append(item)

def display_all(collection):
    for item in collection:
        item.show()

def execute():
    collection = []
    insert_gadget(collection, "Xiaomi", "Mi 11", "Android 11", 4600)
    insert_gadget(collection, "OnePlus", "9 Pro", "Android 11", 4500)
    print("List of mobile devices with battery info:")
    display_all(collection)

if __name__ == "__main__":
    execute()