import sqlite3

def link_to_db(db_file):
    conn = sqlite3.connect(db_file)
    return conn

def setup_table(conn):
    sql = """CREATE TABLE IF NOT EXISTS staff (
                staff_id integer PRIMARY KEY,
                staff_name text NOT NULL,
                staff_age integer
            );"""
    try:
        c = conn.cursor()
        c.execute(sql)
    except sqlite3.Error as e:
        print(e)

def insert_staff(conn, employee):
    sql = ''' INSERT INTO staff(staff_name, staff_age)
               VALUES(?,?) '''
    cursor = conn.cursor()
    cursor.execute(sql, employee)
    conn.commit()
    return cursor.lastrowid

def get_all_staff(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM staff")
    rows = cursor.fetchall()
    for row in rows:
        print(row)

def execute_procedures():
    database = "organization.db"
    conn = link_to_db(database)
    with conn:
        setup_table(conn)
        employee = ('Alice', 38)
        insert_staff(conn, employee)
        print("Current staff in the database:")
        get_all_staff(conn)

if __name__ == '__main__':
    execute_procedures()