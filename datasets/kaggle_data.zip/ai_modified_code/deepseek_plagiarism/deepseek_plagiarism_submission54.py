import csv

def read_pupil_marks(filename):
    pupils = []
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            pupils.append({'Name': row['Name'], 'Score': float(row['Score'])})
    return pupils

def compute_mean_marks(pupils):
    total = sum(pupil['Score'] for pupil in pupils)
    mean = total / len(pupils)
    return mean

def assign_grades(pupils, mean):
    for pupil in pupils:
        pupil['Grade'] = 'A' if pupil['Score'] >= mean else 'B'
    return pupils

def write_grades_to_file(pupils, outfile):
    with open(outfile, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['Name', 'Score', 'Grade'])
        writer.writeheader()
        writer.writerows(pupils)

def execute():
    input_file = 'students.csv'
    output_file = 'graded_students.csv'
    pupil_data = read_pupil_marks(input_file)
    mean_score = compute_mean_marks(pupil_data)
    graded_pupils = assign_grades(pupil_data, mean_score)
    write_grades_to_file(graded_pupils, output_file)
    print(f"Graded students data saved to {output_file}")

if __name__ == "__main__":
    execute()