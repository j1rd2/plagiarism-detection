from flask import Flask

server = Flask(__name__)

@server.route('/welcome')
def welcome_message():
    return 'Hello, World!'

if __name__ == '__main__':
    server.run(debug=True)