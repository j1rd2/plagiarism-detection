def compute_difference(x, y):
    return x - y