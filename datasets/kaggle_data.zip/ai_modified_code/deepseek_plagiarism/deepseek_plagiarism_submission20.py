import logging

def check_non_negative_int(value):
    if not isinstance(value, int) or value < 0:
        raise ValueError("The provided input must be a non-negative integer.")

def iterative_factorial_calc(num):
    check_non_negative_int(num)
    output = 1
    for j in range(2, num + 1):
        output *= j
    return output

def recursive_factorial_calc(num):
    if num == 0:
        return 1
    return num * recursive_factorial_calc(num - 1)

def digit_sum_calc(number):
    return sum(int(ch) for ch in str(number))

def record_results(input_val, fact_result, sum_result):
    logging.basicConfig(filename='factorial_results.log', level=logging.INFO)
    logging.info(f"Input: {input_val}, Factorial: {fact_result}, Sum of digits: {sum_result}")

def main_menu():
    while True:
        try:
            user_val = int(input("Enter a non-negative integer: "))
            check_non_negative_int(user_val)
            fact_val = iterative_factorial_calc(user_val)
            sum_val = digit_sum_calc(fact_val)
            record_results(user_val, fact_val, sum_val)
            print(f"Factorial: {fact_val}, Sum of digits: {sum_val}")
        except ValueError as err:
            print(f"Error: {err}")

        answer = input("Calculate another factorial? (yes/no): ")
        if answer.lower() != 'yes':
            break

if __name__ == "__main__":
    main_menu()