class Employee:
    def __init__(self, emp_id, emp_name, position):
        self.emp_id = emp_id
        self.emp_name = emp_name
        self.position = position

class Client:
    def __init__(self, client_id, client_name, years, condition):
        self.client_id = client_id
        self.client_name = client_name
        self.years = years
        self.condition = condition

class Invoice:
    def __init__(self, invoice_id, client, total, deadline):
        self.invoice_id = invoice_id
        self.client = client
        self.total = total
        self.deadline = deadline

class Facility:
    def __init__(self):
        self.employees = []
        self.clients = []
        self.invoices = []

    def hire_employee(self, employee):
        self.employees.append(employee)

    def admit_client(self, client):
        self.clients.append(client)

    def generate_invoice(self, invoice):
        self.invoices.append(invoice)

    def display_employees(self):
        for employee in self.employees:
            print(f"ID: {employee.emp_id}, Name: {employee.emp_name}, Role: {employee.position}")

    def display_clients(self):
        for client in self.clients:
            print(f"ID: {client.client_id}, Name: {client.client_name}, Age: {client.years}, Ailment: {client.condition}")

    def display_invoices(self):
        for invoice in self.invoices:
            print(f"Bill ID: {invoice.invoice_id}, Patient: {invoice.client.client_name}, Amount: ${invoice.total}, Due Date: {invoice.deadline}")

def execute():
    facility = Facility()

    emp1 = Employee(1, "Dr. Smith", "Cardiologist")
    emp2 = Employee(2, "Nurse Jane", "Nurse")

    facility.hire_employee(emp1)
    facility.hire_employee(emp2)

    client1 = Client(1, "Emma Watson", 30, "High Blood Pressure")
    client2 = Client(2, "Chris Evans", 40, "Diabetes")

    facility.admit_client(client1)
    facility.admit_client(client2)

    invoice1 = Invoice(1, client1, 500.0, "2024-10-05")
    invoice2 = Invoice(2, client2, 800.0, "2024-10-10")

    facility.generate_invoice(invoice1)
    facility.generate_invoice(invoice2)

    print("Staff List:")
    facility.display_employees()

    print("\nPatient List:")
    facility.display_clients()

    print("\nBilling List:")
    facility.display_invoices()

if __name__ == "__main__":
    execute()