import psutil

def check_cpu_usage():
    cpu_usage = psutil.cpu_percent(interval=1)
    print(f"Current CPU Utilization: {cpu_usage}%")

def execute_monitoring():
    check_cpu_usage()

if __name__ == "__main__":
    execute_monitoring()