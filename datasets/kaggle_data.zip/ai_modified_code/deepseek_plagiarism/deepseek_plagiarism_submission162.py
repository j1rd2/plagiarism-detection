class College:
    def __init__(self, title):
        self.title = title
        self.sections = []

    def include_section(self, section):
        self.sections.append(section)

    def display_sections(self):
        print(f"Sections in {self.title}:")
        for sec in self.sections:
            print(f"- {sec}")

def execute():
    college = College("Harvard University")
    college.include_section("Computer Science")
    college.include_section("Mathematics")
    college.include_section("Physics")
    college.display_sections()

if __name__ == "__main__":
    execute()