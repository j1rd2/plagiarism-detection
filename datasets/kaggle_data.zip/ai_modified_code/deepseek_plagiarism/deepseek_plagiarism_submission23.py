import logging

def check_number_is_valid(value):
    if not isinstance(value, int) or value < 0:
        raise ValueError("Input must be a non-negative integer.")

def compute_factorial(number):
    check_number_is_valid(number)
    result = 1
    while number > 1:
        result *= number
        number -= 1
    return result

def add_digits_of_number(factorial_result):
    return sum(int(char) for char in str(factorial_result))

def write_outcome_to_log(original_number, factorial_result, digit_total):
    logging.basicConfig(filename='factorial_computation.log', level=logging.INFO)
    logging.info(f"Factorial of {original_number}: {factorial_result}, Sum of digits: {digit_total}")

def run_factorial_process():
    while True:
        try:
            user_input = int(input("Please enter a non-negative integer: "))
            computed_factorial = compute_factorial(user_input)
            digit_sum = add_digits_of_number(computed_factorial)
            write_outcome_to_log(user_input, computed_factorial, digit_sum)
            print(f"Factorial: {computed_factorial}, Sum of digits: {digit_sum}")
        except ValueError as error:
            print(f"Error: {error}")

        if input("Perform another calculation? (yes/no): ").lower() != 'yes':
            break

if __name__ == "__main__":
    run_factorial_process()