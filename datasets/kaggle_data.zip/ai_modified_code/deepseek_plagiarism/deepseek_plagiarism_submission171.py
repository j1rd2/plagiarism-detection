class Transport:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year

    def display_info(self):
        print(f"Brand: {self.make}, Type: {self.model}, Year: {self.year}")

def add_transport(transport_collection, make, model, year):
    new_transport = Transport(make, model, year)
    transport_collection.append(new_transport)

def list_all_transports(transport_collection):
    for transport in transport_collection:
        transport.display_info()

def execute_transport_system():
    transport_collection = []
    add_transport(transport_collection, "Honda", "Civic", 2020)
    add_transport(transport_collection, "Chevrolet", "Camaro", 2019)

    print("Registered vehicles:")
    list_all_transports(transport_collection)

if __name__ == "__main__":
    execute_transport_system()