def check_input(x):
    return type(x) == int and x >= 0

def compute_factorial(y):
    if not check_input(y):
        raise ValueError("Please enter a non-negative integer")
    output = 1
    while y > 1:
        output *= y
        y -= 1
    return output

def execute():
    try:
        value = int(input("Enter a number to find its factorial: "))
        print(f"Factorial: {compute_factorial(value)}")
    except ValueError as err:
        print(err)

if __name__ == "__main__":
    execute()