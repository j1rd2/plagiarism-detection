class LibraryItem:
    def __init__(self, name, creator, cost):
        self.name = name
        self.creator = creator
        self.cost = cost

    def show_details(self):
        print(f"Title: {self.name}, Author: {self.creator}, Price: ${self.cost}")

def insert_item(collection, name, creator, cost):
    new_item = LibraryItem(name, creator, cost)
    collection.append(new_item)

def delete_item(collection, name):
    collection[:] = [item for item in collection if item.name != name]

def display_all(collection):
    for item in collection:
        item.show_details()

def execute():
    collection = []
    insert_item(collection, "Moby Dick", "Herman Melville", 11.99)
    insert_item(collection, "Pride and Prejudice", "Jane Austen", 6.99)
    print("Books available before removal:")
    display_all(collection)
    delete_item(collection, "Moby Dick")
    print("\nBooks available after removal:")
    display_all(collection)

if __name__ == "__main__":
    execute()