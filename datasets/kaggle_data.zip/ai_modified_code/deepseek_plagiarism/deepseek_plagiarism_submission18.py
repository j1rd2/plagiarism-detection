import logging

def check_number(x):
    return isinstance(x, int) and x >= 0

def compute_fact(y):
    if y == 0:
        return 1
    else:
        return y * compute_fact(y - 1)

def record_output(a, b):
    logging.basicConfig(filename='factorial.log', level=logging.INFO)
    logging.info(f"Factorial of {a} is {b}")

def perform_calculation():
    try:
        value = int(input("Enter a non-negative integer: "))
        if not check_number(value):
            raise ValueError("Input must be a non-negative integer.")
        output = compute_fact(value)
        record_output(value, output)
        print(f"Factorial of {value} is {output}")
    except ValueError as err:
        print(err)

def run_program():
    while True:
        perform_calculation()
        response = input("Do you want to calculate another factorial? (yes/no): ")
        if response.lower() != 'yes':
            break

if __name__ == "__main__":
    run_program()