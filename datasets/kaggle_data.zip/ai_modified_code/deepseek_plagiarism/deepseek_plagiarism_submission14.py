def check_input(value):
    if isinstance(value, int) and value >= 0:
        return True
    return False

def compute_factorial(num):
    if not check_input(num):
        raise ValueError("Input must be a non-negative integer")
    if num == 0:
        return 1
    return num * compute_factorial(num - 1)

try:
    user_input = int(input("Enter a number: "))
    result = compute_factorial(user_input)
    print(f"The factorial of {user_input} is {result}")
except ValueError as error:
    print(error)