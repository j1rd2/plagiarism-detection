import random

def simulate_mutations():
    initial_sequence = "ATGCTAGCTAGT"
    changed_sequence, mutation_record = modify_dna(initial_sequence, 0.05)
    print("Original Sequence:", initial_sequence)
    print("Mutated Sequence:", changed_sequence)
    print("Mutation Log:", mutation_record)

def modify_dna(dna_string, mutation_rate=0.01):
    nucleotides = ['A', 'T', 'C', 'G']
    altered_dna = list(dna_string)
    log_entries = []

    for position in range(len(altered_dna)):
        if random.random() < mutation_rate:
            old_nucleotide = altered_dna[position]
            new_nucleotide = random.choice(nucleotides)
            altered_dna[position] = new_nucleotide
            log_entries.append((position, old_nucleotide, new_nucleotide))

    return ''.join(altered_dna), log_entries

if __name__ == "__main__":
    simulate_mutations()