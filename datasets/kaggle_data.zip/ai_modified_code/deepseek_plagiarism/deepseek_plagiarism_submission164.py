class Organization:
    def __init__(self, org_name):
        self.org_name = org_name
        self.departments = []

    def include_department(self, department):
        self.departments.append(department)

    def list_departments(self):
        print(f"Departments in {self.org_name}:")
        for department in self.departments:
            print(f"- {department}")


def execute_program():
    org = Organization("Oxford Organization")
    org.include_department("Information Technology")
    org.include_department("Law")
    org.include_department("Chemistry")

    org.list_departments()


if __name__ == "__main__":
    execute_program()