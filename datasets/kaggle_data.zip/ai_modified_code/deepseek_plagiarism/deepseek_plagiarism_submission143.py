import psutil

def monitor_resources():
    cpu_usage = psutil.cpu_percent(interval=1)
    print(f"CPU Usage: {cpu_usage}%")
    memory_info = psutil.virtual_memory()
    print(f"Memory Usage: {memory_info.percent}%")

def execute_monitoring():
    monitor_resources()

if __name__ == "__main__":
    execute_monitoring()