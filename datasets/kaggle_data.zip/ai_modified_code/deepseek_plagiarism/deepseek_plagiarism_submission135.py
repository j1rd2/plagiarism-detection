import openpyxl

def generate_product_excel(file_path):
    workbook = openpyxl.Workbook()
    worksheet = workbook.active
    
    worksheet['A1'] = "Product"
    worksheet['B1'] = "Price"
    
    worksheet['A2'] = "Laptop"
    worksheet['B2'] = 999.99
    
    worksheet['A3'] = "Smartphone"
    worksheet['B3'] = 499.99
    
    workbook.save(file_path)
    print(f"File '{file_path}' created with product data successfully!")

def execute_main():
    generate_product_excel("products.xlsx")

if __name__ == "__main__":
    execute_main()