import random

def alter_sequence(seq, chance=0.02):
    nucleotides = ['A', 'T', 'C', 'G']
    result = list(seq)
    
    for index in range(len(result)):
        if random.random() < chance:
            result[index] = random.choice(nucleotides)
    
    return ''.join(result)

def execute():
    original = "ATGCTAGCTAGT"
    changed = alter_sequence(original, chance=0.05)
    print("Original DNA sequence:", original)
    print("Mutated DNA sequence:", changed)

if __name__ == "__main__":
    execute()