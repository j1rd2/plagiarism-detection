def transform_sequence(original_str):
    mapping = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
    flipped = original_str[::-1]
    result = ''.join(mapping[char] for char in flipped)
    return result

def execute():
    input_data = "ATGCTAGCTAGT"
    output_data = transform_sequence(input_data)
    print("Original DNA sequence:", input_data)
    print("Reverse complement:", output_data)

if __name__ == "__main__":
    execute()