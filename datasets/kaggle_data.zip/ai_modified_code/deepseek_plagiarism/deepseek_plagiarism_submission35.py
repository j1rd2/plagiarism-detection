def check_prime(value):
    if value <= 1:
        return False
    for divisor in range(2, value):
        if value % divisor == 0:
            return False
    return True

def generate_primes(boundary):
    result = []
    for candidate in range(2, boundary + 1):
        if check_prime(candidate):
            result.append(candidate)
    return result

def execute():
    max_value = 50
    primes = generate_primes(max_value)
    print(f"Prime numbers up to {max_value}: {primes}")

if __name__ == "__main__":
    execute()