def compute_factorial(value):
    if value < 0:
        return None
    elif value == 0 or value == 1:
        return 1
    else:
        return value * compute_factorial(value - 1)

def execute():
    user_input = int(input("Enter a positive integer: "))
    if user_input < 0:
        print("Factorial is not defined for negative numbers.")
    else:
        print(f"The factorial of {user_input} is {compute_factorial(user_input)}")

if __name__ == "__main__":
    execute()