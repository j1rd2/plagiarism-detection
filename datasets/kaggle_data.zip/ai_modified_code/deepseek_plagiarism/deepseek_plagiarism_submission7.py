def reorder_sequence(collection):
    size = len(collection)
    for outer in range(size):
        for inner in range(0, size - outer - 1):
            if collection[inner] > collection[inner + 1]:
                collection[inner], collection[inner + 1] = collection[inner + 1], collection[inner]

values = [64, 34, 25, 12, 22, 11, 90]
reorder_sequence(values)
print("Sorted array:", values)