def process_data(source_path):
    with open(source_path, 'r') as f:
        values = [int(line.strip()) for line in f]
    return values

def compute_squares(values):
    return [x ** 2 for x in values]

def save_results(values, destination_path):
    with open(destination_path, 'w') as f:
        for v in values:
            f.write(f"{v}\n")

def execute():
    input_path = 'input.txt'
    output_path = 'output.txt'
    data = process_data(input_path)
    squared_data = compute_squares(data)
    save_results(squared_data, output_path)
    print(f"Squared numbers have been written to {output_path}")

if __name__ == "__main__":
    execute()