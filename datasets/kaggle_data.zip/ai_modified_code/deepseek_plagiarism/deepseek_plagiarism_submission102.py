import random

def alter_sequence(original, rate=0.01):
    bases = ['A', 'T', 'C', 'G']
    changed = list(original)
    
    for position in range(len(changed)):
        if random.random() < rate:
            changed[position] = random.choice(bases)
    
    return ''.join(changed)

def execute():
    initial = "ATGCTAGCTAGT"
    result = alter_sequence(initial, rate=0.05)
    print("Original DNA sequence:", initial)
    print("Mutated DNA sequence:", result)

if __name__ == "__main__":
    execute()