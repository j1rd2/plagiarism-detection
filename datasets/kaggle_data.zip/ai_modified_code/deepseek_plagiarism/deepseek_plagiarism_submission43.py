def reorder_execution(data):
    arranged = sorted(data, key=lambda entry: entry['age'], cmp=comparator)
    return arranged

def comparator(entry_a, entry_b):
    if entry_a['age'] < entry_b['age']:
        return -1
    elif entry_a['age'] > entry_b['age']:
        return 1
    else:
        return 0

def display_arranged(data):
    print("Sorted list of people by age using custom comparison:")
    for entry in data:
        print(f"Name: {entry['name']}, Age: {entry['age']}")

def execute():
    data = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    arranged_data = reorder_execution(data)
    display_arranged(arranged_data)

if __name__ == "__main__":
    execute()