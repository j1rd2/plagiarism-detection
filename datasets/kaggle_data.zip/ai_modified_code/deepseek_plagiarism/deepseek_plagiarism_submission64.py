import xml.etree.ElementTree as ET

class Volume:
    def __init__(self, name, writer, date, cost):
        self.name = name
        self.writer = writer
        self.date = date
        self.cost = cost

class VolumeHandler:
    def __init__(self, source):
        self.source = source
        self.volumes = []

    def import_volumes(self):
        data = ET.parse(self.source)
        base = data.getroot()
        for volume_elem in base.findall('book'):
            name = volume_elem.find('title').text
            writer = volume_elem.find('author').text
            date = int(volume_elem.find('year').text)
            cost = float(volume_elem.find('price').text)
            self.volumes.append(Volume(name, writer, date, cost))

    def select_volumes(self, threshold):
        return [volume for volume in self.volumes if volume.date > threshold]

    def compute_mean_cost(self, selected):
        total = sum(volume.cost for volume in selected)
        return total / len(selected) if selected else 0

    def export_xml(self, selected, mean, destination):
        base = ET.Element('bookSummary')
        mean_elem = ET.SubElement(base, 'averagePrice')
        mean_elem.text = str(mean)
        for volume in selected:
            volume_elem = ET.SubElement(base, 'book')
            ET.SubElement(volume_elem, 'title').text = volume.name
            ET.SubElement(volume_elem, 'author').text = volume.writer
            ET.SubElement(volume_elem, 'year').text = str(volume.date)
            ET.SubElement(volume_elem, 'price').text = str(volume.cost)
        tree = ET.ElementTree(base)
        tree.write(destination)

def execute():
    source_file = 'books.xml'
    destination_file = 'summary_books.xml'
    threshold_year = 2000
    handler = VolumeHandler(source_file)
    handler.import_volumes()
    selected_volumes = handler.select_volumes(threshold_year)
    mean_cost = handler.compute_mean_cost(selected_volumes)
    handler.export_xml(selected_volumes, mean_cost, destination_file)
    print(f"Book summary saved to {destination_file}")

if __name__ == "__main__":
    execute()