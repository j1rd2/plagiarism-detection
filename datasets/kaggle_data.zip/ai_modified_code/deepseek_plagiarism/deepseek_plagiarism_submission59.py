import json

def fetch_workers(file_name):
    with open(file_name, 'r') as f:
        content = json.load(f)
    return content['employees']

def check_department(dept):
    def checker(worker):
        return worker['department'] == dept
    return checker

def extract_pay(worker):
    return worker['salary']

def compute_mean(values):
    if not values:
        return 0.0
    return sum(values) / len(values)

def store_data(info, destination):
    with open(destination, 'w') as f:
        json.dump(info, f, indent=4)

def execute():
    source = 'employees.json'
    target = 'department_summary.json'
    chosen_dept = 'Engineering'

    workers = fetch_workers(source)
    filtered_workers = list(filter(check_department(chosen_dept), workers))
    pay_list = list(map(extract_pay, filtered_workers))
    mean_pay = compute_mean(pay_list)
    
    summary = {
        'department': chosen_dept,
        'average_salary': mean_pay,
        'employee_count': len(filtered_workers)
    }

    store_data(summary, target)
    print(f"Output saved to {target}")

if __name__ == "__main__":
    execute()