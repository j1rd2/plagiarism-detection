from sqlite3 import Error
import sqlite3

def establish_link(db_path):
    link = None
    try:
        link = sqlite3.connect(db_path)
        print(f"Linked to {db_path}.")
    except Error as err:
        print(f"Problem: {err}")
    return link

def generate_table(link):
    table_sql = """CREATE TABLE IF NOT EXISTS patients (
                       patient_id integer PRIMARY KEY,
                       patient_name text NOT NULL,
                       patient_age integer
                   );"""
    try:
        executor = link.cursor()
        executor.execute(table_sql)
        print("Table 'patients' is ready.")
    except Error as err:
        print(f"Problem: {err}")

def add_entry(link, entry_data):
    insert_cmd = ''' INSERT INTO patients(patient_name, patient_age)
                     VALUES(?,?) '''
    handler = link.cursor()
    handler.execute(insert_cmd, entry_data)
    link.commit()
    return handler.lastrowid

def retrieve_all(link):
    try:
        handler = link.cursor()
        handler.execute("SELECT * FROM patients")
        results = handler.fetchall()
        for item in results:
            print(item)
    except Error as err:
        print(f"Problem: {err}")

def execute_operations():
    storage = "hospital.db"
    link = establish_link(storage)
    if link is not None:
        generate_table(link)
        entry = ('Alice', 30)
        add_entry(link, entry)
        print("Database entries:")
        retrieve_all(link)
    else:
        print("Failed to establish link.")

if __name__ == '__main__':
    execute_operations()