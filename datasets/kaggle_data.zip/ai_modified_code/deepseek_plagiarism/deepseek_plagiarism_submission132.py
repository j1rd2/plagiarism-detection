import openpyxl

def generate_spreadsheet(file_path):
    workbook = openpyxl.Workbook()
    worksheet = workbook.active
    
    worksheet['A1'] = "Name"
    worksheet['B1'] = "Age"
    
    worksheet['A2'] = "Alice"
    worksheet['B2'] = 30
    
    worksheet['A3'] = "Bob"
    worksheet['B3'] = 25
    
    workbook.save(file_path)
    print(f"File '{file_path}' created and data written successfully!")

def execute():
    generate_spreadsheet("students_basic.xlsx")

if __name__ == "__main__":
    execute()