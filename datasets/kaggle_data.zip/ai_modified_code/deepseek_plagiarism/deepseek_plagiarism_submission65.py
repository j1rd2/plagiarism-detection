import xml.etree.ElementTree as ET

def load_book_data(file_name):
    document = ET.parse(file_name)
    base = document.getroot()
    return [
        {
            'name': item.find('title').text,
            'writer': item.find('author').text,
            'published': int(item.find('year').text),
            'cost': float(item.find('price').text)
        }
        for item in base.findall('book')
    ]

def filter_by_year(book_list, cutoff):
    return [entry for entry in book_list if entry['published'] > cutoff]

def calculate_mean(book_list):
    if not book_list:
        return 0
    total = sum(entry['cost'] for entry in book_list)
    return total / len(book_list)

def generate_report(book_list, mean_cost, report_file):
    top = ET.Element('bookSummary')
    mean_element = ET.SubElement(top, 'meanPrice')
    mean_element.text = str(mean_cost)
    for entry in book_list:
        book_node = ET.SubElement(top, 'bookEntry')
        ET.SubElement(book_node, 'name').text = entry['name']
        ET.SubElement(book_node, 'writer').text = entry['writer']
        ET.SubElement(book_node, 'published').text = str(entry['published'])
        ET.SubElement(book_node, 'cost').text = str(entry['cost'])
    report_tree = ET.ElementTree(top)
    report_tree.write(report_file)

def execute():
    source = 'books.xml'
    destination = 'filtered_books.xml'
    threshold = 2000

    all_books = load_book_data(source)
    filtered_books = filter_by_year(all_books, threshold)
    average = calculate_mean(filtered_books)
    generate_report(filtered_books, average, destination)
    print(f"Books report saved to {destination}")

if __name__ == "__main__":
    execute()