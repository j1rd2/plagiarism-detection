def reorder_list(values):
    if len(values) <= 1:
        return values
    else:
        center = values[0]
        lower = [item for item in values[1:] if item <= center]
        higher = [item for item in values[1:] if item > center]
        return reorder_list(lower) + [center] + reorder_list(higher)

def execute():
    data = [10, 7, 8, 9, 1, 5]
    print("Original array:", data)
    arranged = reorder_list(data)
    print("Sorted array:", arranged)

if __name__ == "__main__":
    execute()