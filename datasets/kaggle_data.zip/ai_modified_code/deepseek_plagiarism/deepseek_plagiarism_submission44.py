def reorder_by_years(persons):
    arranged = sorted(persons, key=lambda person: person['age'])
    return arranged

def display_persons(persons):
    print("Outputting the sorted list of individuals by age:")
    for person in persons:
        print(f"Person: {person['name']}, Age: {person['age']}")

def execute():
    data = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    ordered = reorder_by_years(data)
    display_persons(ordered)

if __name__ == "__main__":
    execute()