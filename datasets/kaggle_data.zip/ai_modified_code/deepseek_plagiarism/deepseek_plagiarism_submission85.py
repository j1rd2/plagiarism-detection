def reorder_execution(sequence):
    length = len(sequence)
    for outer in range(length):
        flag = False
        for inner in range(0, length - outer - 1):
            if sequence[inner] > sequence[inner + 1]:
                sequence[inner], sequence[inner + 1] = sequence[inner + 1], sequence[inner]
                flag = True
        if not flag:
            break

def start():
    data = [5, 1, 4, 2, 8]
    print("Original array:", data)
    reorder_execution(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    start()