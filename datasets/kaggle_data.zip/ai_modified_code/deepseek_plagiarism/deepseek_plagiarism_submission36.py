import math

def check_prime_fast(x):
    if x < 2:
        return False
    if x == 2:
        return True
    if x % 2 == 0:
        return False
    for divisor in range(3, int(math.sqrt(x)) + 1, 2):
        if x % divisor == 0:
            return False
    return True

def generate_primes_fast(boundary):
    return [value for value in range(2, boundary + 1) if check_prime_fast(value)]

def execute():
    upper_limit = 50
    primes = generate_primes_fast(upper_limit)
    print(f"Prime numbers up to {upper_limit}: {primes}")

if __name__ == "__main__":
    execute()