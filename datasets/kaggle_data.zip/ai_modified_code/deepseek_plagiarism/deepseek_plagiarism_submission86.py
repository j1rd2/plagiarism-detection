def combine_split(sequence):
    if len(sequence) > 1:
        center = len(sequence) // 2
        first_part = sequence[:center]
        second_part = sequence[center:]

        combine_split(first_part)
        combine_split(second_part)

        a = b = c = 0
        while a < len(first_part) and b < len(second_part):
            if first_part[a] < second_part[b]:
                sequence[c] = first_part[a]
                a += 1
            else:
                sequence[c] = second_part[b]
                b += 1
            c += 1

        while a < len(first_part):
            sequence[c] = first_part[a]
            a += 1
            c += 1

        while b < len(second_part):
            sequence[c] = second_part[b]
            b += 1
            c += 1

def execute():
    data = [38, 27, 43, 3, 9, 82, 10]
    print("Original array:", data)
    combine_split(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    execute()