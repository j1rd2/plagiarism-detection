def check_input(y):
    if not isinstance(y, int) or y < 0:
        return False
    return True

def compute_factorial(y):
    if not check_input(y):
        raise ValueError("Input should be a non-negative integer")
    result = 1
    for j in range(1, y + 1):
        result *= j
    return result

def execute():
    try:
        value = int(input("Enter a positive integer: "))
        print(f"The factorial is {compute_factorial(value)}")
    except ValueError as err:
        print(f"Error: {err}")

if __name__ == "__main__":
    execute()