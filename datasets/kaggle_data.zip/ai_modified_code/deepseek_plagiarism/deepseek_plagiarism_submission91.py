import heapq

def compute_paths(network, origin):
    path_lengths = {node: float('inf') for node in network}
    path_lengths[origin] = 0
    heap = [(0, origin)]

    while heap:
        dist_now, node_now = heapq.heappop(heap)

        if dist_now > path_lengths[node_now]:
            continue

        for adjacent, edge_weight in network[node_now].items():
            new_dist = dist_now + edge_weight

            if new_dist < path_lengths[adjacent]:
                path_lengths[adjacent] = new_dist
                heapq.heappush(heap, (new_dist, adjacent))

    return path_lengths

def execute():
    example_network = {
        'X': {'Y': 1, 'Z': 4},
        'Y': {'X': 1, 'Z': 2, 'W': 5},
        'Z': {'X': 4, 'Y': 2, 'W': 1},
        'W': {'Y': 5, 'Z': 1}
    }
    source = 'X'
    print(f"Shortest distances from node {source}:")
    print(compute_paths(example_network, source))

if __name__ == "__main__":
    execute()