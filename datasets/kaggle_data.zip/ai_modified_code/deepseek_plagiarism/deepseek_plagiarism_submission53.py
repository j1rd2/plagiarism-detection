import csv

class Learner:
    def __init__(self, identifier, mark):
        self.identifier = identifier
        self.mark = mark
        self.rating = None

    def set_rating(self, mean_mark):
        self.rating = 'X' if self.mark >= mean_mark else 'Y'

class DataHandler:
    def __init__(self, source_path):
        self.source_path = source_path
        self.learners = []

    def load_learners(self):
        with open(self.source_path, 'r') as f:
            parser = csv.DictReader(f)
            for entry in parser:
                learner = Learner(entry['Name'], float(entry['Score']))
                self.learners.append(learner)

    def compute_mean(self):
        aggregate = sum(learner.mark for learner in self.learners)
        return aggregate / len(self.learners)

    def assign_ratings(self, mean_mark):
        for learner in self.learners:
            learner.set_rating(mean_mark)

    def export_data(self, destination_path):
        with open(destination_path, 'w', newline='') as f:
            recorder = csv.writer(f)
            recorder.writerow(['Name', 'Score', 'Grade'])
            for learner in self.learners:
                recorder.writerow([learner.identifier, learner.mark, learner.rating])

def execute():
    source_path = 'students.csv'
    destination_path = 'graded_students.csv'
    handler = DataHandler(source_path)
    handler.load_learners()
    mean_value = handler.compute_mean()
    handler.assign_ratings(mean_value)
    handler.export_data(destination_path)
    print(f"Grading completed. Results written to {destination_path}")

if __name__ == "__main__":
    execute()