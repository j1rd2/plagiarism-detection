import pandas as pd
import matplotlib.pyplot as plt

def load_dataset(path):
    df = pd.read_csv(path)
    return df

def calculate_growth(df):
    df['GrowthRate'] = df['Population'].pct_change() * 100
    return df

def plot_results(df):
    plt.figure(figsize=(10, 6))
    plt.subplot(2, 1, 1)
    plt.plot(df['Year'], df['Population'], marker='o', linestyle='-')
    plt.title('Population Trend Over Time')
    plt.xlabel('Year')
    plt.ylabel('Population')
    plt.subplot(2, 1, 2)
    plt.plot(df['Year'], df['GrowthRate'], marker='o', linestyle='-', color='orange')
    plt.title('Population Growth Rate Over Time')
    plt.xlabel('Year')
    plt.ylabel('Growth Rate (%)')
    plt.tight_layout()
    plt.show()

def main():
    path = "population_data.csv"
    df = load_dataset(path)
    df = calculate_growth(df)
    plot_results(df)

if __name__ == "__main__":
    main()