import logging

def validate_input(value):
    if not isinstance(value, int) or value < 0:
        raise ValueError("Input must be a non-negative integer.")

def compute_factorial_iterative(num):
    validate_input(num)
    product = 1
    for multiplier in range(2, num + 1):
        product *= multiplier
    return product

def calculate_digit_total(number):
    return sum(int(character) for character in str(number))

def record_output(input_value, factorial_value, digit_total):
    logging.basicConfig(filename='factorial_log_output.log', level=logging.INFO)
    logging.info(f"Factorial of {input_value}: {factorial_value}, Sum of digits: {digit_total}")

def execute():
    while True:
        try:
            user_input = int(input("Enter a non-negative integer: "))
            computed_factorial = compute_factorial_iterative(user_input)
            total_digits = calculate_digit_total(computed_factorial)
            record_output(user_input, computed_factorial, total_digits)
            print(f"Factorial: {computed_factorial}, Sum of digits: {total_digits}")
        except ValueError as err:
            print(f"Error: {err}")

        if input("Calculate another? (yes/no): ").lower() != 'yes':
            break

if __name__ == "__main__":
    execute()