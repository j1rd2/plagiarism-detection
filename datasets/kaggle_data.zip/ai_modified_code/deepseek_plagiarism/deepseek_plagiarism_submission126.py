class Gadget:
    def __init__(self, company, type, system):
        self.company = company
        self.type = type
        self.system = system

    def show_details(self):
        print(f"Brand: {self.company}, Model: {self.type}, OS Version: {self.system}")

def insert_gadget(collection, company, type, system):
    item = Gadget(company, type, system)
    collection.append(item)

def find_gadget_by_type(collection, type):
    for item in collection:
        if item.type == type:
            item.show_details()

def display_all(collection):
    for item in collection:
        item.show_details()

def execute():
    collection = []
    insert_gadget(collection, "Sony", "Xperia", "Android 10")
    insert_gadget(collection, "Nokia", "8.3", "Android 11")

    print("List of mobile devices:")
    display_all(collection)

    print("Search for devices by model:")
    find_gadget_by_type(collection, "8.3")

if __name__ == "__main__":
    execute()