import math

def compute_factorial(value):
    return math.factorial(value)

print(compute_factorial(5))