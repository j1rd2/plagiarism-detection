def reorder_sequence(data):
    length = len(data)
    for outer in range(length):
        for inner in range(0, length - outer - 1):
            if data[inner] > data[inner + 1]:
                data[inner], data[inner + 1] = data[inner + 1], data[inner]

def execute():
    numbers = [64, 34, 25, 12, 22, 11, 90]
    print("Original array:", numbers)
    reorder_sequence(numbers)
    print("Sorted array:", numbers)

if __name__ == "__main__":
    execute()