def check_prime(value):
    if value < 2:
        return False
    for i in range(2, value):
        if value % i == 0:
            return False
    return True

def get_primes(limit):
    output = []
    for n in range(2, limit + 1):
        if check_prime(n):
            output.append(n)
    return output

def execute():
    top = 50
    prime_list = get_primes(top)
    print(f"Prime numbers up to {top}: {prime_list}")

if __name__ == "__main__":
    execute()