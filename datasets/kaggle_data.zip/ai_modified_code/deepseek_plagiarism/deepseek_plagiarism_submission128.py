class Item:
    def __init__(self, name, creator, cost):
        self.name = name
        self.creator = creator
        self.cost = cost

    def show(self):
        print(f"Title: {self.name}, Author: {self.creator}, Price: ${self.cost}")

def insert_item(collection, name, creator, cost):
    new_item = Item(name, creator, cost)
    collection.append(new_item)

def find_item(collection, name):
    for item in collection:
        if item.name == name:
            item.show()

def display_all(collection):
    for item in collection:
        item.show()

def start():
    collection = []
    insert_item(collection, "The Great Gatsby", "F. Scott Fitzgerald", 8.99)
    insert_item(collection, "1984", "George Orwell", 9.99)
    print("Books available in the store:")
    display_all(collection)
    print("\nSearching for '1984':")
    find_item(collection, "1984")

if __name__ == "__main__":
    start()