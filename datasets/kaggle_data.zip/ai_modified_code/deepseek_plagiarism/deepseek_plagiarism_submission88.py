def restructure(data, size, root):
    max_index = root
    left_child = 2 * root + 1
    right_child = 2 * root + 2

    if left_child < size and data[left_child] > data[max_index]:
        max_index = left_child

    if right_child < size and data[right_child] > data[max_index]:
        max_index = right_child

    if max_index != root:
        data[root], data[max_index] = data[max_index], data[root]
        restructure(data, size, max_index)

def order_heap(sequence):
    length = len(sequence)

    for j in range(length // 2 - 1, -1, -1):
        restructure(sequence, length, j)

    for k in range(length - 1, 0, -1):
        sequence[k], sequence[0] = sequence[0], sequence[k]
        restructure(sequence, k, 0)

def execute():
    values = [12, 11, 13, 5, 6, 7]
    print("Original array:", values)
    order_heap(values)
    print("Sorted array:", values)

if __name__ == "__main__":
    execute()