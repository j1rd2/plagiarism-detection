def combine(x, y):
    total = x + y
    return total