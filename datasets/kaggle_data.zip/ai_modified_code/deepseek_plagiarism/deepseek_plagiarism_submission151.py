class Item:
    def __init__(self, title, author, price, genre):
        self.title = title
        self.author = author
        self.price = price
        self.genre = genre

    def display_info(self):
        print(f"Title: {self.title}, Author: {self.author}, Price: ${self.price}, Genre: {self.genre}")

def insert_item(collection, title, author, price, genre):
    new_item = Item(title, author, price, genre)
    collection.append(new_item)

def show_collection(collection):
    for item in collection:
        item.display_info()

def run_program():
    collection = []
    insert_item(collection, "The Power of Now", "Eckhart Tolle", 12.99, "Self-help")
    insert_item(collection, "Homo Deus", "Yuval Noah Harari", 18.99, "Non-fiction")
    print("Publications in the inventory with category info:")
    show_collection(collection)

if __name__ == "__main__":
    run_program()