import logging

def check_value(x):
    return isinstance(x, int) and x >= 0

def calculate_fact(y):
    if y == 0:
        return 1
    else:
        return y * calculate_fact(y - 1)

def save_output(a, b):
    logging.basicConfig(filename='factorial_calculations.log', level=logging.INFO)
    logging.info(f"Computed factorial of {a}: {b}")

def handle_factorial():
    try:
        user_input = int(input("Please enter a non-negative integer: "))
        if not check_value(user_input):
            raise ValueError("Only non-negative integers are accepted.")
        output = calculate_fact(user_input)
        save_output(user_input, output)
        print(f"Factorial of {user_input} is {output}")
    except ValueError as e:
        print(e)

def run():
    while True:
        handle_factorial()
        again = input("Would you like to calculate another factorial? (yes/no): ")
        if again.lower() != 'yes':
            break

if __name__ == "__main__":
    run()