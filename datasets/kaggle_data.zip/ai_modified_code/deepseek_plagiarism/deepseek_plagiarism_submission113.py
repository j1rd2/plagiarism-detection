import sqlite3

def link_database(db_path):
    link = sqlite3.connect(db_path)
    return link

def build_table(link):
    table_sql = """CREATE TABLE IF NOT EXISTS customers (
                    customer_id integer PRIMARY KEY,
                    full_name text NOT NULL,
                    customer_age integer
                );"""
    try:
        executor = link.cursor()
        executor.execute(table_sql)
    except sqlite3.Error as err:
        print(err)

def add_entry(link, entry_data):
    insert_sql = ''' INSERT INTO customers(full_name, customer_age)
                     VALUES(?,?) '''
    cursor = link.cursor()
    cursor.execute(insert_sql, entry_data)
    link.commit()
    return cursor.lastrowid

def fetch_all_entries(link):
    cursor = link.cursor()
    cursor.execute("SELECT * FROM customers")
    results = cursor.fetchall()
    for result in results:
        print(result)

def execute():
    db_path = "customers.db"
    link = link_database(db_path)
    with link:
        build_table(link)
        entry = ('Alice', 32)
        add_entry(link, entry)
        print("Customers in the database:")
        fetch_all_entries(link)

if __name__ == '__main__':
    execute()