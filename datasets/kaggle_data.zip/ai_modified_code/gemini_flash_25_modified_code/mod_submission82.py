def perform_sorting(data_list):
    list_size = len(data_list)
    for outer_pass in range(list_size):
        for inner_comparison in range(0, list_size - outer_pass - 1):
            if data_list[inner_comparison] > data_list[inner_comparison + 1]:
                data_list[inner_comparison], data_list[inner_comparison + 1] = data_list[inner_comparison + 1], data_list[inner_comparison]

def initialize_and_run():
    initial_sequence = [64, 34, 25, 12, 22, 11, 90]
    print("Initial sequence:", initial_sequence)
    perform_sorting(initial_sequence)
    print("Processed sequence:", initial_sequence)

if __name__ == "__main__":
    initialize_and_run()