from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

def prepare_data():
    dataset = load_iris()
    features = dataset.data
    labels = dataset.target
    return features, labels

def split_data(all_features, all_labels):
    features_train, features_test, labels_train, labels_test = train_test_split(all_features, all_labels, test_size=0.3, random_state=42)
    return features_train, features_test, labels_train, labels_test

def build_and_train_model(train_features, train_labels):
    classifier = RandomForestClassifier(n_estimators=100, random_state=42)
    classifier.fit(train_features, train_labels)
    return classifier

def save_model(trained_model, filename):
    joblib.dump(trained_model, filename)

if __name__ == "__main__":
    input_features, target_labels = prepare_data()
    training_features, testing_features, training_labels, testing_labels = split_data(input_features, target_labels)
    trained_classifier = build_and_train_model(training_features, training_labels)
    save_model(trained_classifier, 'random_forest_model.pkl')