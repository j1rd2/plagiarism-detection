def calculate_squares(data_list):
    return list(map(lambda element: element * element, data_list))

def process_data_file(input_filepath, output_filepath):
    raw_data = get_data_from_source(input_filepath)
    processed_data = calculate_squares(raw_data)
    save_processed_data(processed_data, output_filepath)
    print(f"Results are stored in {output_filepath}")

def get_data_from_source(source_path):
    with open(source_path, 'r') as handler:
        data_entries = list(map(int, handler.readlines()))
    return data_entries

def save_processed_data(data_entries, destination_path):
    with open(destination_path, 'w') as handler:
        handler.writelines(f"{entry}\n" for entry in data_entries)

if __name__ == "__main__":
    process_data_file('input.txt', 'output.txt')