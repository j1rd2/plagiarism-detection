import openpyxl

def process_data_to_excel(file_name):
    data_workbook = openpyxl.Workbook()
    data_sheet = data_workbook.active
    
    data_sheet["C1"] = "Item"
    data_sheet["D1"] = "Quantity"
    
    data_sheet["C2"] = "Apple"
    data_sheet["D2"] = 150
    
    data_sheet["C3"] = "Banana"
    data_sheet["D3"] = 200
    
    data_workbook.save(file_name)
    print(f"Report '{file_name}' has been generated.")

def initiate_process():
    process_data_to_excel("inventory_report.xlsx")

if __name__ == "__main__":
    initiate_process()