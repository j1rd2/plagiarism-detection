import openpyxl

def populate_sheet_with_inventory(excel_file_name):
    workbook_object = openpyxl.Workbook()
    current_sheet = workbook_object.active
    
    current_sheet['A1'] = "Item"
    current_sheet['B1'] = "Cost"
    
    current_sheet['A2'] = "Tablet"
    current_sheet['B2'] = 299.50
    
    current_sheet['A3'] = "Headphones"
    current_sheet['B3'] = 150.75
    
    workbook_object.save(excel_file_name)
    print(f"File '{excel_file_name}' generated with inventory details.")

def run_process():
    populate_sheet_with_inventory("inventory.xlsx")

if __name__ == "__main__":
    run_process()