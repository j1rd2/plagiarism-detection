class HandheldGadget:
    def __init__(self, manufacturer, product_name, system_version):
        self.manufacturer = manufacturer
        self.product_name = product_name
        self.system_version = system_version

    def show_specs(self):
        print(f"Manufacturer: {self.manufacturer}, Product: {self.product_name}, Version: {self.system_version}")

def register_gadget(gadget_collection, brand, model, os_version):
    new_gadget = HandheldGadget(brand, model, os_version)
    gadget_collection.append(new_gadget)

def present_gadgets(gadget_collection):
    for gadget in gadget_collection:
        gadget.show_specs()

def orchestrate_gadgets():
    gadget_inventory = []
    register_gadget(gadget_inventory, "Apple", "iPhone 13", "iOS 15")
    register_gadget(gadget_inventory, "Samsung", "Galaxy S21", "Android 11")
    
    print("Inventory of handheld gadgets:")
    present_gadgets(gadget_inventory)

if __name__ == "__main__":
    orchestrate_gadgets()