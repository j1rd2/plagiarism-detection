import json

def retrieve_employee_data(filepath):
    with open(filepath, 'r') as file_handle:
        dataset = json.load(file_handle)
    return dataset['employees']

def filter_by_department(target_department):
    def predicate_function(individual_employee):
        return individual_employee['department'] == target_department
    return predicate_function

def extract_salary(individual_employee):
    return individual_employee['salary']

def compute_average(values_list):
    if not values_list:
        return 0
    return sum(values_list) / len(values_list)

def persist_to_json(content, destination_file):
    with open(destination_file, 'w') as file_handle:
        json.dump(content, file_handle, indent=4)

def process_employee_information():
    input_filename = 'employees.json'
    output_filename = 'department_summary.json'
    target_department_name = 'Engineering'

    all_employees = retrieve_employee_data(input_filename)
    engineers = list(filter(filter_by_department(target_department_name), all_employees))
    engineer_salaries = list(map(extract_salary, engineers))
    average_engineer_salary = compute_average(engineer_salaries)
    
    summary_data = {
        'department': target_department_name,
        'average_salary': average_engineer_salary,
        'employee_count': len(engineers)
    }

    persist_to_json(summary_data, output_filename)
    print(f"Output saved to {output_filename}")

if __name__ == "__main__":
    process_employee_information()