def translate_nucleic_acid(nucleic_acid_string):
    amino_acid_map = {
        'AUG': 'M', 'UUU': 'F', 'UUC': 'F', 'UUA': 'L', 'UUG': 'L',
        'CUU': 'L', 'CUC': 'L', 'CUA': 'L', 'CUG': 'L', 'AUU': 'I',
        'AUC': 'I', 'AUA': 'I', 'GUU': 'V', 'GUC': 'V', 'GUA': 'V',
        'GUG': 'V', 'UCU': 'S', 'UCC': 'S', 'UCA': 'S', 'UCG': 'S',
        'CCU': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P', 'ACU': 'T',
        'ACC': 'T', 'ACA': 'T', 'ACG': 'T', 'GCU': 'A', 'GCC': 'A',
        'GCA': 'A', 'GCG': 'A', 'UAU': 'Y', 'UAC': 'Y', 'UGU': 'C',
        'UGC': 'C', 'UGG': 'W', 'CAA': 'Q', 'CAG': 'Q', 'AAU': 'N',
        'AAC': 'N', 'AAA': 'K', 'AAG': 'K', 'GAU': 'D', 'GAC': 'D',
        'GAA': 'E', 'GAG': 'E', 'UGA': 'Stop', 'UAA': 'Stop', 'UAG': 'Stop'
    }
    
    translated_chain = ""
    for index in range(0, len(nucleic_acid_string), 3):
        triplet = nucleic_acid_string[index:index+3]
        translated_chain += amino_acid_map.get(triplet, '')
    return translated_chain

def execute_translation():
    input_rna = "AUGUUUCUAUAG"
    resulting_protein = translate_nucleic_acid(input_rna)
    print("Original RNA sequence:", input_rna)
    print("Translated protein sequence:", resulting_protein)

if __name__ == "__main__":
    execute_translation()