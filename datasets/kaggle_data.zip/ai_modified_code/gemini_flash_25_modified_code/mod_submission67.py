class PatientRecord:
    def __init__(self, record_identifier, person_name, person_age, medical_condition):
        self.record_identifier = record_identifier
        self.person_name = person_name
        self.person_age = person_age
        self.medical_condition = medical_condition

class ScheduledEvent:
    def __init__(self, event_identifier, assigned_patient, medical_practitioner, event_date):
        self.event_identifier = event_identifier
        self.assigned_patient = assigned_patient
        self.medical_practitioner = medical_practitioner
        self.event_date = event_date

class HealthcareSystem:
    def __init__(self):
        self.all_patients = []
        self.all_appointments = []

    def enroll_patient(self, patient):
        self.all_patients.append(patient)

    def book_appointment(self, appointment):
        self.all_appointments.append(appointment)

    def display_patient_roster(self):
        for patient in self.all_patients:
            print(f"ID: {patient.record_identifier}, Name: {patient.person_name}, Age: {patient.person_age}, Ailment: {patient.medical_condition}")

    def display_scheduled_events(self):
        for appointment in self.all_appointments:
            print(f"Appointment ID: {appointment.event_identifier}, Patient: {appointment.assigned_patient.person_name}, Doctor: {appointment.medical_practitioner}, Date: {appointment.event_date}")

def startup_process():
    healthcare_management = HealthcareSystem()

    patient_alpha = PatientRecord(1, "John Doe", 45, "Flu")
    patient_beta = PatientRecord(2, "Jane Smith", 30, "Cough")

    healthcare_management.enroll_patient(patient_alpha)
    healthcare_management.enroll_patient(patient_beta)

    appointment_one = ScheduledEvent(1, patient_alpha, "Dr. Alice", "2024-09-15")
    appointment_two = ScheduledEvent(2, patient_beta, "Dr. Bob", "2024-09-16")

    healthcare_management.book_appointment(appointment_one)
    healthcare_management.book_appointment(appointment_two)

    print("Patient Roster:")
    healthcare_management.display_patient_roster()

    print("\nScheduled Events:")
    healthcare_management.display_scheduled_events()

if __name__ == "__main__":
    startup_process()