import threading
import time

def perform_counting():
    for count in range(5):
        print(f"Worker Thread: {count}")
        time.sleep(1)

def initiate_process():
    worker_thread = threading.Thread(target=perform_counting)
    worker_thread.start()
    worker_thread.join()

if __name__ == "__main__":
    initiate_process()