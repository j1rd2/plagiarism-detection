from flask import Flask as WebFramework

application = WebFramework(__name__)

@application.route('/')
def greet_user():
    return 'Hello, World!'

if __name__ == '__main__':
    application.run(debug=True)