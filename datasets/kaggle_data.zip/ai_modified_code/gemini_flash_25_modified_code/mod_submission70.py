def register_individual(individuals, individual_identifier, full_name, years, condition):
    individuals.append({"Identifier": individual_identifier, "FullName": full_name, "Years": years, "Condition": condition})

def book_session(sessions, session_identifier, individual, medical_practitioner, appointment_time):
    sessions.append({"SessionID": session_identifier, "Individual": individual, "Practitioner": medical_practitioner, "Time": appointment_time})

def display_individuals(individuals):
    for person in individuals:
        print(f"Identifier: {person['Identifier']}, FullName: {person['FullName']}, Years: {person['Years']}, Condition: {person['Condition']}")

def display_sessions(sessions):
    for booking in sessions:
        print(f"Session ID: {booking['SessionID']}, Individual: {booking['Individual']['FullName']}, Practitioner: {booking['Practitioner']}, Time: {booking['Time']}")

def run_system():
    individuals_list = []
    sessions_list = []

    register_individual(individuals_list, 1, "George Clooney", 50, "Vision Problems")
    register_individual(individuals_list, 2, "Brad Pitt", 45, "Migraine")

    book_session(sessions_list, 1, individuals_list[0], "Dr. Johnson", "2024-09-30")
    book_session(sessions_list, 2, individuals_list[1], "Dr. Williams", "2024-10-01")

    print("Individuals:")
    display_individuals(individuals_list)

    print("\nSessions:")
    display_sessions(sessions_list)

if __name__ == "__main__":
    run_system()