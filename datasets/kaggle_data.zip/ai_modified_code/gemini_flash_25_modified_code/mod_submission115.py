import sqlite3

def establish_database_link(database_path):
    connection = sqlite3.connect(database_path)
    return connection

def initialize_employee_data_structure(db_connection):
    create_employees_statement = """CREATE TABLE IF NOT EXISTS employees (
                                        id integer PRIMARY KEY,
                                        name text NOT NULL,
                                        age integer
                                    );"""
    try:
        cursor = db_connection.cursor()
        cursor.execute(create_employees_statement)
    except sqlite3.Error as err:
        print(err)

def add_new_worker(db_connection, worker_details):
    insert_statement = ''' INSERT INTO employees(name, age)
              VALUES(?,?) '''
    worker_cursor = db_connection.cursor()
    worker_cursor.execute(insert_statement, worker_details)
    db_connection.commit()
    return worker_cursor.lastrowid

def retrieve_all_workers(db_connection):
    worker_cursor = db_connection.cursor()
    worker_cursor.execute("SELECT * FROM employees")

    all_workers = worker_cursor.fetchall()
    for worker_record in all_workers:
        print(worker_record)

def run_operations():
    db_file_name = "company.db"

    connection_object = establish_database_link(db_file_name)
    with connection_object:
        initialize_employee_data_structure(connection_object)
        new_employee_data = ('Alice', 30)
        add_new_worker(connection_object, new_employee_data)
        print("Current list of employees:")
        retrieve_all_workers(connection_object)

if __name__ == '__main__':
    run_operations()