class MedicalCenter:
    def __init__(self):
        self.registered_individuals = {}
        self.scheduled_visits = {}

    def enroll_individual(self, individual_id, full_name, years_old, health_issue):
        self.registered_individuals[individual_id] = {"FullName": full_name, "Age": years_old, "Condition": health_issue}

    def book_visit(self, visit_id, individual_id, physician, visit_date):
        if individual_id in self.registered_individuals:
            self.scheduled_visits[visit_id] = {
                "PatientName": self.registered_individuals[individual_id]["FullName"],
                "Physician": physician,
                "Date": visit_date
            }
        else:
            print(f"No individual found with ID {individual_id}")

    def display_individuals(self):
        for individual_id, details in self.registered_individuals.items():
            print(f"ID: {individual_id}, Name: {details['FullName']}, Age: {details['Age']}, Ailment: {details['Condition']}")

    def display_visits(self):
        for visit_id, details in self.scheduled_visits.items():
            print(f"Visit ID: {visit_id}, Patient: {details['PatientName']}, Doctor: {details['Physician']}, Date: {details['Date']}")

def initialize_operations():
    clinic = MedicalCenter()

    clinic.enroll_individual(101, "Mark Spencer", 40, "Back Pain")
    clinic.enroll_individual(102, "Lucy Hale", 35, "Allergy")

    clinic.book_visit(1, 101, "Dr. Green", "2024-09-20")
    clinic.book_visit(2, 102, "Dr. White", "2024-09-21")

    print("Individual Registry:")
    clinic.display_individuals()

    print("\nScheduled Visits:")
    clinic.display_visits()

if __name__ == "__main__":
    initialize_operations()