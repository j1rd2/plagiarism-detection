import random

def generate_altered_genome(original_genome, alteration_frequency=0.01):
    bases = ['A', 'T', 'C', 'G']
    modified_genome_list = list(original_genome)
    
    for index in range(len(modified_genome_list)):
        if random.random() < alteration_frequency:
            modified_genome_list[index] = random.choice(bases)
    
    return ''.join(modified_genome_list)

def initiate_process():
    initial_genome = "ATGCTAGCTAGT"
    altered_genome = generate_altered_genome(initial_genome, alteration_frequency=0.05)
    print("Baseline genome:", initial_genome)
    print("Altered genome:", altered_genome)

if __name__ == "__main__":
    initiate_process()