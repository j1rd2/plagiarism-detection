import csv

def get_student_data(source_path):
    student_records = []
    with open(source_path, mode='r') as csv_file:
        data_reader = csv.DictReader(csv_file)
        for record in data_reader:
            processed_record = {
                'student_name': record['Name'],
                'student_score': float(record['Score'])
            }
            student_records.append(processed_record)
    return student_records

def determine_overall_average(student_list):
    total_scores = sum(student['student_score'] for student in student_list)
    if not student_list:
        return 0
    return total_scores / len(student_list)

def classify_grades(student_list, pass_threshold):
    for student in student_list:
        if student['student_score'] >= pass_threshold:
            student['student_grade'] = 'A'
        else:
            student['student_grade'] = 'B'
    return student_list

def output_processed_data(student_list, destination_path):
    with open(destination_path, mode='w', newline='') as csv_file:
        field_names = ['Name', 'Score', 'Grade']
        data_writer = csv.DictWriter(csv_file, fieldnames=field_names)
        data_writer.writeheader()
        for student in student_list:
            data_writer.writerow(student)

def execute_processing():
    source_csv = 'students.csv'
    destination_csv = 'graded_students.csv'
    all_students = get_student_data(source_csv)
    class_average = determine_overall_average(all_students)
    graded_students = classify_grades(all_students, class_average)
    output_processed_data(graded_students, destination_csv)
    print(f"Processed student data written to {destination_csv}")

if __name__ == "__main__":
    execute_processing()