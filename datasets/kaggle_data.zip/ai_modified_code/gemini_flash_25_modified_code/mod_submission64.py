import xml.etree.ElementTree as ET

class Volume:
    def __init__(self, label, creator, publication_year, cost):
        self.label = label
        self.creator = creator
        self.publication_year = publication_year
        self.cost = cost

class LibraryCatalog:
    def __init__(self, source_document):
        self.source_document = source_document
        self.cataloged_volumes = []

    def ingest_data(self):
        document_tree = ET.parse(self.source_document)
        root_element = document_tree.getroot()
        for volume_element in root_element.findall('volume'):
            title_text = volume_element.find('title').text
            author_text = volume_element.find('author').text
            year_value = int(volume_element.find('year').text)
            price_value = float(volume_element.find('price').text)
            self.cataloged_volumes.append(Volume(title_text, author_text, year_value, price_value))

    def select_recent_volumes(self, cutoff_year):
        return [vol for vol in self.cataloged_volumes if vol.publication_year > cutoff_year]

    def compute_average_value(self, volumes_list):
        total_value = sum(vol.cost for vol in volumes_list)
        return total_value / len(volumes_list) if volumes_list else 0

    def generate_report(self, relevant_volumes, avg_value, destination_file):
        report_root = ET.Element('catalogReport')
        avg_value_element = ET.SubElement(report_root, 'averageCost')
        avg_value_element.text = str(avg_value)
        for vol in relevant_volumes:
            vol_element = ET.SubElement(report_root, 'volume')
            ET.SubElement(vol_element, 'title').text = vol.label
            ET.SubElement(vol_element, 'author').text = vol.creator
            ET.SubElement(vol_element, 'year').text = str(vol.publication_year)
            ET.SubElement(vol_element, 'price').text = str(vol.cost)

        report_tree = ET.ElementTree(report_root)
        report_tree.write(destination_file)

def execute_workflow():
    input_data_file = 'books.xml'
    output_report_file = 'summary_books.xml'
    minimum_year = 2000

    catalog_manager = LibraryCatalog(input_data_file)
    catalog_manager.ingest_data()
    recent_volumes = catalog_manager.select_recent_volumes(minimum_year)
    average_cost = catalog_manager.compute_average_value(recent_volumes)
    catalog_manager.generate_report(recent_volumes, average_cost, output_report_file)
    print(f"Catalog summary generated at {output_report_file}")

if __name__ == "__main__":
    execute_workflow()