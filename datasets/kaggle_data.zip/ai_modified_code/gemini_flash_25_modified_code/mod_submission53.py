import csv

class Learner:
    def __init__(self, learner_name, marks):
        self.learner_name = learner_name
        self.marks = marks
        self.performance_level = None

    def set_performance_level(self, reference_marks):
        self.performance_level = 'Pass' if self.marks >= reference_marks else 'Fail'

class DataHandler:
    def __init__(self, source_path):
        self.source_path = source_path
        self.learner_records = []

    def ingest_data(self):
        with open(self.source_path, 'r') as data_stream:
            data_reader = csv.DictReader(data_stream)
            for record in data_reader:
                learner = Learner(record['Name'], float(record['Score']))
                self.learner_records.append(learner)

    def compute_mean_marks(self):
        total_marks = sum(learner.marks for learner in self.learner_records)
        return total_marks / len(self.learner_records)

    def assign_levels(self, mean_marks):
        for learner in self.learner_records:
            learner.set_performance_level(mean_marks)

    def export_output(self, target_path):
        with open(target_path, 'w', newline='') as output_stream:
            output_writer = csv.writer(output_stream)
            output_writer.writerow(['Name', 'Score', 'Grade'])
            for learner in self.learner_records:
                output_writer.writerow([learner.learner_name, learner.marks, learner.performance_level])

def orchestrate_process():
    input_data_file = 'students.csv'
    output_data_file = 'graded_students.csv'
    data_manager = DataHandler(input_data_file)
    data_manager.ingest_data()
    mean_marks_value = data_manager.compute_mean_marks()
    data_manager.assign_levels(mean_marks_value)
    data_manager.export_output(output_data_file)
    print(f"Processing complete. Results saved to {output_data_file}")

if __name__ == "__main__":
    orchestrate_process()