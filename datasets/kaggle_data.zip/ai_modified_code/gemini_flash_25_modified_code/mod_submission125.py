class Gadget:
    def __init__(self, maker, name, system_version):
        self.maker = maker
        self.name = name
        self.system_version = system_version

    def show_details(self):
        print(f"Maker: {self.maker}, Name: {self.name}, System Version: {self.system_version}")

    def upgrade_system(self, latest_version):
        self.system_version = latest_version

def register_gadget(gadget_list, maker, name, system_version):
    new_gadget = Gadget(maker, name, system_version)
    gadget_list.append(new_gadget)

def modify_gadget_system(gadget_list, name, latest_version):
    for gadget in gadget_list:
        if gadget.name == name:
            gadget.upgrade_system(latest_version)

def display_all_gadgets(gadget_list):
    for gadget in gadget_list:
        gadget.show_details()

def orchestrator():
    gadget_collection = []
    register_gadget(gadget_collection, "Apple", "iPhone 13", "iOS 15")
    register_gadget(gadget_collection, "Samsung", "Galaxy S21", "Android 11")
    
    print("Gadget inventory prior to system upgrade:")
    display_all_gadgets(gadget_collection)
    
    modify_gadget_system(gadget_collection, "Galaxy S21", "Android 12")
    
    print("Gadget inventory post system upgrade:")
    display_all_gadgets(gadget_collection)

if __name__ == "__main__":
    orchestrator()