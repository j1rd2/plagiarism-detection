account_holdings = {}
employee_records = {}

def register_account(account_identifier, account_holder_name, initial_deposit):
    account_holdings[account_identifier] = {"Holder": account_holder_name, "Funds": initial_deposit}

def hire_employee(employee_identifier, full_name, job_title):
    employee_records[employee_identifier] = {"Name": full_name, "Role": job_title}

def credit_account(account_identifier, transaction_amount):
    if account_identifier in account_holdings:
        account_holdings[account_identifier]["Funds"] += transaction_amount
    else:
        print("Account not found.")

def debit_account(account_identifier, transaction_amount):
    if account_identifier in account_holdings:
        if account_holdings[account_identifier]["Funds"] >= transaction_amount:
            account_holdings[account_identifier]["Funds"] -= transaction_amount
        else:
            print("Insufficient funds.")
    else:
        print("Account not found.")

def display_accounts():
    for account_identifier, details in account_holdings.items():
        print(f"ID: {account_identifier}, Name: {details['Holder']}, Balance: ${details['Funds']}")

def display_staff():
    for employee_identifier, details in employee_records.items():
        print(f"ID: {employee_identifier}, Name: {details['Name']}, Position: {details['Role']}")

def initiate_operations():
    register_account(1, "Emma", 3000)
    register_account(2, "John", 4000)

    hire_employee(101, "Lisa", "Manager")
    hire_employee(102, "Tom", "Teller")

    credit_account(1, 500)
    debit_account(2, 1000)

    print("Account Summary:")
    display_accounts()

    print("\nEmployee Directory:")
    display_staff()

if __name__ == "__main__":
    initiate_operations()