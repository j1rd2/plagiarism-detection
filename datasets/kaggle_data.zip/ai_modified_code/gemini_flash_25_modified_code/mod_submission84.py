def process_list(data_collection):
    for index in range(1, len(data_collection)):
        current_element = data_collection[index]
        previous_index = index - 1
        while previous_index >= 0 and current_element < data_collection[previous_index]:
            data_collection[previous_index + 1] = data_collection[previous_index]
            previous_index -= 1
        data_collection[previous_index + 1] = current_element

def run_sorting_process():
    initial_sequence = [12, 11, 13, 5, 6]
    print("Initial sequence:", initial_sequence)
    process_list(initial_sequence)
    print("Sorted sequence:", initial_sequence)

if __name__ == "__main__":
    run_sorting_process()