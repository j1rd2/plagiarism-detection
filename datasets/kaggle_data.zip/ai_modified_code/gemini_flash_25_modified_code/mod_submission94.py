class Element:
    def __init__(self, value):
        self.value = value
        self.pointer = None

class Sequence:
    def __init__(self):
        self.front = None

    def add_to_tail(self, value):
        new_element = Element(value)
        if not self.front:
            self.front = new_element
            return
        current_element = self.front
        while current_element.pointer:
            current_element = current_element.pointer
        current_element.pointer = new_element

    def remove_element(self, target_value):
        temp_element = self.front
        if temp_element is not None:
            if temp_element.value == target_value:
                self.front = temp_element.pointer
                temp_element = None
                return
        while temp_element is not None:
            if temp_element.value == target_value:
                break
            previous_element = temp_element
            temp_element = temp_element.pointer
        if temp_element is None:
            return
        previous_element.pointer = temp_element.pointer
        temp_element = None

    def display_sequence(self):
        current_element = self.front
        while current_element:
            print(current_element.value, end=" -> ")
            current_element = current_element.pointer
        print("None")

def initialize_and_process():
    my_sequence = Sequence()
    my_sequence.add_to_tail(10)
    my_sequence.add_to_tail(20)
    my_sequence.add_to_tail(30)
    my_sequence.display_sequence()
    my_sequence.remove_element(20)
    my_sequence.display_sequence()

if __name__ == "__main__":
    initialize_and_process()