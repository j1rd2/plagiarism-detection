class AccountHolder:
    def __init__(self, identifier, account_name, current_balance):
        self.account_id = identifier
        self.holder_name = account_name
        self.available_balance = current_balance
        self.outstanding_loans = 0

    def credit(self, transaction_amount):
        self.available_balance += transaction_amount

    def debit(self, transaction_amount):
        if transaction_amount <= self.available_balance:
            self.available_balance -= transaction_amount
        else:
            print("Insufficient funds.")

    def request_loan(self, loan_amount):
        self.outstanding_loans += loan_amount
        self.available_balance += loan_amount

class FinancialInstitution:
    def __init__(self):
        self.account_records = {}

    def register_account(self, account):
        self.account_records[account.account_id] = account

    def search_account(self, account_id):
        return self.account_records.get(account_id, None)

    def display_all_accounts(self):
        for account in self.account_records.values():
            print(f"ID: {account.account_id}, Name: {account.holder_name}, Balance: ${account.available_balance}, Loans: ${account.outstanding_loans}")

def run_operations():
    institution = FinancialInstitution()

    person1 = AccountHolder(101, "Alice", 1000)
    person2 = AccountHolder(102, "Bob", 1500)

    institution.register_account(person1)
    institution.register_account(person2)

    person1.credit(500)
    person2.debit(200)
    person1.request_loan(300)

    print("Account Overview:")
    institution.display_all_accounts()

if __name__ == "__main__":
    run_operations()