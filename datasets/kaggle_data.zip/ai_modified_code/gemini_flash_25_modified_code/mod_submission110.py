from flask import Flask

server_instance = Flask(__name__)

@server_instance.route('/')
def greet_world():
    return 'Hello, World!'

@server_instance.route('/info')
def display_info():
    return 'This is the About page.'

if __name__ == '__main__':
    server_instance.run(debug=True)