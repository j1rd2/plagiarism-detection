class AccountHolder:
    def __init__(self, acc_id, holder_name, current_balance):
        self.acc_id = acc_id
        self.holder_name = holder_name
        self.current_balance = current_balance

    def add_funds(self, transaction_amount):
        self.current_balance += transaction_amount

    def remove_funds(self, transaction_amount):
        if transaction_amount <= self.current_balance:
            self.current_balance -= transaction_amount
        else:
            print("Insufficient funds.")

class FinancialInstitution:
    def __init__(self):
        self.account_records = {}

    def register_account(self, account_holder):
        self.account_records[account_holder.acc_id] = account_holder

    def search_account(self, account_identifier):
        return self.account_records.get(account_identifier, None)

    def display_all_accounts(self):
        for account in self.account_records.values():
            print(f"ID: {account.acc_id}, Name: {account.holder_name}, Balance: ${account.current_balance}")

def run_simulation():
    my_bank = FinancialInstitution()

    client_one = AccountHolder(101, "Charlie", 5000)
    client_two = AccountHolder(102, "Diana", 7500)

    my_bank.register_account(client_one)
    my_bank.register_account(client_two)

    client_one.add_funds(1000)
    client_two.remove_funds(500)

    print("Account Records:")
    my_bank.display_all_accounts()

if __name__ == "__main__":
    run_simulation()