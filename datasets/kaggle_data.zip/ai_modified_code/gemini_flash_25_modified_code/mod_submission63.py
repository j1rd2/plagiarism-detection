from lxml import etree

def extract_data_from_xml(path_to_xml):
    xml_tree = etree.parse(path_to_xml)
    xml_root = xml_tree.getroot()
    book_list = []
    for current_book_node in xml_root.xpath('//book'):
        book_list.append({
            'title': current_book_node.find('title').text,
            'author': current_book_node.find('author').text,
            'year': int(current_book_node.find('year').text),
            'price': float(current_book_node.find('price').text)
        })
    return book_list

def select_books_after_year(all_books, cutoff_year):
    return [book_record for book_record in all_books if book_record['year'] > cutoff_year]

def compute_average(collection_of_books):
    if not collection_of_books:
        return 0
    total_cost = sum(book_record['price'] for book_record in collection_of_books)
    return total_cost / len(collection_of_books)

def generate_summary_xml(books_to_summarize, computed_avg_price, destination_file):
    summary_root = etree.Element('bookSummary')
    avg_price_element = etree.SubElement(summary_root, 'averagePrice')
    avg_price_element.text = str(computed_avg_price)
    for book_data in books_to_summarize:
        book_element = etree.SubElement(summary_root, 'book')
        title_element = etree.SubElement(book_element, 'title')
        title_element.text = book_data['title']
        author_element = etree.SubElement(book_element, 'author')
        author_element.text = book_data['author']
        year_element = etree.SubElement(book_element, 'year')
        year_element.text = str(book_data['year'])
        price_element = etree.SubElement(book_element, 'price')
        price_element.text = str(book_data['price'])

    output_tree = etree.ElementTree(summary_root)
    output_tree.write(destination_file, pretty_print=True)

def execute_process():
    source_xml_file = 'books.xml'
    target_xml_file = 'recent_books.xml'
    year_threshold = 2000

    parsed_books = extract_data_from_xml(source_xml_file)
    relevant_books = select_books_after_year(parsed_books, year_threshold)
    average_selling_price = compute_average(relevant_books)
    generate_summary_xml(relevant_books, average_selling_price, target_xml_file)
    print(f"XML output saved to {target_xml_file}")

if __name__ == "__main__":
    execute_process()