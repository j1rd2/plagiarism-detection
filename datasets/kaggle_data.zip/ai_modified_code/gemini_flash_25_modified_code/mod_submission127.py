class ReadingMaterial:
    def __init__(self, subject, creator, cost):
        self.subject = subject
        self.creator = creator
        self.cost = cost

    def show_details(self):
        print(f"Title: {self.subject}, Author: {self.creator}, Price: ${self.cost}")

def incorporate_item(collection, subject, creator, cost):
    item = ReadingMaterial(subject, creator, cost)
    collection.append(item)

def present_items(collection):
    for item in collection:
        item.show_details()

def start_process():
    inventory = []
    incorporate_item(inventory, "The Great Gatsby", "F. Scott Fitzgerald", 9.50)
    incorporate_item(inventory, "1984", "George Orwell", 8.75)
    
    print("Inventory of items:")
    present_items(inventory)

if __name__ == "__main__":
    start_process()