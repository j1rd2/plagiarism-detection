import json

def retrieve_staff_info(source_file):
    with open(source_file, 'r') as data_stream:
        parsed_data = json.load(data_stream)
    return parsed_data['staff_records']

def select_by_team(staff_list, team_name):
    return [member for member in staff_list if member['team'] == team_name]

def calculate_mean_remuneration(staff_list):
    if not staff_list:
        return 0
    total_remuneration = sum(member['remuneration'] for member in staff_list)
    return total_remuneration / len(staff_list)

def output_findings_to_json(analysis_results, destination_file):
    with open(destination_file, 'w') as output_stream:
        json.dump(analysis_results, output_stream, indent=4)

def initiate_process():
    source_data_path = 'employees.json'
    report_path = 'department_summary.json'
    target_team = 'Engineering'

    all_staff = retrieve_staff_info(source_data_path)
    team_members = select_by_team(all_staff, target_team)
    mean_remuneration_for_team = calculate_mean_remuneration(team_members)
    team_overview = {
        'department': target_team,
        'average_salary': mean_remuneration_for_team,
        'employee_count': len(team_members)
    }

    output_findings_to_json(team_overview, report_path)
    print(f"Data written to {report_path}")

if __name__ == "__main__":
    initiate_process()