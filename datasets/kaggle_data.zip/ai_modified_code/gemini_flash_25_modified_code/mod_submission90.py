def traverse_graph(adj_list, current_node, seen_nodes=None):
    if seen_nodes is None:
        seen_nodes = set()
    seen_nodes.add(current_node)
    print(current_node, end=" ")

    for neighbor in adj_list[current_node] - seen_nodes:
        traverse_graph(adj_list, neighbor, seen_nodes)

def execute_traversal():
    adjacency_list = {
        'A': {'B', 'C'},
        'B': {'A', 'D', 'E'},
        'C': {'A', 'F'},
        'D': {'B'},
        'E': {'B', 'F'},
        'F': {'C', 'E'}
    }
    print("DFS starting from vertex A:")
    traverse_graph(adjacency_list, 'A')

if __name__ == "__main__":
    execute_traversal()