import threading
import time

def perform_numeric_task():
    for counter in range(5):
        print(f"Worker A: {counter}")
        time.sleep(1)

def perform_alphabetic_task():
    for symbol in "ABCDE":
        print(f"Worker B: {symbol}")
        time.sleep(0.5)

def orchestrate_tasks():
    worker_a = threading.Thread(target=perform_numeric_task)
    worker_b = threading.Thread(target=perform_alphabetic_task)
    
    worker_a.start()
    worker_b.start()
    
    worker_a.join()
    worker_b.join()

if __name__ == "__main__":
    orchestrate_tasks()