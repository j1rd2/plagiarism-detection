import json

def retrieve_data(source_path):
    with open(source_path, 'r') as data_stream:
        payload = json.load(data_stream)
    return payload['personnel']

def filter_personnel_by_unit(personnel_list, target_unit):
    selected_personnel = []
    for individual in personnel_list:
        if individual['unit'] == target_unit:
            selected_personnel.append(individual)
    return selected_personnel

def calculate_average_compensation(personnel_list):
    if not personnel_list:
        return 0
    total_compensation = sum(person['compensation'] for person in personnel_list)
    avg_compensation = total_compensation / len(personnel_list)
    return avg_compensation

def materialize_json_output(report_data, destination_path):
    with open(destination_path, 'w') as output_stream:
        json.dump(report_data, output_stream, indent=4)

def execute_process():
    source_file_path = 'employees.json'
    output_file_path = 'department_summary.json'
    target_department_name = 'Engineering'

    all_personnel = retrieve_data(source_file_path)
    personnel_in_target_unit = filter_personnel_by_unit(all_personnel, target_department_name)
    average_pay = calculate_average_compensation(personnel_in_target_unit)
    summary_report = {
        'department': target_department_name,
        'average_salary': average_pay,
        'employee_count': len(personnel_in_target_unit)
    }

    materialize_json_output(summary_report, output_file_path)
    print(f"Summary written to {output_file_path}")

if __name__ == "__main__":
    execute_process()