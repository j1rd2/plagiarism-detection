class Container:
    def __init__(self):
        self.elements = []

    def add_element(self, element):
        self.elements.append(element)

    def remove_last(self):
        if not self.check_empty():
            return self.elements.pop()
        return None

    def get_top(self):
        if not self.check_empty():
            return self.elements[-1]
        return None

    def check_empty(self):
        return len(self.elements) == 0

    def get_count(self):
        return len(self.elements)

def execute_operations():
    data_structure = Container()
    data_structure.add_element(10)
    data_structure.add_element(20)
    data_structure.add_element(30)
    print("Last element:", data_structure.get_top())
    print("Number of elements:", data_structure.get_count())
    data_structure.remove_last()
    print("Structure after removal:", data_structure.elements)

if __name__ == "__main__":
    execute_operations()