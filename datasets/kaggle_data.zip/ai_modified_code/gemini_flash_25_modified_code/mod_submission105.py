import random

def generate_mutated_genome(genome_string, chance_of_alteration=0.01):
    available_bases = ['A', 'T', 'C', 'G']
    genome_as_list = list(genome_string)
    alteration_log = []
    
    for index in range(len(genome_as_list)):
        if random.random() < chance_of_alteration:
            original_base = genome_as_list[index]
            random_base = random.choice(available_bases)
            genome_as_list[index] = random_base
            alteration_log.append((index, original_base, random_base))
    
    return ''.join(genome_as_list), alteration_log

def run_simulation():
    initial_genome = "ATGCTAGCTAGT"
    altered_genome, log_of_changes = generate_mutated_genome(initial_genome, chance_of_alteration=0.05)
    print("Starting genome:", initial_genome)
    print("Modified genome:", altered_genome)
    print("Alteration record:", log_of_changes)

if __name__ == "__main__":
    run_simulation()