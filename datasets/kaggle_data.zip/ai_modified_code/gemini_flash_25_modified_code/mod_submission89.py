from collections import deque

def explore_graph(adj_list, initial_node):
    discovered = set()
    traversal_queue = deque([initial_node])

    while traversal_queue:
        current_node = traversal_queue.popleft()
        if current_node not in discovered:
            print(current_node, end=" ")
            discovered.add(current_node)
            neighbors_to_visit = adj_list[current_node] - discovered
            traversal_queue.extend(neighbors_to_visit)

def setup_and_run():
    my_graph_representation = {
        'A': {'B', 'C'},
        'B': {'A', 'D', 'E'},
        'C': {'A', 'F'},
        'D': {'B'},
        'E': {'B', 'F'},
        'F': {'C', 'E'}
    }
    print("Breadth-First Search initiated from node A:")
    explore_graph(my_graph_representation, 'A')

if __name__ == "__main__":
    setup_and_run()