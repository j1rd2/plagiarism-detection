def find_reverse_complement(input_dna):
    base_pairings = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
    sequenced_dna = input_dna[::-1]
    return ''.join(base_pairings[nucleotide] for nucleotide in sequenced_dna)

def execute_process():
    initial_dna = "ATGCTAGCTAGT"
    computed_reverse_complement = find_reverse_complement(initial_dna)
    print("Original DNA sequence:", initial_dna)
    print("Reverse complement:", computed_reverse_complement)

if __name__ == "__main__":
    execute_process()