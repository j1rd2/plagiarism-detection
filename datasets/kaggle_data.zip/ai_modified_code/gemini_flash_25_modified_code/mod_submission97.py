def greet_user(username):
    message = f"Hello, {username}!"
    print(message)

def process_data(data_list):
    processed_items = []
    for item in data_list:
        modified_item = item.upper()
        processed_items.append(modified_item)
    return processed_items

def main_operation():
    user_input = input("Enter your name: ")
    greet_user(user_input)

    sample_data = ["apple", "banana", "cherry"]
    transformed_data = process_data(sample_data)
    print("Transformed data:", transformed_data)

if __name__ == "__main__":
    main_operation()