class LibraryItem:
    def __init__(self, item_name, creator, cost):
        self.item_name = item_name
        self.creator = creator
        self.cost = cost

    def show_details(self):
        print(f"Name: {self.item_name}, Creator: {self.creator}, Cost: ${self.cost}")

def stock_item(inventory, name, author, price):
    new_item = LibraryItem(name, author, price)
    inventory.append(new_item)

def delete_item(inventory, name):
    inventory[:] = [item for item in inventory if item.item_name != name]

def display_inventory(inventory):
    for item in inventory:
        item.show_details()

def execute_operations():
    inventory = []
    stock_item(inventory, "1984", "George Orwell", 9.50)
    stock_item(inventory, "To Kill a Mockingbird", "Harper Lee", 7.25)
    
    print("Items in stock initially:")
    display_inventory(inventory)
    
    delete_item(inventory, "1984")
    
    print("\nItems in stock after deletion:")
    display_inventory(inventory)

if __name__ == "__main__":
    execute_operations()