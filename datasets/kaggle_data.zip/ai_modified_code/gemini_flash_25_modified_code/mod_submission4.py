def perform_addition(first_number, second_number):
    sum_result = first_number + second_number
    return sum_result