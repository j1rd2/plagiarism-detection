import psutil

def gather_resource_metrics():
    system_cpu_load = psutil.cpu_percent(interval=1)
    print(f"CPU Utilization: {system_cpu_load}%")
    
    system_memory_info = psutil.virtual_memory()
    print(f"RAM Utilization: {system_memory_info.percent}%")
    
    system_disk_stats = psutil.disk_usage('/')
    print(f"Storage Utilization: {system_disk_stats.percent}%")

def execute_checks():
    gather_resource_metrics()

if __name__ == "__main__":
    execute_checks()