def partition_and_recurse(data_list):
    if len(data_list) <= 1:
        return data_list
    else:
        pivot_element = data_list[0]
        smaller_elements = [item for item in data_list[1:] if item <= pivot_element]
        larger_elements = [item for item in data_list[1:] if item > pivot_element]
        return partition_and_recurse(smaller_elements) + [pivot_element] + partition_and_recurse(larger_elements)

def execute_sorting():
    initial_data = [10, 7, 8, 9, 1, 5]
    print("Initial dataset:", initial_data)
    processed_data = partition_and_recurse(initial_data)
    print("Processed dataset:", processed_data)

if __name__ == "__main__":
    execute_sorting()