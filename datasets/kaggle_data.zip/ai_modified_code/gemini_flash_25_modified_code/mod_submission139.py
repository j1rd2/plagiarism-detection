import threading
import time

def display_sequence(identifier, wait_time):
    for count in range(5):
        print(f"{identifier}: {count}")
        time.sleep(wait_time)

def orchestrate_tasks():
    worker_one = threading.Thread(target=display_sequence, args=("Worker Alpha", 1))
    worker_two = threading.Thread(target=display_sequence, args=("Worker Beta", 0.5))

    worker_one.start()
    worker_two.start()

    worker_one.join()
    worker_two.join()

if __name__ == "__main__":
    orchestrate_tasks()