import random

def process_nucleotide_strand(nucleotide_string, alteration_chance=0.02):
    valid_nucleotides = ['A', 'T', 'C', 'G']
    nucleotide_list = list(nucleotide_string)
    alteration_count = 0
    
    for index in range(len(nucleotide_list)):
        if random.random() < alteration_chance:
            nucleotide_list[index] = random.choice(valid_nucleotides)
            alteration_count += 1
    
    modified_string = ''.join(nucleotide_list)
    print(f"Total alterations: {alteration_count}")
    return modified_string

def initiate_process():
    initial_nucleotide_string = "ATGCTAGCTAGT"
    final_nucleotide_string = process_nucleotide_strand(initial_nucleotide_string, alteration_chance=0.05)
    print("Initial nucleotide string:", initial_nucleotide_string)
    print("Modified nucleotide string:", final_nucleotide_string)

if __name__ == "__main__":
    initiate_process()