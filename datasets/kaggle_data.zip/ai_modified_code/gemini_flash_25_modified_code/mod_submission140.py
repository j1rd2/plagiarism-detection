import threading
import time

def perform_counting():
    for counter in range(5):
        print(f"Worker Thread: {counter}")
        time.sleep(1)

def orchestrate_threads():
    worker_thread = threading.Thread(target=perform_counting)
    worker_thread.daemon = True
    worker_thread.start()
    
    time.sleep(2)

if __name__ == "__main__":
    orchestrate_threads()