import json

def retrieve_personnel_records(data_location):
    with open(data_location, 'r') as source_file:
        personnel_info = json.load(source_file)
    return personnel_info['personnel']

def select_personnel_by_unit(personnel_list, target_unit):
    return [individual for individual in personnel_list if individual['unit'] == target_unit]

def compute_average_compensation(personnel_group):
    total_compensation = sum(individual['pay'] for individual in personnel_group)
    return total_compensation / len(personnel_group) if personnel_group else 0

def archive_findings_to_json(findings, destination_file):
    with open(destination_file, 'w') as sink_file:
        json.dump(findings, sink_file, indent=4)

def orchestrate_processing():
    source_file_path = 'employees.json'
    destination_file_path = 'department_summary.json'
    designated_unit = 'Engineering'

    all_personnel = retrieve_personnel_records(source_file_path)
    designated_personnel = select_personnel_by_unit(all_personnel, designated_unit)
    average_compensation_level = compute_average_compensation(designated_personnel)
    summary_report = {
        'unit': designated_unit,
        'average_compensation': average_compensation_level,
        'personnel_count': len(designated_personnel)
    }

    archive_findings_to_json(summary_report, destination_file_path)
    print(f"Processing complete. Report saved to {destination_file_path}")

if __name__ == "__main__":
    orchestrate_processing()