class Gadget:
    def __init__(self, manufacturer, product_name, software_release):
        self.manufacturer = manufacturer
        self.product_name = product_name
        self.software_release = software_release

    def show_details(self):
        print(f"Manufacturer: {self.manufacturer}, Product: {self.product_name}, Software: {self.software_release}")

def introduce_gadget(gadgets_collection, manufacturer, product_name, software_release):
    new_gadget = Gadget(manufacturer, product_name, software_release)
    gadgets_collection.append(new_gadget)

def eliminate_gadget(gadgets_collection, product_name):
    gadgets_collection[:] = [gadget for gadget in gadgets_collection if gadget.product_name != product_name]

def present_gadgets(gadgets_collection):
    for gadget in gadgets_collection:
        gadget.show_details()

def initiate_process():
    gadgets_registry = []
    introduce_gadget(gadgets_registry, "Apple", "iPhone 13", "iOS 15")
    introduce_gadget(gadgets_registry, "Google", "Pixel 6", "Android 12")
    
    print("Current gadgets in registry:")
    present_gadgets(gadgets_registry)
    
    eliminate_gadget(gadgets_registry, "iPhone 13")
    
    print("Updated gadgets in registry:")
    present_gadgets(gadgets_registry)

if __name__ == "__main__":
    initiate_process()