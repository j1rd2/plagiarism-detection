import sqlite3

def establish_db_connection(database_path):
    db_connection = sqlite3.connect(database_path)
    return db_connection

def define_data_structure(db_connection):
    create_users_sql = """CREATE TABLE IF NOT EXISTS users (
                                    user_id integer PRIMARY KEY,
                                    user_name text NOT NULL,
                                    user_age integer
                                );"""
    try:
        cursor = db_connection.cursor()
        cursor.execute(create_users_sql)
    except sqlite3.Error as err:
        print(err)

def add_new_record(db_connection, record_data):
    insert_sql = ''' INSERT INTO users(user_name, user_age)
              VALUES(?,?) '''
    record_cursor = db_connection.cursor()
    record_cursor.execute(insert_sql, record_data)
    db_connection.commit()
    return record_cursor.lastrowid

def retrieve_all_records(db_connection):
    fetch_cursor = db_connection.cursor()
    fetch_cursor.execute("SELECT * FROM users")

    all_records = fetch_cursor.fetchall()
    for rec in all_records:
        print(rec)

def execute_operations():
    db_file_path = "data.db"

    connection_instance = establish_db_connection(db_file_path)
    with connection_instance:
        define_data_structure(connection_instance)
        new_user_data = ('Jane', 30)
        add_new_record(connection_instance, new_user_data)
        print("Records in the data store:")
        retrieve_all_records(connection_instance)

if __name__ == '__main__':
    execute_operations()