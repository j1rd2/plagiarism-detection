def process_input(user_entry):
    if not check_validity(user_entry):
        raise ValueError("Please enter a non-negative integer")

    accumulated_product = 1
    while user_entry > 1:
        accumulated_product *= user_entry
        user_entry -= 1
    return accumulated_product

def check_validity(value):
    return isinstance(value, int) and value >= 0

def execute_program():
    try:
        input_value = int(input("Enter a number to find its factorial: "))
        print(f"Factorial: {process_input(input_value)}")
    except ValueError as error_message:
        print(error_message)

if __name__ == "__main__":
    execute_program()