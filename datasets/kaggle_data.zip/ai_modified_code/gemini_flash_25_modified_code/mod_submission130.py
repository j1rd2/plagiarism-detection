class Tome:
    def __init__(self, book_name, writer_name, cost):
        self.book_name = book_name
        self.writer_name = writer_name
        self.cost = cost

    def present_details(self):
        print(f"Title: {self.book_name}, Author: {self.writer_name}, Price: ${self.cost}")

    def adjust_cost(self, revised_cost):
        self.cost = revised_cost

def register_tome(tome_collection, book_name, writer_name, cost):
    new_tome = Tome(book_name, writer_name, cost)
    tome_collection.append(new_tome)

def modify_tome_cost(tome_collection, book_name, revised_cost):
    for tome in tome_collection:
        if tome.book_name == book_name:
            tome.adjust_cost(revised_cost)

def enumerate_tomes(tome_collection):
    for tome in tome_collection:
        tome.present_details()

def process_operations():
    tome_collection = []
    register_tome(tome_collection, "War and Peace", "Leo Tolstoy", 12.99)
    register_tome(tome_collection, "The Hobbit", "J.R.R. Tolkien", 9.99)
    
    print("Tomes available before cost adjustment:")
    enumerate_tomes(tome_collection)
    
    modify_tome_cost(tome_collection, "The Hobbit", 7.99)
    
    print("\nTomes available after cost adjustment:")
    enumerate_tomes(tome_collection)

if __name__ == "__main__":
    process_operations()