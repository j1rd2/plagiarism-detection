import sqlite3

def establish_database_connection(database_path):
    connection_object = sqlite3.connect(database_path)
    return connection_object

def build_customer_table(database_connection):
    create_customers_sql = """CREATE TABLE IF NOT EXISTS customers (
                                customer_id integer PRIMARY KEY,
                                full_name text NOT NULL,
                                customer_age integer
                            );"""
    try:
        cursor_object = database_connection.cursor()
        cursor_object.execute(create_customers_sql)
    except sqlite3.Error as error:
        print(error)

def add_new_customer(database_connection, customer_data):
    insert_customer_sql = ''' INSERT INTO customers(full_name, customer_age)
              VALUES(?,?) '''
    record_cursor = database_connection.cursor()
    record_cursor.execute(insert_customer_sql, customer_data)
    database_connection.commit()
    return record_cursor.lastrowid

def retrieve_all_customers(database_connection):
    query_cursor = database_connection.cursor()
    query_cursor.execute("SELECT * FROM customers")

    all_records = query_cursor.fetchall()
    for record in all_records:
        print(record)

def orchestrate_db_operations():
    db_filename = "customers.db"

    connection = establish_database_connection(db_filename)
    with connection:
        build_customer_table(connection)
        new_customer_details = ('Bob', 25)
        add_new_customer(connection, new_customer_details)
        print("Current customer roster:")
        retrieve_all_customers(connection)

if __name__ == '__main__':
    orchestrate_db_operations()