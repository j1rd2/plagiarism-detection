import pandas as pd

def process_records(source_path):
    data_frame = pd.read_csv(source_path)
    return data_frame

def determine_mean_value(frame):
    mean_score = frame['Score'].mean()
    return mean_score

def categorize_performance(frame, mean_score_threshold):
    frame['PerformanceCategory'] = frame['Score'].apply(lambda value: 'Pass' if value >= mean_score_threshold else 'Fail')
    return frame

def save_output(frame, destination_path):
    frame.to_csv(destination_path, index=False)

def orchestrate_process():
    input_csv = 'students.csv'
    output_csv = 'graded_students.csv'
    raw_data = process_records(input_csv)
    calculated_mean = determine_mean_value(raw_data)
    final_data = categorize_performance(raw_data, calculated_mean)
    save_output(final_data, output_csv)
    print(f"Processing complete. Results are in {output_csv}")

if __name__ == "__main__":
    orchestrate_process()