import joblib
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

def prepare_data():
    dataset = load_iris()
    features = dataset.data
    labels = dataset.target
    return features, labels

def split_data(all_features, all_labels):
    features_train, features_test, labels_train, labels_test = train_test_split(
        all_features, all_labels, test_size=0.3, random_state=42
    )
    return features_train, features_test, labels_train, labels_test

def train_classifier(training_features, training_labels):
    classifier = LogisticRegression(max_iter=200, random_state=42)
    classifier.fit(training_features, training_labels)
    return classifier

def save_model(trained_classifier, filename='logistic_regression_model.pkl'):
    joblib.dump(trained_classifier, filename)

if __name__ == "__main__":
    dataset_features, dataset_labels = prepare_data()
    train_features, test_features, train_labels, test_labels = split_data(dataset_features, dataset_labels)
    fitted_model = train_classifier(train_features, train_labels)
    save_model(fitted_model)