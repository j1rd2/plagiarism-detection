class ListItem:
    def __init__(self, value):
        self.value = value
        self.following = None
        self.preceding = None

class LinkedListContainer:
    def __init__(self):
        self.start_node = None

    def append_item(self, item_value):
        new_item = ListItem(item_value)
        if not self.start_node:
            self.start_node = new_item
            return
        last_item = self.start_node
        while last_item.following:
            last_item = last_item.following
        last_item.following = new_item
        new_item.preceding = last_item

    def remove_item(self, item_key):
        current_item = self.start_node
        if current_item is not None:
            if current_item.value == item_key:
                self.start_node = current_item.following
                if self.start_node:
                    self.start_node.preceding = None
                current_item = None
                return
        while current_item is not None:
            if current_item.value == item_key:
                break
            current_item = current_item.following
        if current_item is None:
            return
        if current_item.following:
            current_item.following.preceding = current_item.preceding
        if current_item.preceding:
            current_item.preceding.following = current_item.following
        current_item = None

    def display_items(self):
        current_item = self.start_node
        while current_item:
            print(current_item.value, end=" <-> ")
            current_item = current_item.following
        print("None")

def process_list():
    my_list = LinkedListContainer()
    my_list.append_item(10)
    my_list.append_item(20)
    my_list.append_item(30)
    my_list.display_items()
    my_list.remove_item(20)
    my_list.display_items()

if __name__ == "__main__":
    process_list()