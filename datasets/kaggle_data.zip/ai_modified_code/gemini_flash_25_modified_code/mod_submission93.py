class DataStructure:
    def __init__(self):
        self.internal_list = []

    def add_element(self, element):
        self.internal_list.append(element)

    def remove_element(self):
        if not self.check_empty():
            return self.internal_list.pop(0)
        return None

    def peek_first(self):
        if not self.check_empty():
            return self.internal_list[0]
        return None

    def check_empty(self):
        return len(self.internal_list) == 0

    def get_count(self):
        return len(self.internal_list)

def execution_flow():
    data_container = DataStructure()
    data_container.add_element(10)
    data_container.add_element(20)
    data_container.add_element(30)
    print("First item:", data_container.peek_first())
    print("Container count:", data_container.get_count())
    data_container.remove_element()
    print("Container after removal:", data_container.internal_list)

if __name__ == "__main__":
    execution_flow()