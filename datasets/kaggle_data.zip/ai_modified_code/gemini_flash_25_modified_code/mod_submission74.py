class Item:
    def __init__(self, item_id, item_name, item_cost, stock_level):
        self.item_id = item_id
        self.item_name = item_name
        self.item_cost = item_cost
        self.stock_level = stock_level

    def adjust_stock(self, quantity_change):
        self.stock_level += quantity_change

    def set_cost(self, new_cost):
        self.item_cost = new_cost

class Patron:
    def __init__(self, patron_id, patron_name):
        self.patron_id = patron_id
        self.patron_name = patron_name

class Store:
    def __init__(self):
        self.wares = {}
        self.patrons = {}

    def introduce_item(self, item):
        self.wares[item.item_id] = item

    def modify_stock(self, item_id, quantity):
        if item_id in self.wares:
            self.wares[item_id].adjust_stock(quantity)

    def register_patron(self, patron):
        self.patrons[patron.patron_id] = patron

    def display_wares(self):
        for item in self.wares.values():
            print(f"ID: {item.item_id}, Name: {item.item_name}, Price: ${item.item_cost}, Quantity: {item.stock_level}")

    def display_patrons(self):
        for patron in self.patrons.values():
            print(f"ID: {patron.patron_id}, Name: {patron.patron_name}")

def run_simulation():
    market = Store()

    item_a = Item(1, "Milk", 1.99, 50)
    item_b = Item(2, "Bread", 2.49, 30)

    market.introduce_item(item_a)
    market.introduce_item(item_b)

    client_one = Patron(101, "Alice")
    client_two = Patron(102, "Bob")

    market.register_patron(client_one)
    market.register_patron(client_two)

    market.modify_stock(1, 10)
    market.modify_stock(2, -2)

    print("Wares List:")
    market.display_wares()

    print("\nPatron List:")
    market.display_patrons()

if __name__ == "__main__":
    run_simulation()