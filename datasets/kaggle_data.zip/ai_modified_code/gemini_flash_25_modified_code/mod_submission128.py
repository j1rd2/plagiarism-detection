class ReadingMaterial:
    def __init__(self, name, creator, cost):
        self.name = name
        self.creator = creator
        self.cost = cost

    def show_details(self):
        print(f"Name: {self.name}, Creator: {self.creator}, Cost: ${self.cost}")

def insert_reading_material(collection, name, creator, cost):
    material = ReadingMaterial(name, creator, cost)
    collection.append(material)

def find_reading_material(collection, name):
    for item in collection:
        if item.name == name:
            item.show_details()

def show_all_reading_materials(collection):
    for item in collection:
        item.show_details()

def run_application():
    inventory = []
    insert_reading_material(inventory, "To Kill a Mockingbird", "Harper Lee", 7.50)
    insert_reading_material(inventory, "Pride and Prejudice", "Jane Austen", 6.99)
    
    print("Inventory items:")
    show_all_reading_materials(inventory)
    
    print("\nLooking for 'Pride and Prejudice':")
    find_reading_material(inventory, "Pride and Prejudice")

if __name__ == "__main__":
    run_application()