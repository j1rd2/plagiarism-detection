def calculate_gc_percentage(sequence):
    g_count = sequence.count('G')
    c_count = sequence.count('C')
    total_gc = g_count + c_count
    return (total_gc / len(sequence)) * 100

def execute_analysis():
    sample_sequence = "ATGCTAGCTAGT"
    gc_result = calculate_gc_percentage(sample_sequence)
    print("Sequence:", sample_sequence)
    print("GC Content (%):", gc_result)

if __name__ == "__main__":
    execute_analysis()