import csv

def extract_student_info(data_source):
    students_list = []
    with open(data_source, 'r') as source_file:
        data_parser = csv.DictReader(source_file)
        for entry in data_parser:
            students_list.append({
                'student_name': entry['Name'],
                'student_score': float(entry['Score'])
            })
    return students_list

def calculate_class_average(students_info):
    total_score = sum(s['student_score'] for s in students_info)
    return total_score / len(students_info)

def assign_performance_levels(students_info, class_avg):
    for s in students_info:
        if s['student_score'] >= class_avg:
            s['performance'] = 'A'
        else:
            s['performance'] = 'B'
    return students_info

def output_processed_data(students_info, destination_file):
    with open(destination_file, 'w', newline='') as dest_file:
        data_formatter = csv.DictWriter(dest_file, fieldnames=['Name', 'Score', 'Grade'])
        data_formatter.writeheader()
        data_formatter.writerows(students_info)

def run_processing_pipeline():
    input_file_path = 'students.csv'
    output_file_path = 'graded_students.csv'
    student_records = extract_student_info(input_file_path)
    average_score = calculate_class_average(student_records)
    final_student_data = assign_performance_levels(student_records, average_score)
    output_processed_data(final_student_data, output_file_path)
    print(f"Processed data saved to {output_file_path}")

if __name__ == "__main__":
    run_processing_pipeline()