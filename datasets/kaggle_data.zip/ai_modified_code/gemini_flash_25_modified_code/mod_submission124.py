class Gadget:
    def __init__(self, manufacturer, model_name, system_version, power_storage):
        self.manufacturer = manufacturer
        self.model_name = model_name
        self.system_version = system_version
        self.power_storage = power_storage

    def show_details(self):
        print(f"Manufacturer: {self.manufacturer}, Model: {self.model_name}, OS: {self.system_version}, Battery: {self.power_storage}mAh")

def register_gadget(gadget_collection, manufacturer, model_name, system_version, power_storage):
    new_gadget = Gadget(manufacturer, model_name, system_version, power_storage)
    gadget_collection.append(new_gadget)

def present_gadgets(gadget_collection):
    for gadget in gadget_collection:
        gadget.show_details()

def start_management():
    gadget_list = []
    register_gadget(gadget_list, "Samsung", "Galaxy S21", "Android 11", 4000)
    register_gadget(gadget_list, "Apple", "iPhone 13", "iOS 15", 3240)
    
    print("Inventory of portable electronics:")
    present_gadgets(gadget_list)

if __name__ == "__main__":
    start_management()