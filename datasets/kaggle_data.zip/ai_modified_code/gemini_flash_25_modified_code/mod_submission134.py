import openpyxl

def process_spreadsheet(filepath):
    workbook_instance = openpyxl.load_workbook(filepath)
    target_sheet = workbook_instance.active
    
    for row_data in target_sheet.iter_rows(values_only=True):
        print(row_data)

def initiate_process():
    print("Accessing data from 'students_with_city.xlsx':")
    process_spreadsheet("students_with_city.xlsx")

if __name__ == "__main__":
    initiate_process()