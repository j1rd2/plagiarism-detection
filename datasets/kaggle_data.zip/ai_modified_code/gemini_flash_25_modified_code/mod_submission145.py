import psutil

def gather_system_metrics():
    cpu_load = psutil.cpu_percent(interval=1)
    print(f"CPU Load: {cpu_load}%")
    
    mem_info = psutil.virtual_memory()
    print(f"Memory Load: {mem_info.percent}%")
    
    disk_stats = psutil.disk_usage('/')
    print(f"Disk Load: {disk_stats.percent}%")

def run_monitoring_tasks():
    gather_system_metrics()

if __name__ == "__main__":
    run_monitoring_tasks()