import pickle
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

def prepare_data_and_train_model(dataset_name, test_fraction, seed):
    data_bundle = dataset_name()
    features = data_bundle.data
    labels = data_bundle.target

    training_features, testing_features, training_labels, testing_labels = train_test_split(
        features, labels, test_size=test_fraction, random_state=seed
    )

    classifier = SVC(kernel='linear', random_state=seed)
    classifier.fit(training_features, training_labels)
    return classifier

def save_model(trained_model, filename):
    with open(filename, 'wb') as output_file:
        pickle.dump(trained_model, output_file)

iris_dataset_loader = load_iris
test_data_ratio = 0.25
random_seed = 42

trained_classifier = prepare_data_and_train_model(
    iris_dataset_loader, test_data_ratio, random_seed
)

model_storage_path = 'svm_model.pkl'
save_model(trained_classifier, model_storage_path)