def process_list(data_structure):
    list_length = len(data_structure)
    for current_index in range(list_length):
        minimum_position = current_index
        for exploration_index in range(current_index + 1, list_length):
            if data_structure[exploration_index] < data_structure[minimum_position]:
                minimum_position = exploration_index
        data_structure[current_index], data_structure[minimum_position] = data_structure[minimum_position], data_structure[current_index]

def initiate_operation():
    initial_sequence = [29, 10, 14, 37, 13]
    print("Initial sequence:", initial_sequence)
    process_list(initial_sequence)
    print("Processed sequence:", initial_sequence)

if __name__ == "__main__":
    initiate_operation()