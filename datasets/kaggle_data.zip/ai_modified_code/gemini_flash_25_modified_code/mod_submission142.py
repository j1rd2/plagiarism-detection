import psutil

def observe_processor_load():
    processor_utilization = psutil.cpu_percent(interval=1)
    print(f"Processor Load: {processor_utilization}%")

def start_monitoring_process():
    observe_processor_load()

if __name__ == "__main__":
    start_monitoring_process()