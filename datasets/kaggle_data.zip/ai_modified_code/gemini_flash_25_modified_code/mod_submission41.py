from operator import itemgetter

def present_data(records):
    print("Ordered list of individuals by their years:")
    for individual in records:
        print(f"Identifier: {individual['identifier']}, Years: {individual['years']}")

def process_data(data_entries):
    ordered_data = sorted(data_entries, key=itemgetter('years'))
    return ordered_data

def initiate_process():
    data_entries = [
        {'identifier': 'Alice', 'years': 34},
        {'identifier': 'Bob', 'years': 23},
        {'identifier': 'Charlie', 'years': 29},
        {'identifier': 'Diana', 'years': 40},
        {'identifier': 'Eve', 'years': 22}
    ]
    ordered_data = process_data(data_entries)
    present_data(ordered_data)

if __name__ == "__main__":
    initiate_process()