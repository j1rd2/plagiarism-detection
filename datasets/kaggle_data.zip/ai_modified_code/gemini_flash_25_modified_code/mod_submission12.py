def calculate_product_sequence(value):
    if value <= 1:
        return 1
    else:
        return value * calculate_product_sequence(value - 1)

print(calculate_product_sequence(5))