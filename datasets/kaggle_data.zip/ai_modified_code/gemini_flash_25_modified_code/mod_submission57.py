import json

class StaffMember:
    def __init__(self, staff_name, division, wage):
        self.staff_name = staff_name
        self.division = division
        self.wage = wage

class DivisionReport:
    def __init__(self, division_name):
        self.division_name = division_name
        self.staff_list = []

    def enroll_staff(self, staff):
        if staff.division == self.division_name:
            self.staff_list.append(staff)

    def determine_mean_wage(self):
        if not self.staff_list:
            return 0
        total_wage = sum(member.wage for member in self.staff_list)
        return total_wage / len(self.staff_list)

    def to_structured_data(self):
        return {
            'division': self.division_name,
            'mean_wage': self.determine_mean_wage(),
            'staff_count': len(self.staff_list)
        }

def fetch_staff_data(data_source):
    with open(data_source, 'r') as source:
        content = json.load(source)
    return [StaffMember(record['name'], record['department'], record['salary']) for record in content['employees']]

def archive_report(report_dict, destination_file):
    with open(destination_file, 'w') as destination:
        json.dump(report_dict, destination, indent=4)

def orchestrate_processing():
    input_data_path = 'employees.json'
    output_report_path = 'department_summary.json'
    target_division = 'Engineering'

    all_staff = fetch_staff_data(input_data_path)
    engineering_report = DivisionReport(target_division)
    
    for person in all_staff:
        engineering_report.enroll_staff(person)
    
    formatted_report = engineering_report.to_structured_data()
    archive_report(formatted_report, output_report_path)
    print(f"Division summary has been compiled to {output_report_path}")

if __name__ == "__main__":
    orchestrate_processing()