account_registry = {}
transaction_log = []

def register_account(account_id, account_holder_name, initial_balance):
    account_registry[account_id] = {"HolderName": account_holder_name, "CurrentBalance": initial_balance}

def credit_account(account_id, deposit_amount):
    if account_id in account_registry:
        account_registry[account_id]["CurrentBalance"] += deposit_amount
        transaction_log.append({"AccountID": account_id, "Operation": "Deposit", "Value": deposit_amount})
    else:
        print("Account ID not found.")

def debit_account(account_id, withdrawal_amount):
    if account_id in account_registry:
        if account_registry[account_id]["CurrentBalance"] >= withdrawal_amount:
            account_registry[account_id]["CurrentBalance"] -= withdrawal_amount
            transaction_log.append({"AccountID": account_id, "Operation": "Withdraw", "Value": withdrawal_amount})
        else:
            print("Insufficient balance.")
    else:
        print("Account ID not found.")

def display_accounts():
    for account_id, account_details in account_registry.items():
        print(f"ID: {account_id}, Name: {account_details['HolderName']}, Balance: ${account_details['CurrentBalance']}")

def display_transactions():
    for log_entry in transaction_log:
        print(f"Account ID: {log_entry['AccountID']}, Type: {log_entry['Operation']}, Amount: ${log_entry['Value']}")

def start_process():
    register_account(101, "Alice", 5000)
    register_account(102, "Bob", 3000)

    credit_account(101, 700)
    debit_account(102, 1000)

    print("Account Overview:")
    display_accounts()

    print("\nTransaction History:")
    display_transactions()

if __name__ == "__main__":
    start_process()