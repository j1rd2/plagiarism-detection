from flask import Flask

web_server = Flask(__name__)

@web_server.route('/greeting')
def display_greeting():
    return '<h1 style="color:green;">Greetings, Earthling!</h1>'

if __name__ == '__main__':
    web_server.run(debug=True)