import math

def calculate_product_of_integers(number_to_process):
    return math.factorial(number_to_process)

print(calculate_product_of_integers(5))