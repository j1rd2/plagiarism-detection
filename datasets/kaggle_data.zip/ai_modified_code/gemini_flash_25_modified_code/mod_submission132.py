import openpyxl

def process_data_to_excel(output_file_name):
    workbook_instance = openpyxl.Workbook()
    target_sheet = workbook_instance.active
    
    target_sheet["A1"] = "PersonName"
    target_sheet["B1"] = "YearsOld"
    
    target_sheet["A2"] = "Charlie"
    target_sheet["B2"] = 28
    
    target_sheet["A3"] = "Diana"
    target_sheet["B3"] = 35
    
    workbook_instance.save(output_file_name)
    print(f"Report file '{output_file_name}' has been generated with data.")

def initiate_process():
    process_data_to_excel("employee_data.xlsx")

if __name__ == "__main__":
    initiate_process()