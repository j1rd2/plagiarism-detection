import random

def introduce_mutations(genetic_code, chance_of_change=0.02):
    nucleotides = ['A', 'T', 'C', 'G']
    code_as_list = list(genetic_code)
    
    for index in range(len(code_as_list)):
        if random.random() < chance_of_change:
            code_as_list[index] = random.choice(nucleotides)
    
    return ''.join(code_as_list)

def run_simulation():
    initial_genetic_string = "ATGCTAGCTAGT"
    modified_genetic_string = introduce_mutations(initial_genetic_string, chance_of_change=0.05)
    print("Initial genetic string:", initial_genetic_string)
    print("Modified genetic string:", modified_genetic_string)

if __name__ == "__main__":
    run_simulation()