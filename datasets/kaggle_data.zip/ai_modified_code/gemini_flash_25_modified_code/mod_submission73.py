class GroceryItem:
    def __init__(self, item_code, item_name, unit_cost, stock_level):
        self.item_code = item_code
        self.item_name = item_name
        self.unit_cost = unit_cost
        self.stock_level = stock_level

    def adjust_stock(self, amount):
        self.stock_level += amount

    def set_cost(self, cost):
        self.unit_cost = cost

class Store:
    def __init__(self):
        self.stockroom = {}

    def stock_item(self, item):
        self.stockroom[item.item_code] = item

    def modify_stock(self, item_code, quantity_change):
        if item_code in self.stockroom:
            self.stockroom[item_code].adjust_stock(quantity_change)

    def display_stock(self):
        for item in self.stockroom.values():
            print(f"Code: {item.item_code}, Name: {item.item_name}, Cost: ${item.unit_cost}, Quantity: {item.stock_level}")

def process_operations():
    my_store = Store()

    item_a = GroceryItem(101, "Apples", 0.50, 100)
    item_b = GroceryItem(102, "Bananas", 0.30, 75)

    my_store.stock_item(item_a)
    my_store.stock_item(item_b)

    my_store.modify_stock(101, 50)  # Add 50 units to Apples
    my_store.modify_stock(102, -10)  # Remove 10 units from Bananas

    print("Current Store Inventory:")
    my_store.display_stock()

if __name__ == "__main__":
    process_operations()