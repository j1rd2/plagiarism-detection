def produce_integers(source_path):
    with open(source_path, 'r') as handler:
        for line_content in handler:
            yield int(line_content.strip())

def transform_to_squares(data_stream):
    for item in data_stream:
        yield item ** 2

def consume_and_write(processed_data, destination_path):
    with open(destination_path, 'w') as sink:
        for data_point in processed_data:
            sink.write(f"{data_point}\n")

def orchestrate_process():
    source_file = 'input.txt'
    sink_file = 'output.txt'
    initial_stream = produce_integers(source_file)
    transformed_stream = transform_to_squares(initial_stream)
    consume_and_write(transformed_stream, sink_file)
    print(f"Squared numbers saved to {sink_file}")

if __name__ == "__main__":
    orchestrate_process()