def initiate_sorting(data_list):
    list_length = len(data_list)
    for outer_index in range(list_length):
        element_swapped = False
        for inner_index in range(0, list_length - outer_index - 1):
            if data_list[inner_index] > data_list[inner_index + 1]:
                data_list[inner_index], data_list[inner_index + 1] = data_list[inner_index + 1], data_list[inner_index]
                element_swapped = True
        if not element_swapped:
            break

def run_process():
    input_data = [5, 1, 4, 2, 8]
    print("Initial sequence:", input_data)
    initiate_sorting(input_data)
    print("Processed sequence:", input_data)

if __name__ == "__main__":
    run_process()