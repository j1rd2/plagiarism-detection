def display_individuals(individuals):
    print("Individuals sorted by age:")
    for individual in individuals:
        print(f"Name: {individual['name']}, Age: {individual['age']}")

def arrange_by_youth(group):
    ordered_group = sorted(group, key=lambda data: data['age'])
    return ordered_group

def run_process():
    personnel = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    aged_personnel = arrange_by_youth(personnel)
    display_individuals(aged_personnel)

if __name__ == "__main__":
    run_process()