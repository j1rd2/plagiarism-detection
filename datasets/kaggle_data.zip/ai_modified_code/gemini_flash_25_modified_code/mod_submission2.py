def sum_two_numbers(first_operand, second_operand):
    result = first_operand + second_operand
    return result