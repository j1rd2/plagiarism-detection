import math

def check_for_prime(number):
    if number <= 1:
        return False
    if number == 2:
        return True
    if number % 2 == 0:
        return False
    for divisor in range(3, int(math.sqrt(number)) + 1, 2):
        if number % divisor == 0:
            return False
    return True

def gather_primes_up_to(upper_bound):
    return [candidate for candidate in range(2, upper_bound + 1) if check_for_prime(candidate)]

def run_process():
    max_value = 50
    primes_found = gather_primes_up_to(max_value)
    print(f"Primes up to {max_value}: {primes_found}")

if __name__ == "__main__":
    run_process()