import sqlite3

def initialize_database(db_path):
    db_connection = sqlite3.connect(db_path)
    return db_connection

def setup_user_table(connection):
    create_users_sql = """CREATE TABLE IF NOT EXISTS users (
                                    id integer PRIMARY KEY,
                                    name text NOT NULL,
                                    age integer
                                );"""
    try:
        cursor_obj = connection.cursor()
        cursor_obj.execute(create_users_sql)
    except sqlite3.Error as err:
        print(err)

def add_new_user(connection, user_data):
    insert_sql = ''' INSERT INTO users(name, age)
              VALUES(?,?) '''
    cursor_obj = connection.cursor()
    cursor_obj.execute(insert_sql, user_data)
    connection.commit()
    return cursor_obj.lastrowid

def remove_user_by_id(connection, user_identifier):
    delete_sql = 'DELETE FROM users WHERE id=?'
    cursor_obj = connection.cursor()
    cursor_obj.execute(delete_sql, (user_identifier,))
    connection.commit()

def retrieve_all_users(connection):
    cursor_obj = connection.cursor()
    cursor_obj.execute("SELECT * FROM users")

    all_records = cursor_obj.fetchall()
    for record in all_records:
        print(record)

def execute_db_operations():
    db_file_name = "test.db"

    connection_obj = initialize_database(db_file_name)
    with connection_obj:
        setup_user_table(connection_obj)
        new_user_details = ('John', 28)
        add_new_user(connection_obj, new_user_details)
        remove_user_by_id(connection_obj, 1)
        print("Users in the database:")
        retrieve_all_users(connection_obj)

if __name__ == '__main__':
    execute_db_operations()