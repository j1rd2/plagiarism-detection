class PatientRecord:
    def __init__(self, record_id, name, age, health_condition):
        self.record_id = record_id
        self.name = name
        self.age = age
        self.health_condition = health_condition

class MeetingData:
    def __init__(self, meeting_id, patient_ref, physician_name, meeting_date):
        self.meeting_id = meeting_id
        self.patient_ref = patient_ref
        self.physician_name = physician_name
        self.meeting_date = meeting_date

class FinancialStatement:
    def __init__(self, statement_id, client_ref, charge_amount):
        self.statement_id = statement_id
        self.client_ref = client_ref
        self.charge_amount = charge_amount

class HealthcareManagement:
    def __init__(self):
        self.registered_patients = []
        self.scheduled_meetings = []
        self.issued_statements = []

    def admit_patient(self, patient):
        self.registered_patients.append(patient)

    def schedule_meeting(self, meeting):
        self.scheduled_meetings.append(meeting)

    def issue_charge(self, statement):
        self.issued_statements.append(statement)

    def display_patients(self):
        for patient in self.registered_patients:
            print(f"ID: {patient.record_id}, Name: {patient.name}, Age: {patient.age}, Condition: {patient.health_condition}")

    def display_meetings(self):
        for meeting in self.scheduled_meetings:
            print(f"Meeting ID: {meeting.meeting_id}, Patient: {meeting.patient_ref.name}, Doctor: {meeting.physician_name}, Date: {meeting.meeting_date}")

    def display_financials(self):
        for statement in self.issued_statements:
            print(f"Bill ID: {statement.statement_id}, Patient: {statement.client_ref.name}, Amount: ${statement.charge_amount}")

def execute_operations():
    system_manager = HealthcareManagement()

    patient_alpha = PatientRecord(101, "Alice Green", 29, "Headache")
    patient_beta = PatientRecord(102, "Bob Brown", 54, "Fever")

    system_manager.admit_patient(patient_alpha)
    system_manager.admit_patient(patient_beta)

    appointment_alpha = MeetingData(1001, patient_alpha, "Dr. Martin", "2024-09-17")
    appointment_beta = MeetingData(1002, patient_beta, "Dr. Lisa", "2024-09-18")

    system_manager.schedule_meeting(appointment_alpha)
    system_manager.schedule_meeting(appointment_beta)

    billing_alpha = FinancialStatement(1, patient_alpha, 150.0)
    billing_beta = FinancialStatement(2, patient_beta, 200.0)

    system_manager.issue_charge(billing_alpha)
    system_manager.issue_charge(billing_beta)

    print("Patient Records:")
    system_manager.display_patients()

    print("\nAppointment Records:")
    system_manager.display_meetings()

    print("\nBilling Records:")
    system_manager.display_financials()

if __name__ == "__main__":
    execute_operations()