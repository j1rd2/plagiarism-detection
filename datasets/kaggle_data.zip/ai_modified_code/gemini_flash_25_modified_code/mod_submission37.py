def is_element_prime(candidate_number):
    if candidate_number <= 1:
        return False
    for factor in range(2, candidate_number):
        if candidate_number % factor == 0:
            return False
    return True

def collect_prime_numbers(boundary):
    identified_primes = []
    for number_to_check in range(2, boundary + 1):
        if is_element_prime(number_to_check):
            identified_primes.append(number_to_check)
    return identified_primes

def execute_prime_finding_process():
    maximum_value = 50
    found_primes = collect_prime_numbers(maximum_value)
    print(f"Prime numbers within the range up to {maximum_value}: {found_primes}")

if __name__ == "__main__":
    execute_prime_finding_process()