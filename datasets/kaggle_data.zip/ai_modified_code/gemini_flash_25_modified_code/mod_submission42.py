def display_individuals(individuals_data):
    print("Individuals data sorted by their age values:")
    for individual in individuals_data:
        print(f"Name: {individual['name_key']}, Age: {individual['age_key']}")

def arrange_by_age(list_of_people):
    arranged_list = sorted(list_of_people, key=lambda person_dict: person_dict['age_key'])
    return arranged_list

def process_data():
    person_records = [
        {'name_key': 'Alice', 'age_key': 34},
        {'name_key': 'Bob', 'age_key': 23},
        {'name_key': 'Charlie', 'age_key': 29},
        {'name_key': 'Diana', 'age_key': 40},
        {'name_key': 'Eve', 'age_key': 22}
    ]
    ordered_person_records = arrange_by_age(person_records)
    display_individuals(ordered_person_records)

if __name__ == "__main__":
    process_data()