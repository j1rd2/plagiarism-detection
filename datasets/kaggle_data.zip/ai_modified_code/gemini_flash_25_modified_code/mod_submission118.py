import pickle
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

def train_and_save_model():
    data_features, target_labels = load_dataset()
    training_features, testing_features, training_labels, testing_labels = split_data(data_features, target_labels)
    trained_classifier = build_and_train_classifier(training_features, training_labels)
    save_model_to_file(trained_classifier, 'trained_classifier.pkl')

def load_dataset():
    iris_dataset = load_iris()
    return iris_dataset.data, iris_dataset.target

def split_data(features, labels, test_proportion=0.25, seed=42):
    return train_test_split(features, labels, test_size=test_proportion, random_state=seed)

def build_and_train_classifier(features_train, labels_train, num_trees=100, seed=42):
    classifier = RandomForestClassifier(n_estimators=num_trees, random_state=seed)
    classifier.fit(features_train, labels_train)
    return classifier

def save_model_to_file(model_instance, filename):
    with open(filename, 'wb') as output_file:
        pickle.dump(model_instance, output_file)

if __name__ == "__main__":
    train_and_save_model()