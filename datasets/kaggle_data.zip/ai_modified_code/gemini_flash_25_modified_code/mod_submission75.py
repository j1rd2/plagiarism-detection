inventory = {}
clients = {}
transactions = []

def register_item(item_code, item_name, item_price, item_stock):
    inventory[item_code] = {"Name": item_name, "Price": item_price, "Stock": item_stock}

def enroll_client(client_id, client_name):
    clients[client_id] = {"Name": client_name}

def record_transaction(transaction_ref, client_id, item_code, quantity_bought):
    if item_code in inventory and client_id in clients:
        if inventory[item_code]["Stock"] >= quantity_bought:
            inventory[item_code]["Stock"] -= quantity_bought
            transactions.append({"TransactionRef": transaction_ref, "ClientID": client_id, "ItemCode": item_code, "Quantity": quantity_bought})
        else:
            print(f"Insufficient stock for item {item_code}")
    else:
        print("Invalid item or client identifier")

def display_inventory():
    for item_code, details in inventory.items():
        print(f"Code: {item_code}, Name: {details['Name']}, Price: ${details['Price']}, Stock: {details['Stock']}")

def display_clients():
    for client_id, details in clients.items():
        print(f"ID: {client_id}, Name: {details['Name']}")

def display_transactions():
    for transaction in transactions:
        print(f"Ref: {transaction['TransactionRef']}, Client ID: {transaction['ClientID']}, Item Code: {transaction['ItemCode']}, Quantity: {transaction['Quantity']}")

def run_operations():
    register_item(1, "Eggs", 3.99, 100)
    register_item(2, "Butter", 4.99, 50)

    enroll_client(201, "Charlie")
    enroll_client(202, "Daisy")

    record_transaction(1, 201, 1, 12)
    record_transaction(2, 202, 2, 5)

    print("Inventory Items:")
    display_inventory()

    print("\nClient Roster:")
    display_clients()

    print("\nTransaction Log:")
    display_transactions()

if __name__ == "__main__":
    run_operations()