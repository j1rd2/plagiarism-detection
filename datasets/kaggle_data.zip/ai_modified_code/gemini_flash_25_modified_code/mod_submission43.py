def determine_age_order(record_a, record_b):
    if record_a['age'] < record_b['age']:
        return -1
    elif record_a['age'] > record_b['age']:
        return 1
    else:
        return 0

def arrange_individuals_by_age(individual_list):
    arranged_individuals = sorted(individual_list, key=lambda individual: individual['age'], cmp=determine_age_order)
    return arranged_individuals

def display_arranged_individuals(individual_list):
    print("Arranged list of individuals by age using custom comparison:")
    for individual in individual_list:
        print(f"Name: {individual['name']}, Age: {individual['age']}")

def initiate_process():
    individual_data = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    ordered_individuals = arrange_individuals_by_age(individual_data)
    display_arranged_individuals(ordered_individuals)

if __name__ == "__main__":
    initiate_process()