import logging

def validate_input_is_non_negative_integer(value):
    if not isinstance(value, int) or value < 0:
        raise ValueError("Input must be a non-negative integer.")

def compute_factorial_iteratively(limit):
    validate_input_is_non_negative_integer(limit)
    product = 1
    for counter in range(2, limit + 1):
        product *= counter
    return product

def sum_digits_of_number(number_to_process):
    return sum(int(digit) for digit in str(number_to_process))

def record_processing_outcome(original_number, computed_factorial, sum_of_digits):
    logging.basicConfig(filename='calculation_log.txt', level=logging.INFO)
    logging.info(f"Processing {original_number}: Factorial = {computed_factorial}, Digit Sum = {sum_of_digits}")

def orchestrate_factorial_calculation():
    while True:
        try:
            user_input = int(input("Enter a non-negative integer: "))
            calculated_factorial = compute_factorial_iteratively(user_input)
            total_digit_sum = sum_digits_of_number(calculated_factorial)
            record_processing_outcome(user_input, calculated_factorial, total_digit_sum)
            print(f"Factorial: {calculated_factorial}, Sum of digits: {total_digit_sum}")
        except ValueError as e:
            print(f"Error: {e}")

        continue_prompt = input("Calculate another? (yes/no): ").lower()
        if continue_prompt != 'yes':
            break

if __name__ == "__main__":
    orchestrate_factorial_calculation()