def prime_finder(max_val):
    candidates = [True] * (max_val + 1)
    candidates[0], candidates[1] = False, False
    for factor in range(2, int(max_val ** 0.5) + 1):
        if candidates[factor]:
            for product in range(factor * factor, max_val + 1, factor):
                candidates[product] = False
    return [index for index, is_prime in enumerate(candidates) if is_prime]

def run_process():
    upper_bound = 50
    prime_list = prime_finder(upper_bound)
    print(f"Prime numbers up to {upper_bound} using the Sieve of Eratosthenes: {prime_list}")

if __name__ == "__main__":
    run_process()