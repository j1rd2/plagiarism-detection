import xml.etree.ElementTree as ElementBinder

def load_collection_from_xml(source_path):
    document = ElementBinder.parse(source_path)
    collection_root = document.getroot()
    inventory = []
    for item in collection_root.findall('item'):
        inventory.append({
            'book_name': item.find('title').text,
            'creator': item.find('author').text,
            'publication_year': int(item.find('year').text),
            'unit_cost': float(item.find('price').text)
        })
    return inventory

def isolate_by_year(catalog, threshold_year):
    return [book_record for book_record in catalog if book_record['publication_year'] > threshold_year]

def compute_average_value(catalog):
    if not catalog:
        return 0
    total_value = sum(book_record['unit_cost'] for book_record in catalog)
    return total_value / len(catalog)

def export_summary_to_xml(catalog_subset, average_value, destination_path):
    summary_root = ElementBinder.Element('summaryReport')
    avg_value_node = ElementBinder.SubElement(summary_root, 'averageCost')
    avg_value_node.text = str(average_value)
    for book_record in catalog_subset:
        item_node = ElementBinder.SubElement(summary_root, 'item')
        title_node = ElementBinder.SubElement(item_node, 'title')
        title_node.text = book_record['book_name']
        author_node = ElementBinder.SubElement(item_node, 'author')
        author_node.text = book_record['creator']
        year_node = ElementBinder.SubElement(item_node, 'year')
        year_node.text = str(book_record['publication_year'])
        price_node = ElementBinder.SubElement(item_node, 'price')
        price_node.text = str(book_record['unit_cost'])

    document_tree = ElementBinder.ElementTree(summary_root)
    document_tree.write(destination_path)

def run_processing():
    source_document = 'books.xml'
    destination_document = 'filtered_books.xml'
    cutoff_year = 2000

    full_collection = load_collection_from_xml(source_document)
    recent_inventory = isolate_by_year(full_collection, cutoff_year)
    average_item_cost = compute_average_value(recent_inventory)
    export_summary_to_xml(recent_inventory, average_item_cost, destination_document)
    print(f"Processed collection saved to {destination_document}")

if __name__ == "__main__":
    run_processing()