def restore_heap_property(data_list, heap_size, root_index):
    largest_element_index = root_index
    left_child_index = 2 * root_index + 1
    right_child_index = 2 * root_index + 2

    if left_child_index < heap_size and data_list[left_child_index] > data_list[largest_element_index]:
        largest_element_index = left_child_index

    if right_child_index < heap_size and data_list[right_child_index] > data_list[largest_element_index]:
        largest_element_index = right_child_index

    if largest_element_index != root_index:
        data_list[root_index], data_list[largest_element_index] = data_list[largest_element_index], data_list[root_index]
        restore_heap_property(data_list, heap_size, largest_element_index)

def perform_heap_sort(input_array):
    array_length = len(input_array)

    for i in range(array_length // 2 - 1, -1, -1):
        restore_heap_property(input_array, array_length, i)

    for i in range(array_length - 1, 0, -1):
        input_array[i], input_array[0] = input_array[0], input_array[i]
        restore_heap_property(input_array, i, 0)

def run_process():
    sample_data = [12, 11, 13, 5, 6, 7]
    print("Original data:", sample_data)
    perform_heap_sort(sample_data)
    print("Sorted data:", sample_data)

if __name__ == "__main__":
    run_process()