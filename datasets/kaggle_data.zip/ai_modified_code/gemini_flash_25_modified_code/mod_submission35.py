def check_if_prime(number):
    if number <= 1:
        return False
    for divisor in range(2, number):
        if number % divisor == 0:
            return False
    return True

def generate_prime_list(upper_bound):
    found_primes = []
    for candidate_num in range(2, upper_bound + 1):
        if check_if_prime(candidate_num):
            found_primes.append(candidate_num)
    return found_primes

def execute_prime_finder():
    max_value = 50
    results = generate_prime_list(max_value)
    print(f"Prime numbers up to {max_value}: {results}")

if __name__ == "__main__":
    execute_prime_finder()