def transform_and_store(source_path, destination_path):
    processed_values = process_input(source_path)
    write_output(processed_values, destination_path)
    print(f"Results written to {destination_path}")

def process_input(source_path):
    raw_data = fetch_data(source_path)
    transformed_data = apply_transformation(raw_data)
    return transformed_data

def fetch_data(source_path):
    with open(source_path, 'r') as source_file:
        data_lines = [int(line.strip()) for line in source_file]
    return data_lines

def apply_transformation(data_lines):
    transformed_lines = [value ** 2 for value in data_lines]
    return transformed_lines

def write_output(transformed_lines, destination_path):
    with open(destination_path, 'w') as destination_file:
        for value in transformed_lines:
            destination_file.write(f"{value}\n")

if __name__ == "__main__":
    input_source = 'input.txt'
    output_destination = 'output.txt'
    transform_and_store(input_source, output_destination)