import xml.etree.ElementTree as ET

def obtain_book_data(source_path):
    xml_document = ET.parse(source_path)
    xml_root_element = xml_document.getroot()
    extracted_books = []
    for current_book in xml_root_element.findall('book'):
        extracted_books.append({
            'title': current_book.find('title').text,
            'author': current_book.find('author').text,
            'year': int(current_book.find('year').text),
            'price': float(current_book.find('price').text)
        })
    return extracted_books

def isolate_books_since(book_collection, reference_year):
    return [book for book in book_collection if book['year'] > reference_year]

def determine_average_cost(book_collection):
    if not book_collection:
        return 0
    total_cost = sum(book['price'] for book in book_collection)
    return total_cost / len(book_collection)

def compile_report_to_xml(book_collection, calculated_avg_price, destination_path):
    summary_root = ET.Element('booksSummary')
    average_price_element = ET.SubElement(summary_root, 'averagePrice')
    average_price_element.text = str(calculated_avg_price)
    for book in book_collection:
        book_element = ET.SubElement(summary_root, 'book')
        ET.SubElement(book_element, 'title').text = book['title']
        ET.SubElement(book_element, 'author').text = book['author']
        ET.SubElement(book_element, 'year').text = str(book['year'])
        ET.SubElement(book_element, 'price').text = str(book['price'])

    summary_tree = ET.ElementTree(summary_root)
    summary_tree.write(destination_path)

def orchestrate_process():
    input_xml_file = 'books.xml'
    output_xml_file = 'filtered_books.xml'
    year_limit = 2000

    all_books = obtain_book_data(input_xml_file)
    selected_books = isolate_books_since(all_books, year_limit)
    average_cost = determine_average_cost(selected_books)
    compile_report_to_xml(selected_books, average_cost, output_xml_file)
    print(f"Filtered books written to {output_xml_file}")

if __name__ == "__main__":
    orchestrate_process()