import psutil

def report_resource_utilization():
    current_cpu_load = psutil.cpu_percent(interval=1)
    print(f"CPU Utilization: {current_cpu_load}%")
    
    system_memory_stats = psutil.virtual_memory()
    print(f"RAM Utilization: {system_memory_stats.percent}%")

def execute_checks():
    report_resource_utilization()

if __name__ == "__main__":
    execute_checks()