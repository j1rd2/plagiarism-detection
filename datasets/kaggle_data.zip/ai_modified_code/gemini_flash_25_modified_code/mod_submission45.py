def process_data_stream(data_source):
    processed_values = [int(item.strip()) for item in data_source]
    return processed_values

def transform_values(values):
    return [val * val for val in values]

def persist_results(results, destination):
    with open(destination, 'w') as file_handle:
        for item in results:
            file_handle.write(f"{item}\n")

def orchestrate_operation():
    source_file = 'input.txt'
    target_file = 'output.txt'
    raw_data = process_data_stream(open(source_file))
    transformed_data = transform_values(raw_data)
    persist_results(transformed_data, target_file)
    print(f"Transformed values have been persisted to {target_file}")

if __name__ == "__main__":
    orchestrate_operation()