class Employee:
    def __init__(self, emp_id, employee_name, position):
        self.emp_id = emp_id
        self.employee_name = employee_name
        self.position = position

class ServiceRecipient:
    def __init__(self, recipient_id, recipient_name, years_old, medical_condition):
        self.recipient_id = recipient_id
        self.recipient_name = recipient_name
        self.years_old = years_old
        self.medical_condition = medical_condition

class Invoice:
    def __init__(self, invoice_ref, recipient, invoice_amount, payment_deadline):
        self.invoice_ref = invoice_ref
        self.recipient = recipient
        self.invoice_amount = invoice_amount
        self.payment_deadline = payment_deadline

class MedicalFacility:
    def __init__(self):
        self.personnel = []
        self.recipients = []
        self.invoices = []

    def register_personnel(self, employee):
        self.personnel.append(employee)

    def register_recipient(self, service_recipient):
        self.recipients.append(service_recipient)

    def issue_invoice(self, invoice):
        self.invoices.append(invoice)

    def display_personnel(self):
        for staff in self.personnel:
            print(f"ID: {staff.emp_id}, Name: {staff.employee_name}, Role: {staff.position}")

    def display_recipients(self):
        for recipient in self.recipients:
            print(f"ID: {recipient.recipient_id}, Name: {recipient.recipient_name}, Age: {recipient.years_old}, Ailment: {recipient.medical_condition}")

    def display_invoices(self):
        for bill in self.invoices:
            print(f"Bill ID: {bill.invoice_ref}, Patient: {bill.recipient.recipient_name}, Amount: ${bill.invoice_amount}, Due Date: {bill.payment_deadline}")

def orchestrate_operations():
    clinic = MedicalFacility()

    worker1 = Employee(1, "Dr. Smith", "Cardiologist")
    worker2 = Employee(2, "Nurse Jane", "Nurse")

    clinic.register_personnel(worker1)
    clinic.register_personnel(worker2)

    person1 = ServiceRecipient(1, "Emma Watson", 30, "High Blood Pressure")
    person2 = ServiceRecipient(2, "Chris Evans", 40, "Diabetes")

    clinic.register_recipient(person1)
    clinic.register_recipient(person2)

    payment1 = Invoice(1, person1, 500.0, "2024-10-05")
    payment2 = Invoice(2, person2, 800.0, "2024-10-10")

    clinic.issue_invoice(payment1)
    clinic.issue_invoice(payment2)

    print("Staff List:")
    clinic.display_personnel()

    print("\nPatient List:")
    clinic.display_recipients()

    print("\nBilling List:")
    clinic.display_invoices()

if __name__ == "__main__":
    orchestrate_operations()