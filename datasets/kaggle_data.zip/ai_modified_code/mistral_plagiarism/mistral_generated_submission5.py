def compute_product(factor_one, factor_two):
    return factor_one * factor_two