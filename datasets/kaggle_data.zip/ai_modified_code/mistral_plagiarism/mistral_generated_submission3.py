def compute_difference(minuend, subtrahend):
    return minuend - subtrahend