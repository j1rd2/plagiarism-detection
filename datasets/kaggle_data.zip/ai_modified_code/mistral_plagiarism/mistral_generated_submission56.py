import json

def read_json_file(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    return data['employees']

def find_employees_by_department(employees, department):
    filtered = []
    for employee in employees:
        if employee['department'] == department:
            filtered.append(employee)
    return filtered

def calculate_average_salary(employees):
    if not employees:
        return 0
    total_salary = sum(emp['salary'] for emp in employees)
    avg_salary = total_salary / len(employees)
    return avg_salary

def save_json_output(results, output_filename):
    with open(output_filename, 'w') as file:
        json.dump(results, file, indent=4)

def execute():
    input_filename = 'employees.json'
    output_filename = 'department_summary.json'
    department = 'Engineering'

    employees = read_json_file(input_filename)
    department_employees = find_employees_by_department(employees, department)
    avg_salary = calculate_average_salary(department_employees)
    output_data = {
        'department': department,
        'average_salary': avg_salary,
        'employee_count': len(department_employees)
    }

    save_json_output(output_data, output_filename)
    print(f"Summary written to {output_filename}")

if __name__ == "__main__":
    execute()