def load_numbers_from_file(filename):
    with open(filename, 'r') as file:
        numbers = [int(line.strip()) for line in file]
    return numbers

def compute_squares(numbers):
    return [number ** 2 for number in numbers]

def save_numbers_to_file(numbers, output_filename):
    with open(output_filename, 'w') as file:
        for number in numbers:
            file.write(f"{number}\n")

def execute():
    input_filename = 'input.txt'
    output_filename = 'output.txt'
    numbers = load_numbers_from_file(input_filename)
    squared_numbers = compute_squares(numbers)
    save_numbers_to_file(squared_numbers, output_filename)
    print(f"Squared numbers have been written to {output_filename}")

if __name__ == "__main__":
    execute()