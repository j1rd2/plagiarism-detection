import xml.etree.ElementTree as ET

class Publication:
    def __init__(self, title, author, year, price):
        self.title = title
        self.author = author
        self.year = year
        self.price = price

class BookManager:
    def __init__(self, input_filename):
        self.input_filename = input_filename
        self.books = []

    def load_books(self):
        tree = ET.parse(self.input_filename)
        root = tree.getroot()
        for book_elem in root.findall('book'):
            title = book_elem.find('title').text
            author = book_elem.find('author').text
            year = int(book_elem.find('year').text)
            price = float(book_elem.find('price').text)
            self.books.append(Publication(title, author, year, price))

    def filter_books(self, year):
        return [book for book in self.books if book.year > year]

    def compute_average_price(self, books):
        total_price = sum(book.price for book in books)
        return total_price / len(books) if books else 0

    def save_to_xml(self, books, average_price, output_filename):
        root = ET.Element('bookSummary')
        avg_price_elem = ET.SubElement(root, 'averagePrice')
        avg_price_elem.text = str(average_price)
        for book in books:
            book_elem = ET.SubElement(root, 'book')
            ET.SubElement(book_elem, 'title').text = book.title
            ET.SubElement(book_elem, 'author').text = book.author
            ET.SubElement(book_elem, 'year').text = str(book.year)
            ET.SubElement(book_elem, 'price').text = str(book.price)

        tree = ET.ElementTree(root)
        tree.write(output_filename)

def execute():
    input_filename = 'books.xml'
    output_filename = 'summary_books.xml'
    year_threshold = 2000

    manager = BookManager(input_filename)
    manager.load_books()
    filtered_books = manager.filter_books(year_threshold)
    average_price = manager.compute_average_price(filtered_books)
    manager.save_to_xml(filtered_books, average_price, output_filename)
    print(f"Book summary saved to {output_filename}")

if __name__ == "__main__":
    execute()