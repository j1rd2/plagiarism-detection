def sort_list(data):
    for index in range(1, len(data)):
        key = data[index]
        position = index - 1
        while position >= 0 and key < data[position]:
            data[position + 1] = data[position]
            position -= 1
        data[position + 1] = key

def execute():
    data = [12, 11, 13, 5, 6]
    print("Original array:", data)
    sort_list(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    execute()