import csv

def load_student_scores(filename):
    student_records = []
    with open(filename, 'r') as file:
        csv_reader = csv.DictReader(file)
        for record in csv_reader:
            student_records.append({
                'name': record['Name'],
                'score': float(record['Score'])
            })
    return student_records

def calculate_average(student_records):
    total = sum(record['score'] for record in student_records)
    return total / len(student_records)

def assign_grades(student_records, average_score):
    for record in student_records:
        if record['score'] >= average_score:
            record['grade'] = 'A'
        else:
            record['grade'] = 'B'
    return student_records

def save_results(student_records, output_filename):
    with open(output_filename, 'w', newline='') as file:
        csv_writer = csv.DictWriter(file, fieldnames=['Name', 'Score', 'Grade'])
        csv_writer.writeheader()
        csv_writer.writerows(student_records)

def execute():
    input_filename = 'students.csv'
    output_filename = 'graded_students.csv'
    student_records = load_student_scores(input_filename)
    average_score = calculate_average(student_records)
    graded_students = assign_grades(student_records, average_score)
    save_results(graded_students, output_filename)
    print(f"Graded data exported to {output_filename}")

if __name__ == "__main__":
    execute()