def sort_list(data):
    length = len(data)
    for outer in range(length):
        for inner in range(0, length - outer - 1):
            if data[inner] > data[inner + 1]:
                data[inner], data[inner + 1] = data[inner + 1], data[inner]

input_list = [64, 34, 25, 12, 22, 11, 90]
sort_list(input_list)
print("Sorted list:", input_list)