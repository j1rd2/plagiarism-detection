import csv

def load_student_data(filename):
    students = []
    with open(filename, mode='r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            student = {
                'name': row['Name'],
                'score': float(row['Score'])
            }
            students.append(student)
    return students

def compute_average_score(students):
    total_score = sum(student['score'] for student in students)
    average_score = total_score / len(students)
    return average_score

def determine_grades(students, average_score):
    for student in students:
        if student['score'] >= average_score:
            student['grade'] = 'A'
        else:
            student['grade'] = 'B'
    return students

def save_results_to_csv(students, output_filename):
    with open(output_filename, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=['Name', 'Score', 'Grade'])
        writer.writeheader()
        for student in students:
            writer.writerow(student)

def execute():
    input_filename = 'students.csv'
    output_filename = 'graded_students.csv'
    students = load_student_data(input_filename)
    average_score = compute_average_score(students)
    students_with_grades = determine_grades(students, average_score)
    save_results_to_csv(students_with_grades, output_filename)
    print(f"Processed student data written to {output_filename}")

if __name__ == "__main__":
    execute()