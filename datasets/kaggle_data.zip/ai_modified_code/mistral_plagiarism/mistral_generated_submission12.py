def factorial_recursive(input_number):
    if input_number <= 1:
        return 1
    else:
        return input_number * factorial_recursive(input_number - 1)

print(factorial_recursive(5))