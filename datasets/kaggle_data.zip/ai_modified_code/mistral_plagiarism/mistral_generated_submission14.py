def validate_input(value):
    if isinstance(value, int) and value >= 0:
        return True
    return False


def compute_factorial(value):
    if not validate_input(value):
        raise ValueError("Input must be a non-negative integer")

    if value == 0:
        return 1
    else:
        return value * compute_factorial(value - 1)


try:
    user_input = int(input("Enter a number: "))
    print(f"The factorial of {user_input} is {compute_factorial(user_input)}")
except ValueError as error:
    print(error)