def calculate_factorial(value):
    product = 1
    for counter in range(2, value + 1):
        product *= counter
    return product

def execute():
    user_input = int(input("Enter a positive integer: "))
    if user_input < 0:
        print("Factorial is not defined for negative numbers.")
    else:
        print(f"The factorial of {user_input} is {calculate_factorial(user_input)}")

if __name__ == "__main__":
    execute()