import pandas as pd
import matplotlib.pyplot as plt


# Load CSV data
def read_csv_data(filename):
    data = pd.read_csv(filename)
    return data


# Calculate the population growth rate
def compute_growth_rate(dataframe):
    dataframe['GrowthRate'] = dataframe['Population'].pct_change() * 100
    return dataframe


# Plot the population data and growth rate
def visualize_data(dataframe):
    plt.figure(figsize=(10, 6))

    # Plot Population
    plt.subplot(2, 1, 1)
    plt.plot(dataframe['Year'], dataframe['Population'], marker='o', linestyle='-')
    plt.title('Population Over Time')
    plt.xlabel('Year')
    plt.ylabel('Population')

    # Plot Growth Rate
    plt.subplot(2, 1, 2)
    plt.plot(dataframe['Year'], dataframe['GrowthRate'], marker='o', linestyle='-', color='orange')
    plt.title('Population Growth Rate')
    plt.xlabel('Year')
    plt.ylabel('Growth Rate (%)')

    plt.tight_layout()
    plt.show()


# Main function to run the steps
def execute():
    filename = "population_data.csv"
    data = read_csv_data(filename)
    data = compute_growth_rate(data)
    visualize_data(data)


if __name__ == "__main__":
    execute()