import json

def load_employee_data(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    return data['employees']

def select_by_department(employees, dept):
    return [emp for emp in employees if emp['department'] == dept]

def calculate_average_salary(employees):
    if not employees:
        return 0
    total = sum(emp['salary'] for emp in employees)
    return total / len(employees)

def save_results_to_json(results, output_filename):
    with open(output_filename, 'w') as file:
        json.dump(results, file, indent=4)

def execute():
    input_filename = 'employees.json'
    output_filename = 'department_summary.json'
    department = 'Engineering'

    employees = load_employee_data(input_filename)
    dept_employees = select_by_department(employees, department)
    avg_salary = calculate_average_salary(dept_employees)
    summary = {
        'department': department,
        'average_salary': avg_salary,
        'employee_count': len(dept_employees)
    }

    save_results_to_json(summary, output_filename)
    print(f"Data written to {output_filename}")

if __name__ == "__main__":
    execute()