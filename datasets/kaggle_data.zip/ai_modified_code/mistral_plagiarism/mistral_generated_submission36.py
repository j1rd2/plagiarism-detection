import math

def check_prime_optimized(value):
    if value <= 1:
        return False
    if value == 2:
        return True
    if value % 2 == 0:
        return False
    for divisor in range(3, int(math.sqrt(value)) + 1, 2):
        if value % divisor == 0:
            return False
    return True

def find_primes_optimized(max_value):
    return [number for number in range(2, max_value + 1) if check_prime_optimized(number)]

def execute():
    max_value = 50
    prime_numbers = find_primes_optimized(max_value)
    print(f"Prime numbers up to {max_value}: {prime_numbers}")

if __name__ == "__main__":
    execute()