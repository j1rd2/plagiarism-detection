def validate_number(value):
    return isinstance(value, int) and value >= 0


def compute_factorial(value):
    if not validate_number(value):
        raise ValueError("Please enter a non-negative integer")

    product = 1
    while value > 1:
        product *= value
        value -= 1
    return product


def execute():
    try:
        user_input = int(input("Enter a number to find its factorial: "))
        print(f"Factorial: {compute_factorial(user_input)}")
    except ValueError as error:
        print(error)


if __name__ == "__main__":
    execute()