def heapify(data, size, index):
    largest = index
    left = 2 * index + 1
    right = 2 * index + 2

    if left < size and data[left] > data[largest]:
        largest = left

    if right < size and data[right] > data[largest]:
        largest = right

    if largest != index:
        data[index], data[largest] = data[largest], data[index]
        heapify(data, size, largest)

def sort_list(data):
    size = len(data)

    for i in range(size // 2 - 1, -1, -1):
        heapify(data, size, i)

    for i in range(size - 1, 0, -1):
        data[i], data[0] = data[0], data[i]
        heapify(data, i, 0)

def execute():
    data = [12, 11, 13, 5, 6, 7]
    print("Original array:", data)
    sort_list(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    execute()