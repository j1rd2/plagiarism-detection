import math

def calculate_factorial(number):
    return math.factorial(number)

print(calculate_factorial(5))