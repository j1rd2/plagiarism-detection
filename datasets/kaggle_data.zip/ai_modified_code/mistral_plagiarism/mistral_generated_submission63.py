from lxml import etree

def load_books(filename):
    tree = etree.parse(filename)
    root = tree.getroot()
    books = []
    for book in root.xpath('//book'):
        books.append({
            'title': book.find('title').text,
            'author': book.find('author').text,
            'year': int(book.find('year').text),
            'price': float(book.find('price').text)
        })
    return books

def select_books_by_year(books, year):
    return [book for book in books if book['year'] > year]

def compute_average_price(books):
    if not books:
        return 0
    total_price = sum(book['price'] for book in books)
    return total_price / len(books)

def save_to_xml(books, avg_price, output_filename):
    root = etree.Element('bookSummary')
    avg_elem = etree.SubElement(root, 'averagePrice')
    avg_elem.text = str(avg_price)
    for book in books:
        book_elem = etree.SubElement(root, 'book')
        title_elem = etree.SubElement(book_elem, 'title')
        title_elem.text = book['title']
        author_elem = etree.SubElement(book_elem, 'author')
        author_elem.text = book['author']
        year_elem = etree.SubElement(book_elem, 'year')
        year_elem.text = str(book['year'])
        price_elem = etree.SubElement(book_elem, 'price')
        price_elem.text = str(book['price'])

    tree = etree.ElementTree(root)
    tree.write(output_filename, pretty_print=True)

def execute():
    input_filename = 'books.xml'
    output_filename = 'recent_books.xml'
    year_filter = 2000

    books = load_books(input_filename)
    filtered_books = select_books_by_year(books, year_filter)
    average_price = compute_average_price(filtered_books)
    save_to_xml(filtered_books, average_price, output_filename)
    print(f"XML output saved to {output_filename}")

if __name__ == "__main__":
    execute()