import logging

def check_non_negative(value):
    """Validate that the input is a non-negative integer."""
    if not isinstance(value, int) or value < 0:
        raise ValueError("Input must be a non-negative integer.")

def compute_factorial(value):
    """Calculate factorial using a while loop."""
    check_non_negative(value)
    result = 1
    while value > 1:
        result *= value
        value -= 1
    return result

def compute_digit_sum(factorial_outcome):
    """Sum the digits of the factorial."""
    return sum(int(digit) for digit in str(factorial_outcome))

def record_results(value, factorial_outcome, digit_sum_outcome):
    """Log the factorial and digit sum to a log file."""
    logging.basicConfig(filename='factorial_computation.log', level=logging.INFO)
    logging.info(f"Factorial of {value}: {factorial_outcome}, Sum of digits: {digit_sum_outcome}")

def process_factorial():
    while True:
        try:
            input_value = int(input("Please enter a non-negative integer: "))
            factorial_outcome = compute_factorial(input_value)
            digit_sum_outcome = compute_digit_sum(factorial_outcome)
            record_results(input_value, factorial_outcome, digit_sum_outcome)
            print(f"Factorial: {factorial_outcome}, Sum of digits: {digit_sum_outcome}")
        except ValueError as exception:
            print(f"Error: {exception}")

        if input("Perform another calculation? (yes/no): ").lower() != 'yes':
            break

if __name__ == "__main__":
    process_factorial()