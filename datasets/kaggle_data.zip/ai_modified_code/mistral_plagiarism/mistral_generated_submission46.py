def load_numbers_from_file(filename):
    with open(filename, 'r') as file:
        numbers = list(map(int, file.readlines()))
    return numbers

def compute_squares_using_map(numbers):
    return list(map(lambda value: value ** 2, numbers))

def save_to_file(numbers, filename):
    with open(filename, 'w') as file:
        file.writelines(f"{number}\n" for number in numbers)

def execute():
    input_filename = 'input.txt'
    output_filename = 'output.txt'
    numbers = load_numbers_from_file(input_filename)
    squared_numbers = compute_squares_using_map(numbers)
    save_to_file(squared_numbers, output_filename)
    print(f"Processed numbers are saved in {output_filename}")

if __name__ == "__main__":
    execute()