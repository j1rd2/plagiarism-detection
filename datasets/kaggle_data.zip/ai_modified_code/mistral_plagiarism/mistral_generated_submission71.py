class Employee:
    def __init__(self, employee_id, name, role):
        self.employee_id = employee_id
        self.name = name
        self.role = role

class Patient:
    def __init__(self, patient_id, name, age, ailment):
        self.patient_id = patient_id
        self.name = name
        self.age = age
        self.ailment = ailment

class Billing:
    def __init__(self, bill_id, patient, amount, due_date):
        self.bill_id = bill_id
        self.patient = patient
        self.amount = amount
        self.due_date = due_date

class Clinic:
    def __init__(self):
        self.employees = []
        self.patients = []
        self.bills = []

    def add_employee(self, employee):
        self.employees.append(employee)

    def add_patient(self, patient):
        self.patients.append(patient)

    def create_bill(self, bill):
        self.bills.append(bill)

    def list_employees(self):
        for employee in self.employees:
            print(f"ID: {employee.employee_id}, Name: {employee.name}, Role: {employee.role}")

    def list_patients(self):
        for patient in self.patients:
            print(f"ID: {patient.patient_id}, Name: {patient.name}, Age: {patient.age}, Ailment: {patient.ailment}")

    def list_bills(self):
        for bill in self.bills:
            print(f"Bill ID: {bill.bill_id}, Patient: {bill.patient.name}, Amount: ${bill.amount}, Due Date: {bill.due_date}")

def execute():
    clinic = Clinic()

    employee1 = Employee(1, "Dr. Smith", "Cardiologist")
    employee2 = Employee(2, "Nurse Jane", "Nurse")

    clinic.add_employee(employee1)
    clinic.add_employee(employee2)

    patient1 = Patient(1, "Emma Watson", 30, "High Blood Pressure")
    patient2 = Patient(2, "Chris Evans", 40, "Diabetes")

    clinic.add_patient(patient1)
    clinic.add_patient(patient2)

    bill1 = Billing(1, patient1, 500.0, "2024-10-05")
    bill2 = Billing(2, patient2, 800.0, "2024-10-10")

    clinic.create_bill(bill1)
    clinic.create_bill(bill2)

    print("Staff List:")
    clinic.list_employees()

    print("\nPatient List:")
    clinic.list_patients()

    print("\nBilling List:")
    clinic.list_bills()

if __name__ == "__main__":
    execute()