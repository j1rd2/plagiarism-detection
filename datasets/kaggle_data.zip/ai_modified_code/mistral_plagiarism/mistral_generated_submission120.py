from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
import pickle

# Load the iris dataset
data = load_iris()
features = data.data
target = data.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.25, random_state=42)

# Train a Support Vector Machine model
classifier = SVC(kernel='linear', random_state=42)
classifier.fit(X_train, y_train)

# Dump the trained model using pickle
with open('svm_model.pkl', 'wb') as file:
    pickle.dump(classifier, file)