def sort_list(data):
    if len(data) > 1:
        mid = len(data) // 2
        left_half = data[:mid]
        right_half = data[mid:]

        sort_list(left_half)
        sort_list(right_half)

        i = j = k = 0
        while i < len(left_half) and j < len(right_half):
            if left_half[i] < right_half[j]:
                data[k] = left_half[i]
                i += 1
            else:
                data[k] = right_half[j]
                j += 1
            k += 1

        while i < len(left_half):
            data[k] = left_half[i]
            i += 1
            k += 1

        while j < len(right_half):
            data[k] = right_half[j]
            j += 1
            k += 1

def execute():
    data = [38, 27, 43, 3, 9, 82, 10]
    print("Original array:", data)
    sort_list(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    execute()