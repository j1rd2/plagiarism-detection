def compute_fibonacci_recursively(position, cache={}):
    if position in cache:
        return cache[position]
    if position <= 1:
        return position
    cache[position] = compute_fibonacci_recursively(position - 1, cache) + compute_fibonacci_recursively(position - 2, cache)
    return cache[position]

def generate_fibonacci_sequence(max_value):
    sequence = []
    index = 0
    while True:
        next_number = compute_fibonacci_recursively(index)
        if next_number >= max_value:
            break
        sequence.append(next_number)
        index += 1
    return sequence

def show_fibonacci_sequence(sequence):
    print("The Fibonacci sequence up to the specified limit is:")
    for position, number in enumerate(sequence):
        print(f"Fibonacci[{position}] = {number}")

def execute():
    max_value = 100
    fibonacci_sequence = generate_fibonacci_sequence(max_value)
    show_fibonacci_sequence(fibonacci_sequence)

if __name__ == "__main__":
    execute()