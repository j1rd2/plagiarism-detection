import logging

def validate_integer(value):
    """Check if the input is a non-negative integer."""
    return isinstance(value, int) and value >= 0

def compute_factorial(value):
    """Calculate the factorial of a non-negative integer."""
    if value == 0:
        return 1
    else:
        return value * compute_factorial(value - 1)

def record_result(number, outcome):
    """Log the factorial result to a file."""
    logging.basicConfig(filename='factorial.log', level=logging.INFO)
    logging.info(f"Factorial of {number} is {outcome}")

def process_factorial():
    try:
        user_input = int(input("Enter a non-negative integer: "))
        if not validate_integer(user_input):
            raise ValueError("Input must be a non-negative integer.")
        outcome = compute_factorial(user_input)
        record_result(user_input, outcome)
        print(f"Factorial of {user_input} is {outcome}")
    except ValueError as error:
        print(error)

def execute():
    while True:
        process_factorial()
        continue_prompt = input("Do you want to calculate another factorial? (yes/no): ")
        if continue_prompt.lower() != 'yes':
            break

if __name__ == "__main__":
    execute()