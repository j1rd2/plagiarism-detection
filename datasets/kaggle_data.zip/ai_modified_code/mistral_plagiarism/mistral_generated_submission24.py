class BankMachine:
    def __init__(self, starting_balance=0):
        self.account_balance = starting_balance

    def display_balance(self):
        """Displays the current balance."""
        print(f"Your current balance is: ${self.account_balance:.2f}")

    def add_funds(self, deposit_amount):
        """Deposits a specified amount into the account."""
        if deposit_amount > 0:
            self.account_balance += deposit_amount
            print(f"${deposit_amount:.2f} has been deposited to your account.")
        else:
            print("Deposit amount must be positive.")

    def remove_funds(self, withdrawal_amount):
        """Withdraws a specified amount from the account."""
        if withdrawal_amount > self.account_balance:
            print("Insufficient balance for this withdrawal.")
        elif withdrawal_amount <= 0:
            print("Withdrawal amount must be positive.")
        else:
            self.account_balance -= withdrawal_amount
            print(f"${withdrawal_amount:.2f} has been withdrawn from your account.")

    def display_options(self):
        """Displays the ATM menu."""
        print("\n===== Bank Machine Menu =====")
        print("1. Check Balance")
        print("2. Deposit")
        print("3. Withdraw")
        print("4. Exit")
        print("=============================\n")

def execute():
    bank_machine = BankMachine(100)  # Initial balance of $100
    while True:
        bank_machine.display_options()
        selection = input("Please select an option (1-4): ")

        if selection == '1':
            bank_machine.display_balance()
        elif selection == '2':
            deposit_amount = float(input("Enter the amount to deposit: $"))
            bank_machine.add_funds(deposit_amount)
        elif selection == '3':
            withdrawal_amount = float(input("Enter the amount to withdraw: $"))
            bank_machine.remove_funds(withdrawal_amount)
        elif selection == '4':
            print("Thank you for using the Bank Machine. Goodbye!")
            break
        else:
            print("Invalid option. Please select a valid option.")

if __name__ == "__main__":
    execute()