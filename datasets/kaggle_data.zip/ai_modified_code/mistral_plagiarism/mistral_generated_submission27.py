import pandas as pd
import matplotlib.pyplot as plt


# Function to read CSV file into DataFrame
def load_data_from_csv(file_path):
    dataset = pd.read_csv(file_path)
    return dataset


# Function to compute growth percentage
def calculate_growth_rate(dataset):
    dataset['GrowthPercentage'] = dataset['Population'].pct_change() * 100
    return dataset


# Function to create plots
def generate_plots(dataset):
    plt.figure(figsize=(10, 6))

    # Plotting the Population data
    plt.subplot(2, 1, 1)
    plt.plot(dataset['Year'], dataset['Population'], marker='o', linestyle='-')
    plt.title('Yearly Population')
    plt.xlabel('Year')
    plt.ylabel('Population')

    # Plotting the Growth Rate
    plt.subplot(2, 1, 2)
    plt.plot(dataset['Year'], dataset['GrowthPercentage'], marker='o', linestyle='-', color='orange')
    plt.title('Yearly Population Growth Rate')
    plt.xlabel('Year')
    plt.ylabel('Growth Rate (%)')

    plt.tight_layout()
    plt.show()


# Main execution function
def execute():
    file_path = "population_data.csv"
    dataset = load_data_from_csv(file_path)
    dataset = calculate_growth_rate(dataset)
    generate_plots(dataset)


if __name__ == "__main__":
    execute()