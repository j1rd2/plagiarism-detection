import xml.etree.ElementTree as ET

def read_books_from_xml(filename):
    tree = ET.parse(filename)
    root = tree.getroot()
    books = []
    for book in root.findall('book'):
        books.append({
            'title': book.find('title').text,
            'author': book.find('author').text,
            'year': int(book.find('year').text),
            'price': float(book.find('price').text)
        })
    return books

def select_books_after_year(books, year):
    return [book for book in books if book['year'] > year]

def calculate_average_price(books):
    if not books:
        return 0
    total = sum(book['price'] for book in books)
    return total / len(books)

def write_results_to_xml(books, average_price, output_filename):
    root = ET.Element('booksSummary')
    avg_price_elem = ET.SubElement(root, 'averagePrice')
    avg_price_elem.text = str(average_price)
    for book in books:
        book_elem = ET.SubElement(root, 'book')
        ET.SubElement(book_elem, 'title').text = book['title']
        ET.SubElement(book_elem, 'author').text = book['author']
        ET.SubElement(book_elem, 'year').text = str(book['year'])
        ET.SubElement(book_elem, 'price').text = str(book['price'])

    tree = ET.ElementTree(root)
    tree.write(output_filename)

def execute():
    input_filename = 'books.xml'
    output_filename = 'filtered_books.xml'
    year_threshold = 2000

    books = read_books_from_xml(input_filename)
    recent_books = select_books_after_year(books, year_threshold)
    avg_price = calculate_average_price(recent_books)
    write_results_to_xml(recent_books, avg_price, output_filename)
    print(f"Filtered books written to {output_filename}")

if __name__ == "__main__":
    execute()