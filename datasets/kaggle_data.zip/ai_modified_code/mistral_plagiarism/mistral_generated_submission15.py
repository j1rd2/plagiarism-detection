def check_input_validity(number):
    if isinstance(number, int) and number >= 0:
        return True
    return False


def calculate_factorial_recursively(number):
    if not check_input_validity(number):
        raise ValueError("Input must be a non-negative integer")

    if number == 0:
        return 1
    else:
        return number * calculate_factorial_recursively(number - 1)


try:
    input_value = int(input("Please enter an integer: "))
    print(f"The factorial of {input_value} is {calculate_factorial_recursively(input_value)}")
except ValueError as exception:
    print(exception)