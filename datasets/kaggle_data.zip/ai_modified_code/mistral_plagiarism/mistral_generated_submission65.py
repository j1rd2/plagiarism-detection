import xml.etree.ElementTree as ET

def extract_books_from_xml(filename):
    tree = ET.parse(filename)
    root = tree.getroot()
    return [
        {
            'title': book.find('title').text,
            'author': book.find('author').text,
            'year': int(book.find('year').text),
            'price': float(book.find('price').text)
        }
        for book in root.findall('book')
    ]

def select_books_after_year(books, year):
    return list(filter(lambda book: book['year'] > year, books))

def calculate_average(books):
    total_price = sum(map(lambda book: book['price'], books))
    return total_price / len(books) if books else 0

def write_to_xml(books, average_price, output_filename):
    root = ET.Element('booksReport')
    avg_price_elem = ET.SubElement(root, 'averagePrice')
    avg_price_elem.text = str(average_price)
    for book in books:
        book_elem = ET.SubElement(root, 'book')
        ET.SubElement(book_elem, 'title').text = book['title']
        ET.SubElement(book_elem, 'author').text = book['author']
        ET.SubElement(book_elem, 'year').text = str(book['year'])
        ET.SubElement(book_elem, 'price').text = str(book['price'])

    tree = ET.ElementTree(root)
    tree.write(output_filename)

def execute():
    input_filename = 'books.xml'
    output_filename = 'filtered_books.xml'
    year_filter = 2000

    books = extract_books_from_xml(input_filename)
    recent_books = select_books_after_year(books, year_filter)
    avg_price = calculate_average(recent_books)
    write_to_xml(recent_books, avg_price, output_filename)
    print(f"Books report saved to {output_filename}")

if __name__ == "__main__":
    execute()