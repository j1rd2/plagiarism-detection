import logging

def check_input_validity(value):
    """Ensure the input is a non-negative integer."""
    return isinstance(value, int) and value >= 0

def calculate_factorial(value):
    """Compute the factorial using a recursive approach."""
    if value == 0:
        return 1
    else:
        return value * calculate_factorial(value - 1)

def log_result(value, outcome):
    """Record the factorial computation to a log file."""
    logging.basicConfig(filename='factorial_calculations.log', level=logging.INFO)
    logging.info(f"Computed factorial of {value}: {outcome}")

def handle_factorial():
    try:
        user_value = int(input("Please enter a non-negative integer: "))
        if not check_input_validity(user_value):
            raise ValueError("Only non-negative integers are accepted.")
        outcome = calculate_factorial(user_value)
        log_result(user_value, outcome)
        print(f"Factorial of {user_value} is {outcome}")
    except ValueError as exception:
        print(exception)

def execute():
    while True:
        handle_factorial()
        continue_prompt = input("Would you like to calculate another factorial? (yes/no): ")
        if continue_prompt.lower() != 'yes':
            break

if __name__ == "__main__":
    execute()