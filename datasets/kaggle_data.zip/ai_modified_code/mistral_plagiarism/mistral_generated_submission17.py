def validate_input(value):
    if not isinstance(value, int) or value < 0:
        return False
    return True


def calculate_factorial(value):
    if not validate_input(value):
        raise ValueError("Input should be a non-negative integer")

    result = 1
    for counter in range(1, value + 1):
        result *= counter
    return result


def execute():
    try:
        user_input = int(input("Enter a positive integer: "))
        print(f"The factorial is {calculate_factorial(user_input)}")
    except ValueError as exception:
        print(f"Error: {exception}")


if __name__ == "__main__":
    execute()