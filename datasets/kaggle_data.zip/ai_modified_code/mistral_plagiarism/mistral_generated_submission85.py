def sort_list_optimized(data):
    length = len(data)
    for outer in range(length):
        swapped = False
        for inner in range(0, length - outer - 1):
            if data[inner] > data[inner + 1]:
                data[inner], data[inner + 1] = data[inner + 1], data[inner]
                swapped = True
        if not swapped:
            break

def execute():
    data = [5, 1, 4, 2, 8]
    print("Original array:", data)
    sort_list_optimized(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    execute()