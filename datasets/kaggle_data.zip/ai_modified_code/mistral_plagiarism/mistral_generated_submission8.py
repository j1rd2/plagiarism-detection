def calculate_fibonacci(limit):
    first, second = 0, 1
    for _ in range(limit):
        first, second = second, first + second
    return first

output = calculate_fibonacci(10)
print("Fibonacci result:", output)