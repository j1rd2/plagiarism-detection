import random

def introduce_mutations(dna_sequence, mutation_prob=0.02):
    bases = ['A', 'T', 'C', 'G']
    sequence = list(dna_sequence)
    
    for i in range(len(sequence)):
        if random.random() < mutation_prob:
            sequence[i] = random.choice(bases)
    
    return ''.join(sequence)

def execute():
    dna_sequence = "ATGCTAGCTAGT"
    mutated_sequence = introduce_mutations(dna_sequence, mutation_prob=0.05)
    print("Original DNA sequence:", dna_sequence)
    print("Mutated DNA sequence:", mutated_sequence)

if __name__ == "__main__":
    execute()