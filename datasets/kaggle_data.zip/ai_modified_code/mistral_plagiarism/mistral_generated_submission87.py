def sort_list(data):
    if len(data) <= 1:
        return data
    else:
        pivot = data[0]
        less = [x for x in data[1:] if x <= pivot]
        greater = [x for x in data[1:] if x > pivot]
        return sort_list(less) + [pivot] + sort_list(greater)

def execute():
    data = [10, 7, 8, 9, 1, 5]
    print("Original array:", data)
    sorted_data = sort_list(data)
    print("Sorted array:", sorted_data)

if __name__ == "__main__":
    execute()