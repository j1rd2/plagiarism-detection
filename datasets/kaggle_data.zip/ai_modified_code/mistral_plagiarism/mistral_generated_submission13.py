def calculate_factorial_iteratively(max_value):
    product = 1
    for counter in range(2, max_value + 1):
        product *= counter
    return product

print(calculate_factorial_iteratively(5))