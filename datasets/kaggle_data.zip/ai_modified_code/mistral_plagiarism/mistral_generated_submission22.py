import logging

def validate_non_negative_integer(value):
    """Ensure the input is a non-negative integer."""
    if not isinstance(value, int) or value < 0:
        raise ValueError("Input must be a non-negative integer.")

def compute_factorial_iteratively(value):
    """Calculate factorial using a loop."""
    validate_non_negative_integer(value)
    product = 1
    for counter in range(2, value + 1):
        product *= counter
    return product

def calculate_digit_sum_of_factorial(factorial_value):
    """Compute the sum of digits of the factorial."""
    return sum(int(digit) for digit in str(factorial_value))

def record_results(input_value, factorial_outcome, digit_sum_outcome):
    """Log the factorial and digit sum to a log file."""
    logging.basicConfig(filename='factorial_log_output.log', level=logging.INFO)
    logging.info(f"Factorial of {input_value}: {factorial_outcome}, Sum of digits: {digit_sum_outcome}")

def execute():
    while True:
        try:
            user_input = int(input("Enter a non-negative integer: "))
            factorial_outcome = compute_factorial_iteratively(user_input)
            digit_sum_outcome = calculate_digit_sum_of_factorial(factorial_outcome)
            record_results(user_input, factorial_outcome, digit_sum_outcome)
            print(f"Factorial: {factorial_outcome}, Sum of digits: {digit_sum_outcome}")
        except ValueError as exception:
            print(f"Error: {exception}")

        if input("Calculate another? (yes/no): ").lower() != 'yes':
            break

if __name__ == "__main__":
    execute()