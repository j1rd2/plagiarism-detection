def validate_prime(value):
    if value <= 1:
        return False
    for divisor in range(2, value):
        if value % divisor == 0:
            return False
    return True

def collect_primes(max_value):
    primes = []
    for num in range(2, max_value + 1):
        if validate_prime(num):
            primes.append(num)
    return primes

def execute():
    max_value = 50
    prime_numbers = collect_primes(max_value)
    print(f"Primes up to {max_value}: {prime_numbers}")

if __name__ == "__main__":
    execute()