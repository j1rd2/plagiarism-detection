def bubble_sort_algorithm(collection):
    size = len(collection)
    for outer_loop in range(size):
        for inner_loop in range(0, size - outer_loop - 1):
            if collection[inner_loop] > collection[inner_loop + 1]:
                collection[inner_loop], collection[inner_loop + 1] = collection[inner_loop + 1], collection[inner_loop]

sample_data = [64, 34, 25, 12, 22, 11, 90]
bubble_sort_algorithm(sample_data)
print("Ordered collection:", sample_data)