def load_from_file(filepath):
    with open(filepath, 'r') as file:
        numbers = [int(line.strip()) for line in file]
    return numbers

def compute_squares_list(numbers):
    squared = [value ** 2 for value in numbers]
    return squared

def save_to_output(squared, output_filepath):
    with open(output_filepath, 'w') as file:
        for number in squared:
            file.write(f"{number}\n")

def execute():
    input_file = 'input.txt'
    output_file = 'output.txt'
    numbers = load_from_file(input_file)
    squared_numbers = compute_squares_list(numbers)
    save_to_output(squared_numbers, output_file)
    print(f"Squared numbers are saved in {output_file}")

if __name__ == "__main__":
    execute()