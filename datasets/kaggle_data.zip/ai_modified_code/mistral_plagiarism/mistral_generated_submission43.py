def custom_comparison(individual1, individual2):
    if individual1['age'] < individual2['age']:
        return -1
    elif individual1['age'] > individual2['age']:
        return 1
    else:
        return 0

def order_people_with_custom_comparison(individuals):
    sorted_individuals = sorted(individuals, key=lambda individual: individual['age'])
    return sorted_individuals

def display_sorted_individuals(individuals):
    print("Sorted list of people by age using custom comparison:")
    for individual in individuals:
        print(f"Name: {individual['name']}, Age: {individual['age']}")

def execute():
    individuals = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    sorted_individuals = order_people_with_custom_comparison(individuals)
    display_sorted_individuals(sorted_individuals)

if __name__ == "__main__":
    execute()