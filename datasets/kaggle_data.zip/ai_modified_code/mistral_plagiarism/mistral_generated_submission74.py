class Item:
    def __init__(self, item_id, name, price, quantity):
        self.item_id = item_id
        self.name = name
        self.price = price
        self.quantity = quantity

    def update_quantity(self, quantity):
        self.quantity += quantity

    def update_price(self, price):
        self.price = price

class Client:
    def __init__(self, client_id, name):
        self.client_id = client_id
        self.name = name

class Market:
    def __init__(self):
        self.inventory = {}
        self.clients = {}

    def add_item(self, item):
        self.inventory[item.item_id] = item

    def update_stock(self, item_id, quantity):
        if item_id in self.inventory:
            self.inventory[item_id].update_quantity(quantity)

    def add_client(self, client):
        self.clients[client.client_id] = client

    def list_inventory(self):
        for item in self.inventory.values():
            print(f"ID: {item.item_id}, Name: {item.name}, Price: ${item.price}, Quantity: {item.quantity}")

    def list_clients(self):
        for client in self.clients.values():
            print(f"ID: {client.client_id}, Name: {client.name}")

def execute():
    market = Market()

    item1 = Item(1, "Milk", 1.99, 50)
    item2 = Item(2, "Bread", 2.49, 30)

    market.add_item(item1)
    market.add_item(item2)

    client1 = Client(101, "Alice")
    client2 = Client(102, "Bob")

    market.add_client(client1)
    market.add_client(client2)

    market.update_stock(1, 10)  # Add 10 units to Milk
    market.update_stock(2, -2)  # Remove 2 units from Bread

    print("Inventory List:")
    market.list_inventory()

    print("\nClient List:")
    market.list_clients()

if __name__ == "__main__":
    execute()