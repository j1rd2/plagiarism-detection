class FinancialTerminal:
    def __init__(self, initial_funds=0):
        self.account_funds = initial_funds

    def show_balance(self):
        """Shows the current balance."""
        print(f"Balance available: ${self.account_funds:.2f}")

    def deposit_money(self, amount_to_deposit):
        """Adds funds to the account."""
        if amount_to_deposit > 0:
            self.account_funds += amount_to_deposit
            print(f"${amount_to_deposit:.2f} added to your account.")
        else:
            print("Invalid deposit amount. Please enter a positive value.")

    def withdraw_money(self, amount_to_withdraw):
        """Removes funds from the account."""
        if amount_to_withdraw > self.account_funds:
            print("Insufficient funds for this transaction.")
        elif amount_to_withdraw <= 0:
            print("Withdrawal amount must be greater than zero.")
        else:
            self.account_funds -= amount_to_withdraw
            print(f"${amount_to_withdraw:.2f} withdrawn from your account.")

    def show_menu(self):
        """Displays available options in the ATM menu."""
        print("\n=== Welcome to Your Bank ===")
        print("1. View Balance")
        print("2. Make a Deposit")
        print("3. Make a Withdrawal")
        print("4. Exit")
        print("============================\n")

def operate_terminal():
    terminal = FinancialTerminal(100)  # Initial balance set to $100
    while True:
        terminal.show_menu()
        selection = input("Select an option (1-4): ")

        if selection == '1':
            terminal.show_balance()
        elif selection == '2':
            deposit = float(input("Enter deposit amount: $"))
            terminal.deposit_money(deposit)
        elif selection == '3':
            withdrawal = float(input("Enter withdrawal amount: $"))
            terminal.withdraw_money(withdrawal)
        elif selection == '4':
            print("Thank you for banking with us. Goodbye!")
            break
        else:
            print("Invalid selection. Please choose a valid option.")

if __name__ == "__main__":
    operate_terminal()