class Item:
    def __init__(self, item_id, name, price, quantity):
        self.item_id = item_id
        self.name = name
        self.price = price
        self.quantity = quantity

    def update_quantity(self, quantity):
        self.quantity += quantity

    def update_price(self, price):
        self.price = price

class Store:
    def __init__(self):
        self.inventory = {}

    def add_item(self, item):
        self.inventory[item.item_id] = item

    def update_stock(self, item_id, quantity):
        if item_id in self.inventory:
            self.inventory[item_id].update_quantity(quantity)

    def list_inventory(self):
        for item in self.inventory.values():
            print(f"ID: {item.item_id}, Name: {item.name}, Price: ${item.price}, Quantity: {item.quantity}")

def execute():
    store = Store()

    item1 = Item(1, "Milk", 1.99, 50)
    item2 = Item(2, "Bread", 2.49, 30)

    store.add_item(item1)
    store.add_item(item2)

    store.update_stock(1, 20)  # Add 20 units to Milk
    store.update_stock(2, -5)  # Remove 5 units from Bread

    print("Inventory List:")
    store.list_inventory()

if __name__ == "__main__":
    execute()