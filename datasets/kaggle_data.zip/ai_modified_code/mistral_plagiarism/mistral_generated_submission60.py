import json

def load_employees_from_json(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    return data['employees']

def filter_employees(employees, dept):
    filtered_employees = []
    for employee in employees:
        if employee['department'] == dept:
            filtered_employees.append(employee)
    return filtered_employees

def calculate_average_salary(employees):
    if not employees:
        return 0
    total_salaries = sum(emp['salary'] for emp in employees)
    average = total_salaries / len(employees)
    return average

def save_json_data(data, output_filename):
    with open(output_filename, 'w') as file:
        json.dump(data, file, indent=4)

def execute():
    input_filename = 'employees.json'
    output_filename = 'department_summary.json'
    dept = 'Engineering'

    employees = load_employees_from_json(input_filename)
    employees_in_dept = filter_employees(employees, dept)
    average_salary = calculate_average_salary(employees_in_dept)
    
    summary = {
        'department': dept,
        'average_salary': average_salary,
        'employee_count': len(employees_in_dept)
    }

    save_json_data(summary, output_filename)
    print(f"Summary written to {output_filename}")

if __name__ == "__main__":
    execute()