def sum_values(value_a, value_b):
    total = value_a + value_b
    return total