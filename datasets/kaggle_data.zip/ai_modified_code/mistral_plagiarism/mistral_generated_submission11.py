def compute_factorial(value):
    result = 1
    for num in range(value, 0, -1):
        result *= num
    return result

print(compute_factorial(5))