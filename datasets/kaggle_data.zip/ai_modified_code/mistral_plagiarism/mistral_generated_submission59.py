import json

def read_employees(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    return data['employees']

def check_department(department):
    def inner(employee):
        return employee['department'] == department
    return inner

def extract_salary(employee):
    return employee['salary']

def compute_average(salaries):
    if not salaries:
        return 0
    return sum(salaries) / len(salaries)

def write_to_json(data, output_filename):
    with open(output_filename, 'w') as file:
        json.dump(data, file, indent=4)

def execute():
    input_filename = 'employees.json'
    output_filename = 'department_summary.json'
    department = 'Engineering'

    employees = read_employees(input_filename)
    department_employees = list(filter(check_department(department), employees))
    salaries = list(map(extract_salary, department_employees))
    avg_salary = compute_average(salaries)
    
    result = {
        'department': department,
        'average_salary': avg_salary,
        'employee_count': len(department_employees)
    }

    write_to_json(result, output_filename)
    print(f"Output saved to {output_filename}")

if __name__ == "__main__":
    execute()