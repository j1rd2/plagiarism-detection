class Client:
    def __init__(self, client_id, name, balance):
        self.client_id = client_id
        self.name = name
        self.balance = balance
        self.loans = 0

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
        else:
            print("Insufficient funds.")

    def apply_loan(self, amount):
        self.loans += amount
        self.balance += amount

class Employee:
    def __init__(self, employee_id, name, position):
        self.employee_id = employee_id
        self.name = name
        self.position = position

class FinancialInstitution:
    def __init__(self):
        self.clients = {}
        self.employees = {}

    def add_client(self, client):
        self.clients[client.client_id] = client

    def add_employee(self, employee):
        self.employees[employee.employee_id] = employee

    def list_clients(self):
        for client in self.clients.values():
            print(f"ID: {client.client_id}, Name: {client.name}, Balance: ${client.balance}, Loans: ${client.loans}")

    def list_employees(self):
        for employee in self.employees.values():
            print(f"ID: {employee.employee_id}, Name: {employee.name}, Position: {employee.position}")

def execute():
    bank = FinancialInstitution()

    client1 = Client(1, "Michael", 5000)
    client2 = Client(2, "Sarah", 6000)

    bank.add_client(client1)
    bank.add_client(client2)

    employee1 = Employee(201, "David", "Manager")
    employee2 = Employee(202, "Emma", "Clerk")

    bank.add_employee(employee1)
    bank.add_employee(employee2)

    client1.apply_loan(1000)

    print("Client List:")
    bank.list_clients()

    print("\nStaff List:")
    bank.list_employees()

if __name__ == "__main__":
    execute()