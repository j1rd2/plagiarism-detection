def check_prime(value):
    if value <= 1:
        return False
    for divisor in range(2, value):
        if value % divisor == 0:
            return False
    return True

def find_primes(max_value):
    prime_list = []
    for number in range(2, max_value + 1):
        if check_prime(number):
            prime_list.append(number)
    return prime_list

def execute():
    max_value = 50
    prime_numbers = find_primes(max_value)
    print(f"Prime numbers up to {max_value}: {prime_numbers}")

if __name__ == "__main__":
    execute()