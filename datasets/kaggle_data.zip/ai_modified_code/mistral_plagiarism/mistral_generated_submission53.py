import csv

class Learner:
    def __init__(self, name, score):
        self.name = name
        self.score = score
        self.grade = None

    def determine_grade(self, average_score):
        self.grade = 'A' if self.score >= average_score else 'B'

class StudentManager:
    def __init__(self, input_filename):
        self.input_filename = input_filename
        self.students = []

    def load_students(self):
        with open(self.input_filename, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                student = Learner(row['Name'], float(row['Score']))
                self.students.append(student)

    def compute_average(self):
        total_score = sum(student.score for student in self.students)
        return total_score / len(self.students)

    def evaluate_students(self, average_score):
        for student in self.students:
            student.determine_grade(average_score)

    def save_results(self, output_filename):
        with open(output_filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Name', 'Score', 'Grade'])
            for student in self.students:
                writer.writerow([student.name, student.score, student.grade])

def execute():
    input_filename = 'students.csv'
    output_filename = 'graded_students.csv'
    manager = StudentManager(input_filename)
    manager.load_students()
    avg_score = manager.compute_average()
    manager.evaluate_students(avg_score)
    manager.save_results(output_filename)
    print(f"Grading completed. Results written to {output_filename}")

if __name__ == "__main__":
    execute()