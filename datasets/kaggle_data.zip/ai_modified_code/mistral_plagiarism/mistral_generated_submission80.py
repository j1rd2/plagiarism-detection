clients = {}
staff = {}

def add_client(client_id, name, balance):
    clients[client_id] = {"Name": name, "Balance": balance}

def add_staff(staff_id, name, position):
    staff[staff_id] = {"Name": name, "Position": position}

def deposit(client_id, amount):
    if client_id in clients:
        clients[client_id]["Balance"] += amount
    else:
        print("Client not found.")

def withdraw(client_id, amount):
    if client_id in clients:
        if clients[client_id]["Balance"] >= amount:
            clients[client_id]["Balance"] -= amount
        else:
            print("Insufficient funds.")
    else:
        print("Client not found.")

def list_clients():
    for client_id, info in clients.items():
        print(f"ID: {client_id}, Name: {info['Name']}, Balance: ${info['Balance']}")

def list_staff():
    for staff_id, info in staff.items():
        print(f"ID: {staff_id}, Name: {info['Name']}, Position: {info['Position']}")

def execute():
    add_client(1, "Emma", 3000)
    add_client(2, "John", 4000)

    add_staff(101, "Lisa", "Manager")
    add_staff(102, "Tom", "Teller")

    deposit(1, 500)
    withdraw(2, 1000)

    print("Client List:")
    list_clients()

    print("\nStaff List:")
    list_staff()

if __name__ == "__main__":
    execute()