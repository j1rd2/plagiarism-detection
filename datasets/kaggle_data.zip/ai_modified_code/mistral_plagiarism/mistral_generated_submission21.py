import logging

def check_non_negative(value):
    """Validates the input as a non-negative integer."""
    if not isinstance(value, int) or value < 0:
        raise ValueError("Input must be a non-negative integer.")

def compute_factorial_recursively(value):
    """Compute the factorial using a recursive function."""
    if value == 0:
        return 1
    return value * compute_factorial_recursively(value - 1)

def compute_factorial_iteratively(value):
    """Compute the factorial using iteration."""
    check_non_negative(value)
    result = 1
    for counter in range(2, value + 1):
        result *= counter
    return result

def calculate_digit_sum(number):
    """Sum the digits of the factorial."""
    return sum(int(digit) for digit in str(number))

def record_results(number, factorial_outcome, digit_sum_outcome):
    """Log the results to a file."""
    logging.basicConfig(filename='factorial_calculations.log', level=logging.INFO)
    logging.info(f"Number: {number}, Factorial: {factorial_outcome}, Sum of digits: {digit_sum_outcome}")

def execute_menu():
    while True:
        try:
            input_value = int(input("Please enter a non-negative integer: "))
            check_non_negative(input_value)
            factorial_outcome = compute_factorial_iteratively(input_value)
            digit_sum_outcome = calculate_digit_sum(factorial_outcome)
            record_results(input_value, factorial_outcome, digit_sum_outcome)
            print(f"Factorial: {factorial_outcome}, Sum of digits: {digit_sum_outcome}")
        except ValueError as error_message:
            print(f"Error: {error_message}")

        continue_prompt = input("Do you want to calculate another factorial? (yes/no): ")
        if continue_prompt.lower() != 'yes':
            break

if __name__ == "__main__":
    execute_menu()