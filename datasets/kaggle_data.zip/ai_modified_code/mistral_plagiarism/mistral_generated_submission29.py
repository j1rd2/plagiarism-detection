import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Function to simulate population data
def create_population_data(years_count):
    years_sequence = np.arange(2000, 2000 + years_count)
    population_numbers = 300000000 + np.cumsum(np.random.normal(1000000, 500000, years_count))
    return pd.DataFrame({'Year': years_sequence, 'Population': population_numbers})

# Function to compute the moving average
def calculate_moving_average(dataframe, window_size):
    return dataframe['Population'].rolling(window=window_size).mean()

# Function to visualize population trends
def plot_population_trends(dataset):
    plt.figure(figsize=(12, 6))
    plt.plot(dataset['Year'], dataset['Population'], label='Population')
    plt.plot(dataset['Year'], calculate_moving_average(dataset, 5), label='5-Year Moving Avg', linestyle='--')
    plt.title('Population Trends with Moving Average')
    plt.xlabel('Year')
    plt.ylabel('Population')
    plt.legend()
    plt.show()

# Main execution flow
if __name__ == "__main__":
    population_dataset = create_population_data(20)
    plot_population_trends(population_dataset)