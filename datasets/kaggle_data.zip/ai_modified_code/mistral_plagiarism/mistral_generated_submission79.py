clients = {}
transactions = []

def add_client(client_id, name, balance):
    clients[client_id] = {"Name": name, "Balance": balance}

def deposit(client_id, amount):
    if client_id in clients:
        clients[client_id]["Balance"] += amount
        transactions.append({"ClientID": client_id, "Type": "Deposit", "Amount": amount})
    else:
        print("Client not found.")

def withdraw(client_id, amount):
    if client_id in clients:
        if clients[client_id]["Balance"] >= amount:
            clients[client_id]["Balance"] -= amount
            transactions.append({"ClientID": client_id, "Type": "Withdraw", "Amount": amount})
        else:
            print("Insufficient funds.")
    else:
        print("Client not found.")

def list_clients():
    for client_id, info in clients.items():
        print(f"ID: {client_id}, Name: {info['Name']}, Balance: ${info['Balance']}")

def list_transactions():
    for transaction in transactions:
        print(f"Client ID: {transaction['ClientID']}, Type: {transaction['Type']}, Amount: ${transaction['Amount']}")

def execute():
    add_client(1, "Charlie", 2000)
    add_client(2, "Daisy", 2500)

    deposit(1, 300)
    withdraw(2, 500)

    print("Client List:")
    list_clients()

    print("\nTransaction List:")
    list_transactions()

if __name__ == "__main__":
    execute()