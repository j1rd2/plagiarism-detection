def read_numbers_from_file(filename):
    with open(filename, 'r') as file:
        number_list = [int(line.strip()) for line in file]
    return number_list

def compute_squares(number_list):
    squared_list = [value ** 2 for value in number_list]
    return squared_list

def write_numbers_to_file(squared_list, output_filename):
    with open(output_filename, 'w') as file:
        for number in squared_list:
            file.write(f"{number}\n")

def execute():
    input_filename = 'input.txt'
    output_filename = 'output.txt'
    numbers = read_numbers_from_file(input_filename)
    squared = compute_squares(numbers)
    write_numbers_to_file(squared, output_filename)
    print(f"Results written to {output_filename}")

if __name__ == "__main__":
    execute()