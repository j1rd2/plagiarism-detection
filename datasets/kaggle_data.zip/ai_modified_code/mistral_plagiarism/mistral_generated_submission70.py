def register_patient(patients, patient_id, name, age, ailment):
    patients.append({"ID": patient_id, "Name": name, "Age": age, "Ailment": ailment})

def create_appointment(appointments, appointment_id, patient, doctor, date):
    appointments.append({"AppointmentID": appointment_id, "Patient": patient, "Doctor": doctor, "Date": date})

def display_patients(patients):
    for patient in patients:
        print(f"ID: {patient['ID']}, Name: {patient['Name']}, Age: {patient['Age']}, Ailment: {patient['Ailment']}")

def display_appointments(appointments):
    for appointment in appointments:
        print(f"Appointment ID: {appointment['AppointmentID']}, Patient: {appointment['Patient']['Name']}, Doctor: {appointment['Doctor']}, Date: {appointment['Date']}")

def execute():
    patients = []
    appointments = []

    register_patient(patients, 1, "George Clooney", 50, "Vision Problems")
    register_patient(patients, 2, "Brad Pitt", 45, "Migraine")

    create_appointment(appointments, 1, patients[0], "Dr. Johnson", "2024-09-30")
    create_appointment(appointments, 2, patients[1], "Dr. Williams", "2024-10-01")

    print("Patients:")
    display_patients(patients)

    print("\nAppointments:")
    display_appointments(appointments)

if __name__ == "__main__":
    execute()