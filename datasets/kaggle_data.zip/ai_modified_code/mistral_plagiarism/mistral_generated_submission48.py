def load_numbers_generator(filename):
    with open(filename, 'r') as file:
        for line in file:
            yield int(line.strip())

def compute_squares_generator(numbers):
    for number in numbers:
        yield number ** 2

def save_numbers_generator(squared_numbers, output_filename):
    with open(output_filename, 'w') as file:
        for number in squared_numbers:
            file.write(f"{number}\n")

def execute():
    input_filename = 'input.txt'
    output_filename = 'output.txt'
    numbers_generator = load_numbers_generator(input_filename)
    squared_generator = compute_squares_generator(numbers_generator)
    save_numbers_generator(squared_generator, output_filename)
    print(f"Squared numbers saved to {output_filename}")

if __name__ == "__main__":
    execute()