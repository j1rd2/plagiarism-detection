def check_if_prime(value):
    if value <= 1:
        return False
    for divisor in range(2, value):
        if value % divisor == 0:
            return False
    return True

def find_primes_up_to(limit):
    primes = []
    for number in range(2, limit + 1):
        if check_if_prime(number):
            primes.append(number)
    return primes

def execute():
    limit = 50
    prime_numbers = find_primes_up_to(limit)
    print(f"Prime numbers up to {limit}: {prime_numbers}")

if __name__ == "__main__":
    execute()