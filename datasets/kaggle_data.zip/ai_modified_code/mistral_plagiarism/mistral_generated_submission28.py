import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Generate synthetic data
def generate_population_data(number_of_years):
    years_range = np.arange(2000, 2000 + number_of_years)
    population_values = 300000000 + np.cumsum(np.random.normal(1000000, 500000, number_of_years))
    return pd.DataFrame({'Year': years_range, 'Population': population_values})

# Calculate moving average
def compute_moving_average(dataset, window):
    return dataset['Population'].rolling(window=window).mean()

# Plotting function
def visualize_population_and_average(dataframe):
    plt.figure(figsize=(12, 6))
    plt.plot(dataframe['Year'], dataframe['Population'], label='Population')
    plt.plot(dataframe['Year'], compute_moving_average(dataframe, 5), label='5-Year Moving Avg', linestyle='--')
    plt.title('Population Growth with Moving Average')
    plt.xlabel('Year')
    plt.ylabel('Population')
    plt.legend()
    plt.show()

# Main execution
if __name__ == "__main__":
    population_dataset = generate_population_data(20)
    visualize_population_and_average(population_dataset)