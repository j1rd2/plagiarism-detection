def order_by_age(individuals):
    sorted_individuals = sorted(individuals, key=lambda individual: individual['age'])
    return sorted_individuals

def display_individuals(individuals):
    print("People list sorted by their age values:")
    for individual in individuals:
        print(f"Name: {individual['name']}, Age: {individual['age']}")

def execute():
    people = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    sorted_people = order_by_age(people)
    display_individuals(sorted_people)

if __name__ == "__main__":
    execute()