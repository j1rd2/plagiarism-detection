def sort_list(data):
    length = len(data)
    for outer in range(length):
        for inner in range(0, length - outer - 1):
            if data[inner] > data[inner + 1]:
                data[inner], data[inner + 1] = data[inner + 1], data[inner]

def execute():
    data = [64, 34, 25, 12, 22, 11, 90]
    print("Original array:", data)
    sort_list(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    execute()