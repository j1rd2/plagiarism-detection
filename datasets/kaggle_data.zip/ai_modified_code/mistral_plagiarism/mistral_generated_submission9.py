def compute_fibonacci_sequence(max_iterations):
    previous, current = 0, 1
    for _ in range(max_iterations):
        previous, current = current, previous + current
    return previous

fibonacci_value = compute_fibonacci_sequence(10)
print("Result:", fibonacci_value)