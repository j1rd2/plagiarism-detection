import json

class Worker:
    def __init__(self, name, department, salary):
        self.name = name
        self.department = department
        self.salary = salary

class DepartmentReport:
    def __init__(self, department):
        self.department = department
        self.employees = []

    def add_employee(self, employee):
        if employee.department == self.department:
            self.employees.append(employee)

    def compute_average_salary(self):
        if not self.employees:
            return 0
        total_salary = sum(emp.salary for emp in self.employees)
        return total_salary / len(self.employees)

    def to_dict(self):
        return {
            'department': self.department,
            'average_salary': self.compute_average_salary(),
            'employee_count': len(self.employees)
        }

def load_employees(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    return [Worker(emp['name'], emp['department'], emp['salary']) for emp in data['employees']]

def save_report(report, output_filename):
    with open(output_filename, 'w') as file:
        json.dump(report, file, indent=4)

def execute():
    input_filename = 'employees.json'
    output_filename = 'department_summary.json'
    department = 'Engineering'

    employees = load_employees(input_filename)
    report = DepartmentReport(department)
    
    for emp in employees:
        report.add_employee(emp)
    
    report_data = report.to_dict()
    save_report(report_data, output_filename)
    print(f"Department summary saved to {output_filename}")

if __name__ == "__main__":
    execute()