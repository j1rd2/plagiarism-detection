def order_by_age(individuals):
    sorted_individuals = sorted(individuals, key=lambda individual: individual['age'])
    return sorted_individuals

def display_people(individuals):
    print("People sorted by age:")
    for individual in individuals:
        print(f"Name: {individual['name']}, Age: {individual['age']}")

def execute():
    individuals = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    sorted_individuals = order_by_age(individuals)
    display_people(sorted_individuals)

if __name__ == "__main__":
    execute()