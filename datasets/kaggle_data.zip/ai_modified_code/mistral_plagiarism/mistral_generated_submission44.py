def sort_by_age(individuals):
    sorted_individuals = sorted(individuals, key=lambda person: person['age'])
    return sorted_individuals

def print_individuals(individuals):
    print("Outputting the sorted list of individuals by age:")
    for person in individuals:
        print(f"Person: {person['name']}, Age: {person['age']}")

def execute():
    group = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    sorted_group = sort_by_age(group)
    print_individuals(sorted_group)

if __name__ == "__main__":
    execute()