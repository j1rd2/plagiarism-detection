class Person:
    def __init__(self, person_id, name, age, condition):
        self.person_id = person_id
        self.name = name
        self.age = age
        self.condition = condition

class Meeting:
    def __init__(self, meeting_id, person, doctor, date):
        self.meeting_id = meeting_id
        self.person = person
        self.doctor = doctor
        self.date = date

class ClinicManagementSystem:
    def __init__(self):
        self.persons = []
        self.meetings = []

    def add_person(self, person):
        self.persons.append(person)

    def schedule_meeting(self, meeting):
        self.meetings.append(meeting)

    def list_persons(self):
        for person in self.persons:
            print(f"ID: {person.person_id}, Name: {person.name}, Age: {person.age}, Condition: {person.condition}")

    def list_meetings(self):
        for meeting in self.meetings:
            print(f"Meeting ID: {meeting.meeting_id}, Person: {meeting.person.name}, Doctor: {meeting.doctor}, Date: {meeting.date}")

def execute():
    clinic_system = ClinicManagementSystem()

    person1 = Person(1, "John Doe", 45, "Flu")
    person2 = Person(2, "Jane Smith", 30, "Cough")

    clinic_system.add_person(person1)
    clinic_system.add_person(person2)

    meeting1 = Meeting(1, person1, "Dr. Alice", "2024-09-15")
    meeting2 = Meeting(2, person2, "Dr. Bob", "2024-09-16")

    clinic_system.schedule_meeting(meeting1)
    clinic_system.schedule_meeting(meeting2)

    print("Person List:")
    clinic_system.list_persons()

    print("\nMeeting List:")
    clinic_system.list_meetings()

if __name__ == "__main__":
    execute()