import xml.etree.ElementTree as ET

def load_books_from_xml(filename):
    tree = ET.parse(filename)
    root = tree.getroot()
    return [
        {
            'title': book.find('title').text,
            'author': book.find('author').text,
            'year': int(book.find('year').text),
            'price': float(book.find('price').text)
        }
        for book in root.findall('book')
    ]

def filter_books_after_year(books, year):
    return list(filter(lambda b: b['year'] > year, books))

def compute_average_price(books):
    total = sum(map(lambda b: b['price'], books))
    return total / len(books) if books else 0

def write_xml_output(books, avg_price, output_filename):
    root = ET.Element('booksReport')
    avg_elem = ET.SubElement(root, 'averagePrice')
    avg_elem.text = str(avg_price)
    for book in books:
        book_elem = ET.SubElement(root, 'book')
        ET.SubElement(book_elem, 'title').text = book['title']
        ET.SubElement(book_elem, 'author').text = book['author']
        ET.SubElement(book_elem, 'year').text = str(book['year'])
        ET.SubElement(book_elem, 'price').text = str(book['price'])

    tree = ET.ElementTree(root)
    tree.write(output_filename)

def execute():
    input_filename = 'books.xml'
    output_filename = 'filtered_books.xml'
    year_cutoff = 2000

    books = load_books_from_xml(input_filename)
    recent_books = filter_books_after_year(books, year_cutoff)
    avg_price = compute_average_price(recent_books)
    write_xml_output(recent_books, avg_price, output_filename)
    print(f"Books data written to {output_filename}")

if __name__ == "__main__":
    execute()