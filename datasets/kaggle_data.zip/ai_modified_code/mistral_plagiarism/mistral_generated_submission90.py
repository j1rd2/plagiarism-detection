def traverse_graph(graph, start, visited=None):
    if visited is None:
        visited = set()
    visited.add(start)
    print(start, end=" ")

    for next_vertex in graph[start] - visited:
        traverse_graph(graph, next_vertex, visited)

def execute():
    graph = {
        'A': {'B', 'C'},
        'B': {'A', 'D', 'E'},
        'C': {'A', 'F'},
        'D': {'B'},
        'E': {'B', 'F'},
        'F': {'C', 'E'}
    }
    print("DFS starting from vertex A:")
    traverse_graph(graph, 'A')

if __name__ == "__main__":
    execute()