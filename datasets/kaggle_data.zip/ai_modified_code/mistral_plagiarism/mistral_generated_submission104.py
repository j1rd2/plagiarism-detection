import random

def introduce_mutations_with_logging(dna_sequence, mutation_prob=0.02):
    bases = ['A', 'T', 'C', 'G']
    sequence = list(dna_sequence)
    mutations = 0
    
    for i in range(len(sequence)):
        if random.random() < mutation_prob:
            sequence[i] = random.choice(bases)
            mutations += 1
    
    mutated_sequence = ''.join(sequence)
    print(f"Total mutations: {mutations}")
    return mutated_sequence

def execute():
    dna_sequence = "ATGCTAGCTAGT"
    mutated_sequence = introduce_mutations_with_logging(dna_sequence, mutation_prob=0.05)
    print("Original DNA sequence:", dna_sequence)
    print("Mutated DNA sequence:", mutated_sequence)

if __name__ == "__main__":
    execute()