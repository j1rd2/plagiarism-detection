import csv

def fetch_student_data(filename):
    student_records = []
    with open(filename, mode='r') as file:
        csv_reader = csv.DictReader(file)
        for record in csv_reader:
            student_records.append({'name': record['Name'], 'score': float(record['Score'])})
    return student_records

def calculate_average_score(students):
    total_scores = sum(student['score'] for student in students)
    average_score = total_scores / len(students)
    return average_score

def assign_grades(students, average):
    for student in students:
        student['grade'] = 'A' if student['score'] >= average else 'B'
    return students

def export_to_csv(students, output_filename):
    with open(output_filename, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=['Name', 'Score', 'Grade'])
        writer.writeheader()
        writer.writerows(students)

def execute():
    input_csv = 'students.csv'
    output_csv = 'graded_students.csv'
    student_records = fetch_student_data(input_csv)
    average = calculate_average_score(student_records)
    graded_students = assign_grades(student_records, average)
    export_to_csv(graded_students, output_csv)
    print(f"Graded students data saved to {output_csv}")

if __name__ == "__main__":
    execute()