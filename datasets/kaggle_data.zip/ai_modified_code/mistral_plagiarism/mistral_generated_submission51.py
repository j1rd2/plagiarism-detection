import pandas as pd

def load_student_data(filename):
    dataframe = pd.read_csv(filename)
    return dataframe

def compute_average(dataframe):
    average_score = dataframe['Score'].mean()
    return average_score

def determine_grade(dataframe, average_score):
    dataframe['Grade'] = dataframe['Score'].apply(lambda value: 'A' if value >= average_score else 'B')
    return dataframe

def save_results(dataframe, output_filename):
    dataframe.to_csv(output_filename, index=False)

def execute():
    input_filename = 'students.csv'
    output_filename = 'graded_students.csv'
    student_dataframe = load_student_data(input_filename)
    avg_score = compute_average(student_dataframe)
    graded_dataframe = determine_grade(student_dataframe, avg_score)
    save_results(graded_dataframe, output_filename)
    print(f"Grades assigned and saved to {output_filename}")

if __name__ == "__main__":
    execute()