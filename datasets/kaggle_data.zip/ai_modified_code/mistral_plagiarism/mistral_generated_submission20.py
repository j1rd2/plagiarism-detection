import logging

def check_non_negative_integer(value):
    """Validates that the input is a non-negative integer."""
    if not isinstance(value, int) or value < 0:
        raise ValueError("The provided input must be a non-negative integer.")

def calculate_factorial_recursively(value):
    """Compute the factorial of a number using recursion."""
    if value == 0:
        return 1
    return value * calculate_factorial_recursively(value - 1)

def calculate_factorial_iteratively(value):
    """Compute the factorial of a number using an iterative method."""
    check_non_negative_integer(value)
    product = 1
    for counter in range(2, value + 1):
        product *= counter
    return product

def calculate_digit_sum(number):
    """Compute the sum of the digits of a number."""
    return sum(int(digit) for digit in str(number))

def record_calculation_results(input_value, factorial_outcome, digit_sum_outcome):
    """Log the results of the calculations to a file."""
    logging.basicConfig(filename='factorial_results.log', level=logging.INFO)
    logging.info(f"Input: {input_value}, Factorial: {factorial_outcome}, Sum of digits: {digit_sum_outcome}")

def factorial_interface():
    while True:
        try:
            user_value = int(input("Enter a non-negative integer: "))
            check_non_negative_integer(user_value)
            factorial_outcome = calculate_factorial_iteratively(user_value)
            digit_sum_outcome = calculate_digit_sum(factorial_outcome)
            record_calculation_results(user_value, factorial_outcome, digit_sum_outcome)
            print(f"Factorial: {factorial_outcome}, Sum of digits: {digit_sum_outcome}")
        except ValueError as exception:
            print(f"Error: {exception}")

        continue_choice = input("Calculate another factorial? (yes/no): ")
        if continue_choice.lower() != 'yes':
            break

if __name__ == "__main__":
    factorial_interface()