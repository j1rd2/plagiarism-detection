from operator import itemgetter

def order_people(individuals):
    sorted_individuals = sorted(individuals, key=itemgetter('age'))
    return sorted_individuals

def show_people(individuals):
    print("Sorted list of people by their ages:")
    for individual in individuals:
        print(f"Name: {individual['name']}, Age: {individual['age']}")

def execute():
    individuals = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    sorted_individuals = order_people(individuals)
    show_people(sorted_individuals)

if __name__ == "__main__":
    execute()