from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import joblib

# Load the iris dataset
data = load_iris()
features = data.data
target = data.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.3, random_state=42)

# Train a Logistic Regression model
classifier = LogisticRegression(max_iter=200, random_state=42)
classifier.fit(X_train, y_train)

# Dump the trained model using joblib
joblib.dump(classifier, 'logistic_regression_model.pkl')