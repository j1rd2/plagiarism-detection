def sort_list(data):
    length = len(data)
    for outer in range(length):
        min_index = outer
        for inner in range(outer + 1, length):
            if data[inner] < data[min_index]:
                min_index = inner
        data[outer], data[min_index] = data[min_index], data[outer]

def execute():
    data = [29, 10, 14, 37, 13]
    print("Original array:", data)
    sort_list(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    execute()