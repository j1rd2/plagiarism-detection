class PatientRecord:
    def __init__(self, id, full_name, years, condition):
        self.id = id
        self.full_name = full_name
        self.years = years
        self.condition = condition

class AppointmentRecord:
    def __init__(self, id, patient, doctor, date):
        self.id = id
        self.patient = patient
        self.doctor = doctor
        self.date = date

class BillingRecord:
    def __init__(self, bill_id, patient, amount):
        self.bill_id = bill_id
        self.patient = patient
        self.amount = amount

class MedicalSystem:
    def __init__(self):
        self.patient_records = []
        self.appointments = []
        self.bills = []

    def register_patient(self, patient):
        self.patient_records.append(patient)

    def create_appointment(self, appointment):
        self.appointments.append(appointment)

    def generate_bill(self, bill):
        self.bills.append(bill)

    def display_patients(self):
        for patient in self.patient_records:
            print(f"ID: {patient.id}, Name: {patient.full_name}, Age: {patient.years}, Condition: {patient.condition}")

    def display_appointments(self):
        for appointment in self.appointments:
            print(f"Appointment ID: {appointment.id}, Patient: {appointment.patient.full_name}, Doctor: {appointment.doctor}, Date: {appointment.date}")

    def display_bills(self):
        for bill in self.bills:
            print(f"Bill ID: {bill.bill_id}, Patient: {bill.patient.full_name}, Amount: ${bill.amount}")

def execute():
    system = MedicalSystem()

    patient_a = PatientRecord(101, "Alice Green", 29, "Headache")
    patient_b = PatientRecord(102, "Bob Brown", 54, "Fever")

    system.register_patient(patient_a)
    system.register_patient(patient_b)

    appointment_a = AppointmentRecord(1001, patient_a, "Dr. Martin", "2024-09-17")
    appointment_b = AppointmentRecord(1002, patient_b, "Dr. Lisa", "2024-09-18")

    system.create_appointment(appointment_a)
    system.create_appointment(appointment_b)

    bill_a = BillingRecord(1, patient_a, 150.0)
    bill_b = BillingRecord(2, patient_b, 200.0)

    system.generate_bill(bill_a)
    system.generate_bill(bill_b)

    print("Patient Records:")
    system.display_patients()

    print("\nAppointment Records:")
    system.display_appointments()

    print("\nBilling Records:")
    system.display_bills()

if __name__ == "__main__":
    execute()