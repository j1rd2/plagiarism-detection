def create_fibonacci_sequence(max_value):
    sequence = [0, 1]
    while True:
        next_number = sequence[-1] + sequence[-2]
        if next_number >= max_value:
            break
        sequence.append(next_number)
    return sequence

def display_fibonacci_sequence(sequence):
    print("Fibonacci sequence up to the limit:")
    for position, number in enumerate(sequence):
        print(f"Index {position}: {number}")

def execute():
    max_value = 100
    fibonacci_sequence = create_fibonacci_sequence(max_value)
    display_fibonacci_sequence(fibonacci_sequence)

if __name__ == "__main__":
    execute()