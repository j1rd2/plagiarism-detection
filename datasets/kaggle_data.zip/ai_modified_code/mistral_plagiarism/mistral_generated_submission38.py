def find_primes_sieve(max_value):
    is_prime = [True] * (max_value + 1)
    is_prime[0], is_prime[1] = False, False
    for current in range(2, int(max_value ** 0.5) + 1):
        if is_prime[current]:
            for multiple in range(current * current, max_value + 1, current):
                is_prime[multiple] = False
    return [number for number, prime in enumerate(is_prime) if prime]

def execute():
    max_value = 50
    prime_numbers = find_primes_sieve(max_value)
    print(f"Prime numbers up to {max_value} using the Sieve of Eratosthenes: {prime_numbers}")

if __name__ == "__main__":
    execute()