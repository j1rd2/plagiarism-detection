class Client:
    def __init__(self, client_id, name, balance):
        self.client_id = client_id
        self.name = name
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
        else:
            print("Insufficient funds.")

class FinancialInstitution:
    def __init__(self):
        self.clients = {}

    def add_client(self, client):
        self.clients[client.client_id] = client

    def find_client(self, client_id):
        return self.clients.get(client_id, None)

    def list_clients(self):
        for client in self.clients.values():
            print(f"ID: {client.client_id}, Name: {client.name}, Balance: ${client.balance}")

def execute():
    bank = FinancialInstitution()

    client1 = Client(1, "Alice", 1000)
    client2 = Client(2, "Bob", 1500)

    bank.add_client(client1)
    bank.add_client(client2)

    client1.deposit(500)
    client2.withdraw(200)

    print("Client List:")
    bank.list_clients()

if __name__ == "__main__":
    execute()