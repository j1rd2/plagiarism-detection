import json

def load_employee_data(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    return data['employees']

def filter_employees_by_department(employees, department):
    return [employee for employee in employees if employee['department'] == department]

def compute_average_salary(employees):
    total_salary = sum(employee['salary'] for employee in employees)
    return total_salary / len(employees) if employees else 0

def save_results_to_json(results, output_filename):
    with open(output_filename, 'w') as file:
        json.dump(results, file, indent=4)

def execute():
    input_filename = 'employees.json'
    output_filename = 'department_summary.json'
    department = 'Engineering'

    employees = load_employee_data(input_filename)
    filtered_employees = filter_employees_by_department(employees, department)
    average_salary = compute_average_salary(filtered_employees)
    results = {
        'department': department,
        'average_salary': average_salary,
        'employee_count': len(filtered_employees)
    }

    save_results_to_json(results, output_filename)
    print(f"Results saved to {output_filename}")

if __name__ == "__main__":
    execute()