def compute_total(first_num, second_num):
    return first_num + second_num