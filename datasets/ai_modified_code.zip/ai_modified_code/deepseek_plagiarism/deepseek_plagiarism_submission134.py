import openpyxl

def process_data(file_path):
    workbook = openpyxl.load_workbook(file_path)
    active_sheet = workbook.active
    
    for row_data in active_sheet.iter_rows(values_only=True):
        print(row_data)

def execute():
    print("Reading data from 'students_with_city.xlsx':")
    process_data("students_with_city.xlsx")

if __name__ == "__main__":
    execute()