def process_data(records, entry_id, full_name, years, condition):
    records.append({"Identifier": entry_id, "FullName": full_name, "Years": years, "Condition": condition})

def arrange_meeting(meetings, meeting_id, record, specialist, day):
    meetings.append({"MeetingID": meeting_id, "Record": record, "Specialist": specialist, "Day": day})

def display_records(records):
    for record in records:
        print(f"Identifier: {record['Identifier']}, FullName: {record['FullName']}, Years: {record['Years']}, Condition: {record['Condition']}")

def display_meetings(meetings):
    for meeting in meetings:
        print(f"Meeting ID: {meeting['MeetingID']}, Record: {meeting['Record']['FullName']}, Specialist: {meeting['Specialist']}, Day: {meeting['Day']}")

def execute():
    records = []
    meetings = []

    process_data(records, 1, "George Clooney", 50, "Vision Problems")
    process_data(records, 2, "Brad Pitt", 45, "Migraine")

    arrange_meeting(meetings, 1, records[0], "Dr. Johnson", "2024-09-30")
    arrange_meeting(meetings, 2, records[1], "Dr. Williams", "2024-10-01")

    print("Records:")
    display_records(records)

    print("\nMeetings:")
    display_meetings(meetings)

if __name__ == "__main__":
    execute()