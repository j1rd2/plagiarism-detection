def check_value(x):
    if type(x) == int and x >= 0:
        return True
    return False

def compute_factorial(n):
    if not check_value(n):
        raise ValueError("Input must be a non-negative integer")
    if n == 0:
        return 1
    return n * compute_factorial(n - 1)

try:
    value = int(input("Please enter an integer: "))
    result = compute_factorial(value)
    print(f"The factorial of {value} is {result}")
except ValueError as e:
    print(e)