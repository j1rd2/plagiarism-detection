inventory = {}
employees = {}

def modify_inventory(item_code, title, cost, stock):
    inventory[item_code] = {"Title": title, "Cost": cost, "Stock": stock}

def modify_employees(employee_code, title, position):
    employees[employee_code] = {"Title": title, "Position": position}

def adjust_stock(item_code, stock):
    if item_code in inventory:
        inventory[item_code]["Stock"] += stock
    else:
        print(f"Item Code {item_code} not found in inventory.")

def display_inventory():
    for item_code, details in inventory.items():
        print(f"Code: {item_code}, Title: {details['Title']}, Cost: ${details['Cost']}, Stock: {details['Stock']}")

def display_employees():
    for employee_code, details in employees.items():
        print(f"Code: {employee_code}, Title: {details['Title']}, Position: {details['Position']}")

def execute():
    modify_inventory(1, "Juice", 2.99, 80)
    modify_inventory(2, "Cookies", 1.99, 120)

    modify_employees(301, "Emma", "Cashier")
    modify_employees(302, "John", "Manager")

    adjust_stock(1, 20)
    adjust_stock(2, -15)

    print("Product List:")
    display_inventory()

    print("\nStaff List:")
    display_employees()

if __name__ == "__main__":
    execute()