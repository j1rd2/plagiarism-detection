class Item:
    def __init__(self, title, author, price):
        self.title = title
        self.author = author
        self.price = price

    def display(self):
        print(f"Title: {self.title}, Author: {self.author}, Price: ${self.price}")

    def adjust_price(self, new_price):
        self.price = new_price


def add_item(collection, title, author, price):
    new_item = Item(title, author, price)
    collection.append(new_item)


def update_item_price(collection, title, new_price):
    for item in collection:
        if item.title == title:
            item.adjust_price(new_price)


def list_collection(collection):
    for item in collection:
        item.display()


def manage_store():
    collection = []
    add_item(collection, "Pride and Prejudice", "Jane Austen", 10.49)
    add_item(collection, "1984", "George Orwell", 8.99)

    print("Items available before price update:")
    list_collection(collection)

    update_item_price(collection, "1984", 6.99)

    print("\nItems available after price update:")
    list_collection(collection)


if __name__ == "__main__":
    manage_store()