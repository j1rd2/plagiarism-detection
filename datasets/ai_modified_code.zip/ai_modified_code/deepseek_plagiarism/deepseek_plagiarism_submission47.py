def read_data(path):
    with open(path, 'r') as f:
        values = [int(line.strip()) for line in f]
    return values

def compute_squares(data):
    result = [x ** 2 for x in data]
    return result

def write_results(data, destination):
    with open(destination, 'w') as f:
        for item in data:
            f.write(f"{item}\n")

def execute():
    source = 'input.txt'
    target = 'output.txt'
    original = read_data(source)
    transformed = compute_squares(original)
    write_results(transformed, target)
    print(f"Results written to {target}")

if __name__ == "__main__":
    execute()