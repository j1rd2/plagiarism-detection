from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import joblib

iris_data = load_iris()
X_values = iris_data.data
y_values = iris_data.target

X_train, X_test, y_train, y_test = train_test_split(X_values, y_values, test_size=0.25, random_state=21)

model = LogisticRegression(max_iter=250, random_state=21)
model.fit(X_train, y_train)

joblib.dump(model, 'lr_model.pkl')