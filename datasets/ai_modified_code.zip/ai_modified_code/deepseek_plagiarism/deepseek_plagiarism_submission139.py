import threading
import time

def display_sequence(identifier, interval):
    for count in range(5):
        print(f"{identifier}: {count}")
        time.sleep(interval)

def execute_threads():
    first_thread = threading.Thread(target=display_sequence, args=("Thread 1", 1))
    second_thread = threading.Thread(target=display_sequence, args=("Thread 2", 0.5))
    
    first_thread.start()
    second_thread.start()
    
    first_thread.join()
    second_thread.join()

if __name__ == "__main__":
    execute_threads()