class PatientRecord:
    def __init__(self, name, age, condition):
        self.name = name
        self.age = age
        self.condition = condition

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}, Diagnosis: {self.condition}")

def add_patient(records, name, age, condition):
    patient = PatientRecord(name, age, condition)
    records.append(patient)

def list_patients(records):
    for patient in records:
        patient.display()

def manage_hospital():
    records = []
    add_patient(records, "Chris Lee", 55, "Pneumonia")
    add_patient(records, "Dana White", 38, "Asthma")
    print("Patients admitted to the hospital:")
    list_patients(records)

if __name__ == "__main__":
    manage_hospital()