import pandas as pd
import matplotlib.pyplot as plt

def fetch_dataset(path):
    dataset = pd.read_csv(path)
    return dataset

def compute_increase(dataset):
    dataset['Increase'] = dataset['Population'].pct_change() * 100
    return dataset

def visualize_dataset(dataset):
    plt.figure(figsize=(10, 6))

    plt.subplot(2, 1, 1)
    plt.plot(dataset['Year'], dataset['Population'], marker='o', linestyle='-')
    plt.title('Population Over Time')
    plt.xlabel('Year')
    plt.ylabel('Population')

    plt.subplot(2, 1, 2)
    plt.plot(dataset['Year'], dataset['Increase'], marker='o', linestyle='-', color='orange')
    plt.title('Population Growth Rate')
    plt.xlabel('Year')
    plt.ylabel('Growth Rate (%)')

    plt.tight_layout()
    plt.show()

def execute():
    path = "population_data.csv"
    dataset = fetch_dataset(path)
    dataset = compute_increase(dataset)
    visualize_dataset(dataset)

if __name__ == "__main__":
    execute()