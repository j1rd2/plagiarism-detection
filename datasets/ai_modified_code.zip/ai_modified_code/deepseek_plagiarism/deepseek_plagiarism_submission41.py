from operator import itemgetter

def arrange_items(items):
    arranged_items = sorted(items, key=itemgetter('age'))
    return arranged_items

def show_items(items):
    print("Sorted list of people by their ages:")
    for item in items:
        print(f"Name: {item['name']}, Age: {item['age']}")

def execute():
    data = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    ordered_data = arrange_items(data)
    show_items(ordered_data)

if __name__ == "__main__":
    execute()