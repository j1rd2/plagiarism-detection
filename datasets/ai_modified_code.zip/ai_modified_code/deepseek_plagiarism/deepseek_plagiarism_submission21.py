import logging

def check_positive_integer(value):
    if not isinstance(value, int) or value < 0:
        raise ValueError("Input must be a non-negative integer.")

def compute_factorial_recursive(n):
    if n == 0:
        return 1
    return n * compute_factorial_recursive(n - 1)

def compute_factorial_iterative(n):
    check_positive_integer(n)
    result = 1
    for idx in range(2, n + 1):
        result *= idx
    return result

def calculate_digit_sum(value):
    return sum(int(ch) for ch in str(value))

def record_output(num, fact, total):
    logging.basicConfig(filename='factorial_calculations.log', level=logging.INFO)
    logging.info(f"Number: {num}, Factorial: {fact}, Sum of digits: {total}")

def user_interface():
    while True:
        try:
            user_input = int(input("Please enter a non-negative integer: "))
            check_positive_integer(user_input)
            fact_result = compute_factorial_iterative(user_input)
            digit_sum_result = calculate_digit_sum(fact_result)
            record_output(user_input, fact_result, digit_sum_result)
            print(f"Factorial: {fact_result}, Sum of digits: {digit_sum_result}")
        except ValueError as err:
            print(f"Error: {err}")

        choice = input("Do you want to calculate another factorial? (yes/no): ")
        if choice.lower() != 'yes':
            break

if __name__ == "__main__":
    user_interface()