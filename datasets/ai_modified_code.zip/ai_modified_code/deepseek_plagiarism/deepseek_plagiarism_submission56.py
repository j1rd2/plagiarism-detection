import json

def read_json_data(file_name):
    with open(file_name, 'r') as f:
        data = json.load(f)
    return data['employees']

def filter_by_section(records, section):
    result = []
    for record in records:
        if record['department'] == section:
            result.append(record)
    return result

def compute_mean_income(records):
    if not records:
        return 0.0
    income_total = sum(item['salary'] for item in records)
    mean_income = income_total / len(records)
    return mean_income

def save_json_data(data, file_name):
    with open(file_name, 'w') as f:
        json.dump(data, f, indent=4)

def execute():
    source_file = 'employees.json'
    target_file = 'department_summary.json'
    target_section = 'Engineering'

    all_records = read_json_data(source_file)
    section_records = filter_by_section(all_records, target_section)
    mean_income = compute_mean_income(section_records)
    summary = {
        'department': target_section,
        'average_salary': mean_income,
        'employee_count': len(section_records)
    }

    save_json_data(summary, target_file)
    print(f"Summary written to {target_file}")

if __name__ == "__main__":
    execute()