def arrange_data(entries):
    ordered_entries = sorted(entries, key=lambda entry: entry['age'])
    return ordered_entries

def display_entries(entries):
    print("People sorted by age:")
    for entry in entries:
        print(f"Name: {entry['name']}, Age: {entry['age']}")

def execute():
    entries = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    ordered_entries = arrange_data(entries)
    display_entries(ordered_entries)

if __name__ == "__main__":
    execute()