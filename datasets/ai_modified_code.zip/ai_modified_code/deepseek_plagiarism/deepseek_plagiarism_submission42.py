def display_individuals(individuals):
    print("People list sorted by their age values:")
    for individual in individuals:
        print(f"Name: {individual['name']}, Age: {individual['age']}")

def arrange_by_age(individuals):
    arranged = sorted(individuals, key=lambda x: x['age'])
    return arranged

def execute():
    data = [
        {'name': 'Alice', 'age': 34},
        {'name': 'Bob', 'age': 23},
        {'name': 'Charlie', 'age': 29},
        {'name': 'Diana', 'age': 40},
        {'name': 'Eve', 'age': 22}
    ]
    ordered_data = arrange_by_age(data)
    display_individuals(ordered_data)

if __name__ == "__main__":
    execute()