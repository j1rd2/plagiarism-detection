client_data = {}
operation_log = []

def register_client(client_num, client_name, funds):
    client_data[client_num] = {"ClientName": client_name, "Funds": funds}

def add_funds(client_num, value):
    if client_num in client_data:
        client_data[client_num]["Funds"] += value
        operation_log.append({"ClientNumber": client_num, "Operation": "Add", "Value": value})
    else:
        print("Client not found.")

def remove_funds(client_num, value):
    if client_num in client_data:
        if client_data[client_num]["Funds"] >= value:
            client_data[client_num]["Funds"] -= value
            operation_log.append({"ClientNumber": client_num, "Operation": "Remove", "Value": value})
        else:
            print("Insufficient funds.")
    else:
        print("Client not found.")

def display_clients():
    for client_num, details in client_data.items():
        print(f"Number: {client_num}, Name: {details['ClientName']}, Funds: ${details['Funds']}")

def display_operations():
    for operation in operation_log:
        print(f"Client Number: {operation['ClientNumber']}, Operation: {operation['Operation']}, Value: ${operation['Value']}")

def execute():
    register_client(1, "Charlie", 2000)
    register_client(2, "Daisy", 2500)

    add_funds(1, 300)
    remove_funds(2, 500)

    print("Client List:")
    display_clients()

    print("\nOperation List:")
    display_operations()

if __name__ == "__main__":
    execute()