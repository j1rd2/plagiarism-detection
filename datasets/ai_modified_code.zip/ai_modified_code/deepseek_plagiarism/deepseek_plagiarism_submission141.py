import threading
import time

shared_value = 0
sync_lock = threading.Lock()

def update_shared_value():
    global shared_value
    for _ in range(5):
        time.sleep(1)
        with sync_lock:
            shared_value += 1
            print(f"Thread {threading.current_thread().name} updated value to {shared_value}")

def execute_threads():
    first_thread = threading.Thread(target=update_shared_value, name="Thread 1")
    second_thread = threading.Thread(target=update_shared_value, name="Thread 2")
    
    first_thread.start()
    second_thread.start()
    
    first_thread.join()
    second_thread.join()

    print(f"Final shared value: {shared_value}")

if __name__ == "__main__":
    execute_threads()