class Institute:
    def __init__(self, institute_title):
        self.institute_title = institute_title
        self.courses = []

    def include_course(self, course):
        self.courses.append(course)

    def display_courses(self):
        print(f"Programs available at {self.institute_title}:")
        for course in self.courses:
            print(f"- {course}")

def operate_institute():
    institute = Institute("MIT Academy")
    institute.include_course("Electrical Engineering")
    institute.include_course("Philosophy")
    institute.include_course("Political Science")
    institute.display_courses()

if __name__ == "__main__":
    operate_institute()