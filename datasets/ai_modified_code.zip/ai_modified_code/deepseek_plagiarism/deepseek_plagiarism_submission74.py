class Item:
    def __init__(self, item_code, title, cost, stock):
        self.item_code = item_code
        self.title = title
        self.cost = cost
        self.stock = stock

    def adjust_stock(self, amount):
        self.stock += amount

    def adjust_cost(self, new_cost):
        self.cost = new_cost

class Shopper:
    def __init__(self, shopper_id, shopper_name):
        self.shopper_id = shopper_id
        self.shopper_name = shopper_name

class Store:
    def __init__(self):
        self.items = {}
        self.shoppers = {}

    def include_item(self, item):
        self.items[item.item_code] = item

    def modify_stock(self, item_code, amount):
        if item_code in self.items:
            self.items[item_code].adjust_stock(amount)

    def include_shopper(self, shopper):
        self.shoppers[shopper.shopper_id] = shopper

    def display_items(self):
        for item in self.items.values():
            print(f"Code: {item.item_code}, Title: {item.title}, Cost: ${item.cost}, Stock: {item.stock}")

    def display_shoppers(self):
        for shopper in self.shoppers.values():
            print(f"ID: {shopper.shopper_id}, Name: {shopper.shopper_name}")

def execute():
    store = Store()

    item_a = Item(1, "Milk", 1.99, 50)
    item_b = Item(2, "Bread", 2.49, 30)

    store.include_item(item_a)
    store.include_item(item_b)

    shopper_x = Shopper(101, "Alice")
    shopper_y = Shopper(102, "Bob")

    store.include_shopper(shopper_x)
    store.include_shopper(shopper_y)

    store.modify_stock(1, 10)
    store.modify_stock(2, -2)

    print("Item List:")
    store.display_items()

    print("\nShopper List:")
    store.display_shoppers()

if __name__ == "__main__":
    execute()