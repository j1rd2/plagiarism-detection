class Gadget:
    def __init__(self, maker, name, system):
        self.maker = maker
        self.name = name
        self.system = system

    def show_details(self):
        print(f"Maker: {self.maker}, Name: {self.name}, System: {self.system}")

    def upgrade_system(self, new_system):
        self.system = new_system

def insert_gadget(gadget_list, maker, name, system):
    new_gadget = Gadget(maker, name, system)
    gadget_list.append(new_gadget)

def modify_gadget_system(gadget_list, name, new_system):
    for gadget in gadget_list:
        if gadget.name == name:
            gadget.upgrade_system(new_system)

def display_gadgets(gadget_list):
    for gadget in gadget_list:
        gadget.show_details()

def execute():
    gadget_list = []
    insert_gadget(gadget_list, "Apple", "iPhone 13", "iOS 15")
    insert_gadget(gadget_list, "Samsung", "Galaxy S21", "Android 11")
    
    print("Gadget list before system upgrade:")
    display_gadgets(gadget_list)
    
    modify_gadget_system(gadget_list, "Galaxy S21", "Android 12")
    
    print("Gadget list after system upgrade:")
    display_gadgets(gadget_list)

if __name__ == "__main__":
    execute()