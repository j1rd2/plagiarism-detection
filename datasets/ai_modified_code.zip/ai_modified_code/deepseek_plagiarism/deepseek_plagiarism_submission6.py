def organize_list(sequence):
    length = len(sequence)
    for outer in range(length):
        for inner in range(0, length - outer - 1):
            if sequence[inner] > sequence[inner + 1]:
                sequence[inner], sequence[inner + 1] = sequence[inner + 1], sequence[inner]

values = [64, 34, 25, 12, 22, 11, 90]
organize_list(values)
print("Sorted array is:", values)