class Item:
    def __init__(self, item_code, title, cost, stock):
        self.item_code = item_code
        self.title = title
        self.cost = cost
        self.stock = stock

    def adjust_stock(self, amount):
        self.stock += amount

    def adjust_cost(self, new_cost):
        self.cost = new_cost

class Store:
    def __init__(self):
        self.items = {}

    def include_item(self, item):
        self.items[item.item_code] = item

    def modify_inventory(self, item_code, amount):
        if item_code in self.items:
            self.items[item_code].adjust_stock(amount)

    def display_items(self):
        for item in self.items.values():
            print(f"Code: {item.item_code}, Title: {item.title}, Cost: ${item.cost}, Stock: {item.stock}")

def execute():
    store = Store()

    item_a = Item(1, "Milk", 1.99, 50)
    item_b = Item(2, "Bread", 2.49, 30)

    store.include_item(item_a)
    store.include_item(item_b)

    store.modify_inventory(1, 20)
    store.modify_inventory(2, -5)

    print("Inventory List:")
    store.display_items()

if __name__ == "__main__":
    execute()