class DeviceManager:
    def __init__(self, brand, model, os_version):
        self.brand = brand
        self.model = model
        self.os_version = os_version

    def display_details(self):
        print(f"Manufacturer: {self.brand}, Model: {self.model}, OS Version: {self.os_version}")

def add_device(collection, brand, model, os_version):
    new_device = DeviceManager(brand, model, os_version)
    collection.append(new_device)

def list_devices(collection):
    for device in collection:
        device.display_details()

def execute():
    collection = []
    add_device(collection, "Google", "Pixel 6", "Android 12")
    add_device(collection, "OnePlus", "9 Pro", "Android 11")
    print("Registered Smartphones:")
    list_devices(collection)

if __name__ == "__main__":
    execute()