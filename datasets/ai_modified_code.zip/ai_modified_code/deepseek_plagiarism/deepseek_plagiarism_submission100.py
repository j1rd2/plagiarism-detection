def translate_sequence(seq):
    mapping = {
        'AUG': 'M', 'UUU': 'F', 'UUC': 'F', 'UUA': 'L', 'UUG': 'L',
        'CUU': 'L', 'CUC': 'L', 'CUA': 'L', 'CUG': 'L', 'AUU': 'I',
        'AUC': 'I', 'AUA': 'I', 'GUU': 'V', 'GUC': 'V', 'GUA': 'V',
        'GUG': 'V', 'UCU': 'S', 'UCC': 'S', 'UCA': 'S', 'UCG': 'S',
        'CCU': 'P', 'CCC': 'P', 'CCA': 'P', 'CCG': 'P', 'ACU': 'T',
        'ACC': 'T', 'ACA': 'T', 'ACG': 'T', 'GCU': 'A', 'GCC': 'A',
        'GCA': 'A', 'GCG': 'A', 'UAU': 'Y', 'UAC': 'Y', 'UGU': 'C',
        'UGC': 'C', 'UGG': 'W', 'CAA': 'Q', 'CAG': 'Q', 'AAU': 'N',
        'AAC': 'N', 'AAA': 'K', 'AAG': 'K', 'GAU': 'D', 'GAC': 'D',
        'GAA': 'E', 'GAG': 'E', 'UGA': 'Stop', 'UAA': 'Stop', 'UAG': 'Stop'
    }
    
    result = ""
    for j in range(0, len(seq), 3):
        triplet = seq[j:j+3]
        result += mapping.get(triplet, '')
    return result

def execute():
    rna_input = "AUGUUUCUAUAG"
    output = translate_sequence(rna_input)
    print("Original RNA sequence:", rna_input)
    print("Translated protein sequence:", output)

if __name__ == "__main__":
    execute()