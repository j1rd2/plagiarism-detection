def compute_fibonacci_memoized(k, cache={}):
    if k in cache:
        return cache[k]
    if k <= 1:
        return k
    cache[k] = compute_fibonacci_memoized(k - 1, cache) + compute_fibonacci_memoized(k - 2, cache)
    return cache[k]

def obtain_fibonacci_series(boundary):
    series = []
    j = 0
    while True:
        current_value = compute_fibonacci_memoized(j)
        if current_value >= boundary:
            break
        series.append(current_value)
        j += 1
    return series

def show_fibonacci_series(series):
    print("The Fibonacci sequence up to the specified limit is:")
    for index, value in enumerate(series):
        print(f"Fibonacci[{index}] = {value}")

def execute():
    boundary = 100
    fib_series = obtain_fibonacci_series(boundary)
    show_fibonacci_series(fib_series)

if __name__ == "__main__":
    execute()