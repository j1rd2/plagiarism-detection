class DataEntry:
    def __init__(self, identifier, name, age, diagnosis):
        self.identifier = identifier
        self.name = name
        self.age = age
        self.diagnosis = diagnosis

class ScheduleEntry:
    def __init__(self, schedule_id, data_entry, physician, day):
        self.schedule_id = schedule_id
        self.data_entry = data_entry
        self.physician = physician
        self.day = day

class Invoice:
    def __init__(self, invoice_id, data_entry, cost):
        self.invoice_id = invoice_id
        self.data_entry = data_entry
        self.cost = cost

class ManagementSystem:
    def __init__(self):
        self.data_entries = []
        self.schedule_entries = []
        self.invoices = []

    def add_data_entry(self, entry):
        self.data_entries.append(entry)

    def add_schedule_entry(self, entry):
        self.schedule_entries.append(entry)

    def add_invoice(self, entry):
        self.invoices.append(entry)

    def display_data_entries(self):
        for entry in self.data_entries:
            print(f"ID: {entry.identifier}, Name: {entry.name}, Age: {entry.age}, Condition: {entry.diagnosis}")

    def display_schedule_entries(self):
        for entry in self.schedule_entries:
            print(f"Appointment ID: {entry.schedule_id}, Patient: {entry.data_entry.name}, Doctor: {entry.physician}, Date: {entry.day}")

    def display_invoices(self):
        for entry in self.invoices:
            print(f"Bill ID: {entry.invoice_id}, Patient: {entry.data_entry.name}, Amount: ${entry.cost}")

def execute():
    manager = ManagementSystem()

    entry_one = DataEntry(101, "Alice Green", 29, "Headache")
    entry_two = DataEntry(102, "Bob Brown", 54, "Fever")

    manager.add_data_entry(entry_one)
    manager.add_data_entry(entry_two)

    schedule_one = ScheduleEntry(1001, entry_one, "Dr. Martin", "2024-09-17")
    schedule_two = ScheduleEntry(1002, entry_two, "Dr. Lisa", "2024-09-18")

    manager.add_schedule_entry(schedule_one)
    manager.add_schedule_entry(schedule_two)

    invoice_one = Invoice(1, entry_one, 150.0)
    invoice_two = Invoice(2, entry_two, 200.0)

    manager.add_invoice(invoice_one)
    manager.add_invoice(invoice_two)

    print("Patient Records:")
    manager.display_data_entries()

    print("\nAppointment Records:")
    manager.display_schedule_entries()

    print("\nBilling Records:")
    manager.display_invoices()

if __name__ == "__main__":
    execute()