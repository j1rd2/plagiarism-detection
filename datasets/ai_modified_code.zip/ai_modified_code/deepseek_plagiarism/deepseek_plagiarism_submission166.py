class Data:
    def __init__(self, identifier, years, condition):
        self.identifier = identifier
        self.years = years
        self.condition = condition

    def display(self):
        print(f"Patient Name: {self.identifier}, Age: {self.years}, Ailment: {self.condition}")

def insert_entry(records, identifier, years, condition):
    new_entry = Data(identifier, years, condition)
    records.append(new_entry)

def show_all(records):
    for entry in records:
        entry.display()

def execute():
    records = []
    insert_entry(records, "John Doe", 45, "Flu")
    insert_entry(records, "Jane Smith", 30, "Cold")
    print("Patients currently in the hospital:")
    show_all(records)

if __name__ == "__main__":
    execute()