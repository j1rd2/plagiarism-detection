def process_data(source):
    with open(source, 'r') as file:
        values = [int(row.strip()) for row in file]
    return values

def compute_powers(data):
    result = [value ** 2 for value in data]
    return result

def store_results(processed, destination):
    with open(destination, 'w') as file:
        for item in processed:
            file.write(f"{item}\n")

def execute():
    input_path = 'input.txt'
    output_path = 'output.txt'
    original = process_data(input_path)
    transformed = compute_powers(original)
    store_results(transformed, output_path)
    print(f"Squared numbers are saved in {output_path}")

if __name__ == "__main__":
    execute()