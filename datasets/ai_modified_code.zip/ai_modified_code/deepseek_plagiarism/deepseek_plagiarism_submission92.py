class Pile:
    def __init__(self):
        self.items = []

    def add(self, element):
        self.items.append(element)

    def remove(self):
        if not self.empty():
            return self.items.pop()
        return None

    def top(self):
        if not self.empty():
            return self.items[-1]
        return None

    def empty(self):
        return len(self.items) == 0

    def length(self):
        return len(self.items)

def execute():
    pile = Pile()
    pile.add(1)
    pile.add(2)
    pile.add(3)
    print("Top item:", pile.top())
    print("Stack size:", pile.length())
    pile.remove()
    print("Stack after pop:", pile.items)

if __name__ == "__main__":
    execute()