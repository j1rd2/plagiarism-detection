class Item:
    def __init__(self, name, creator, cost):
        self.name = name
        self.creator = creator
        self.cost = cost

    def show_details(self):
        print(f"Title: {self.name}, Author: {self.creator}, Price: ${self.cost}")

def insert_item(collection, name, creator, cost):
    new_item = Item(name, creator, cost)
    collection.append(new_item)

def display_all(collection):
    for element in collection:
        element.show_details()

def execute():
    inventory = []
    insert_item(inventory, "The Catcher in the Rye", "J.D. Salinger", 10.99)
    insert_item(inventory, "To Kill a Mockingbird", "Harper Lee", 7.99)
    print("Books available in the store:")
    display_all(inventory)

if __name__ == "__main__":
    execute()