import threading
import time

def alpha_output():
    for char in "ABCDE":
        print(f"Thread 2: {char}")
        time.sleep(0.5)

def numeric_output():
    for j in range(5):
        print(f"Thread 1: {j}")
        time.sleep(1)

def execute_threads():
    first_thread = threading.Thread(target=numeric_output)
    second_thread = threading.Thread(target=alpha_output)
    
    first_thread.start()
    second_thread.start()
    
    first_thread.join()
    second_thread.join()

if __name__ == "__main__":
    execute_threads()