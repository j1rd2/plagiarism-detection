import psutil

def check_disk():
    disk_data = psutil.disk_usage('/')
    print(f"Disk Utilization: {disk_data.percent}%")

def check_memory():
    memory_data = psutil.virtual_memory()
    print(f"Memory Utilization: {memory_data.percent}%")

def check_cpu():
    cpu_data = psutil.cpu_percent(interval=1)
    print(f"CPU Utilization: {cpu_data}%")

def run_checks():
    check_cpu()
    check_memory()
    check_disk()

if __name__ == "__main__":
    run_checks()