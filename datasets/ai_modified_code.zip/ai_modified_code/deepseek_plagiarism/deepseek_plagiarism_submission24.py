class BankMachine:
    def __init__(self, starting_funds=0):
        self.funds = starting_funds

    def display_funds(self):
        print(f"Your available funds are: ${self.funds:.2f}")

    def add_funds(self, value):
        if value > 0:
            self.funds += value
            print(f"${value:.2f} has been added to your funds.")
        else:
            print("Added amount must be positive.")

    def remove_funds(self, value):
        if value > self.funds:
            print("Not enough funds for this removal.")
        elif value <= 0:
            print("Removal amount must be positive.")
        else:
            self.funds -= value
            print(f"${value:.2f} has been taken from your funds.")

    def display_options(self):
        print("\n===== Bank Machine Options =====")
        print("1. Display Funds")
        print("2. Add Funds")
        print("3. Remove Funds")
        print("4. Quit")
        print("===============================\n")

def execute():
    machine = BankMachine(100)
    while True:
        machine.display_options()
        selection = input("Choose an option (1-4): ")

        if selection == '1':
            machine.display_funds()
        elif selection == '2':
            value = float(input("Enter the amount to add: $"))
            machine.add_funds(value)
        elif selection == '3':
            value = float(input("Enter the amount to remove: $"))
            machine.remove_funds(value)
        elif selection == '4':
            print("Thank you for using the bank machine. Farewell!")
            break
        else:
            print("Invalid choice. Please choose a valid option.")

if __name__ == "__main__":
    execute()