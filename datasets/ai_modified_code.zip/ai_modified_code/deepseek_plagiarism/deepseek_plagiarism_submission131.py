class Item:
    def __init__(self, name, creator, cost, category):
        self.name = name
        self.creator = creator
        self.cost = cost
        self.category = category

    def show_details(self):
        print(f"Title: {self.name}, Author: {self.creator}, Price: ${self.cost}, Genre: {self.category}")

def insert_item(collection, name, creator, cost, category):
    new_item = Item(name, creator, cost, category)
    collection.append(new_item)

def display_collection(collection):
    for item in collection:
        item.show_details()

def execute():
    collection = []
    insert_item(collection, "The Alchemist", "Paulo Coelho", 10.49, "Fiction")
    insert_item(collection, "Sapiens", "Yuval Noah Harari", 14.99, "Non-fiction")
    print("Books available in the store with genre info:")
    display_collection(collection)

if __name__ == "__main__":
    execute()