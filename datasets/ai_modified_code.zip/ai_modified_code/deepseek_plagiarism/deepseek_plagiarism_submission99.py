def compute_gc_percentage(seq):
    total_gc = seq.count('C') + seq.count('G')
    return (total_gc / len(seq)) * 100

def execute():
    sequence = "ATGCTAGCTAGT"
    result = compute_gc_percentage(sequence)
    print("DNA sequence:", sequence)
    print("GC content (%):", result)

if __name__ == "__main__":
    execute()