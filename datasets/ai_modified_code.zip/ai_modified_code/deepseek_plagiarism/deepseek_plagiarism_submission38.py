def compute_primes(max_val):
    flags = [True] * (max_val + 1)
    flags[0], flags[1] = False, False
    for base in range(2, int(max_val ** 0.5) + 1):
        if flags[base]:
            for composite in range(base * base, max_val + 1, base):
                flags[composite] = False
    return [value for value, flag in enumerate(flags) if flag]

def execute():
    bound = 50
    primes = compute_primes(bound)
    print(f"Prime numbers up to {bound} using the Sieve of Eratosthenes: {primes}")

if __name__ == "__main__":
    execute()