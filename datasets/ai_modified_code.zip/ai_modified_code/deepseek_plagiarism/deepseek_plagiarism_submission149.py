import matplotlib.pyplot as plt
import pandas as pd

def load_csv(path):
    df = pd.read_csv(path)
    return df

def calculate_increase(df):
    df['Increase_Rate'] = df['Population'].pct_change() * 100
    return df

def plot_results(df):
    plt.figure(figsize=(10, 6))

    plt.subplot(2, 1, 1)
    plt.plot(df['Year'], df['Population'], marker='o', linestyle='-')
    plt.title('Population Trend Over Years')
    plt.xlabel('Year')
    plt.ylabel('Population')

    plt.subplot(2, 1, 2)
    plt.plot(df['Year'], df['Increase_Rate'], marker='o', linestyle='-', color='orange')
    plt.title('Yearly Growth Percentage')
    plt.xlabel('Year')
    plt.ylabel('Growth Percentage (%)')

    plt.tight_layout()
    plt.show()

def execute():
    path = "population_data.csv"
    df = load_csv(path)
    df = calculate_increase(df)
    plot_results(df)

if __name__ == "__main__":
    execute()