import openpyxl

def modify_excel_file(filepath):
    workbook = openpyxl.Workbook()
    worksheet = workbook.active
    
    worksheet['A1'] = "Employee"
    worksheet['B1'] = "Salary"
    
    worksheet['A2'] = "John"
    worksheet['B2'] = 50000
    
    worksheet['A3'] = "Jane"
    worksheet['B3'] = 55000
    
    workbook.save(filepath)
    
    workbook = openpyxl.load_workbook(filepath)
    worksheet = workbook.active
    worksheet['B2'] = 51000
    
    workbook.save(filepath)
    print(f"File '{filepath}' updated successfully!")

def execute():
    modify_excel_file("employees.xlsx")

if __name__ == "__main__":
    execute()