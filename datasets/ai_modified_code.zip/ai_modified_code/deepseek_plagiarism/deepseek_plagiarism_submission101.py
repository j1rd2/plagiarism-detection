import random

def alter_sequence(original_str, change_prob=0.01):
    bases = ['A', 'T', 'C', 'G']
    changed_list = list(original_str)
    
    for position in range(len(changed_list)):
        if random.random() < change_prob:
            changed_list[position] = random.choice(bases)
    
    return ''.join(changed_list)

def execute():
    initial_sequence = "ATGCTAGCTAGT"
    new_sequence = alter_sequence(initial_sequence, change_prob=0.05)
    print("Original DNA sequence:", initial_sequence)
    print("Mutated DNA sequence:", new_sequence)

if __name__ == "__main__":
    execute()