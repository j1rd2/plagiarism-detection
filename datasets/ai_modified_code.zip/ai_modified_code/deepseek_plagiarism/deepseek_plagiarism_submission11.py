def renamed_function(x):
    result = 1
    for j in range(x, 0, -1):
        result = result * j
    return result

print(renamed_function(5))