class Client:
    def __init__(self, client_id, full_name, funds):
        self.client_id = client_id
        self.full_name = full_name
        self.funds = funds
        self.debts = 0

    def add_funds(self, value):
        self.funds += value

    def remove_funds(self, value):
        if value <= self.funds:
            self.funds -= value
        else:
            print("Insufficient funds.")

    def request_debt(self, value):
        self.debts += value
        self.funds += value

class Institution:
    def __init__(self):
        self.clients = {}

    def register_client(self, client):
        self.clients[client.client_id] = client

    def locate_client(self, client_id):
        return self.clients.get(client_id, None)

    def display_clients(self):
        for client in self.clients.values():
            print(f"ID: {client.client_id}, Name: {client.full_name}, Balance: ${client.funds}, Loans: ${client.debts}")

def execute():
    institution = Institution()

    client_a = Client(1, "Alice", 1000)
    client_b = Client(2, "Bob", 1500)

    institution.register_client(client_a)
    institution.register_client(client_b)

    client_a.add_funds(500)
    client_b.remove_funds(200)
    client_a.request_debt(300)

    print("Customer List:")
    institution.display_clients()

if __name__ == "__main__":
    execute()