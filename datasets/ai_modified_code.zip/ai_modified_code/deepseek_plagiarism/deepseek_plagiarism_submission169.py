class PatientRecord:
    def __init__(self, name, years, diagnosis):
        self.name = name
        self.years = years
        self.diagnosis = diagnosis

    def show(self):
        print(f"Name: {self.name}, Age: {self.years}, Condition: {self.diagnosis}")

def add_patient(list_of_records, name, years, diagnosis):
    new_record = PatientRecord(name, years, diagnosis)
    list_of_records.append(new_record)

def list_all_patients(list_of_records):
    for record in list_of_records:
        record.show()

def manage_hospital():
    patient_list = []
    add_patient(patient_list, "Emily Clark", 40, "Allergies")
    add_patient(patient_list, "Frank Wells", 60, "Back Pain")
    print("Patients listed in the hospital:")
    list_all_patients(patient_list)

if __name__ == "__main__":
    manage_hospital()