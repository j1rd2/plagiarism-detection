class Clinic:
    def __init__(self):
        self.clients = {}
        self.bookings = {}

    def register_client(self, client_id, full_name, years, condition):
        self.clients[client_id] = {"FullName": full_name, "Years": years, "Condition": condition}

    def book_visit(self, booking_id, client_id, physician, day):
        if client_id in self.clients:
            self.bookings[booking_id] = {
                "Client": self.clients[client_id]["FullName"],
                "Physician": physician,
                "Day": day
            }
        else:
            print(f"No client found with ID {client_id}")

    def display_clients(self):
        for client_id, details in self.clients.items():
            print(f"ID: {client_id}, FullName: {details['FullName']}, Years: {details['Years']}, Condition: {details['Condition']}")

    def display_bookings(self):
        for booking_id, details in self.bookings.items():
            print(f"Booking ID: {booking_id}, Client: {details['Client']}, Physician: {details['Physician']}, Day: {details['Day']}")

def execute():
    clinic = Clinic()

    clinic.register_client(1, "Mark Spencer", 40, "Back Pain")
    clinic.register_client(2, "Lucy Hale", 35, "Allergy")

    clinic.book_visit(1, 1, "Dr. Green", "2024-09-20")
    clinic.book_visit(2, 2, "Dr. White", "2024-09-21")

    print("Client List:")
    clinic.display_clients()

    print("\nBooking List:")
    clinic.display_bookings()

if __name__ == "__main__":
    execute()