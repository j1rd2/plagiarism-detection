def process_data(source_path):
    with open(source_path, 'r') as file:
        values = [int(line) for line in file]
    return values

def compute_squares(data):
    return [item * item for item in data]

def store_results(data, destination_path):
    with open(destination_path, 'w') as file:
        for value in data:
            file.write(f"{value}\n")

def execute():
    input_path = 'input.txt'
    output_path = 'output.txt'
    original_data = process_data(input_path)
    transformed_data = compute_squares(original_data)
    store_results(transformed_data, output_path)
    print(f"Processed numbers are saved in {output_path}")

if __name__ == "__main__":
    execute()