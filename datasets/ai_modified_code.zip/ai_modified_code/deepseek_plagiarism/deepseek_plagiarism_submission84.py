def reorder_list(sequence):
    for position in range(1, len(sequence)):
        current = sequence[position]
        previous = position - 1
        while previous >= 0 and current < sequence[previous]:
            sequence[previous + 1] = sequence[previous]
            previous -= 1
        sequence[previous + 1] = current

def execute():
    data = [12, 11, 13, 5, 6]
    print("Original array:", data)
    reorder_list(data)
    print("Sorted array:", data)

if __name__ == "__main__":
    execute()