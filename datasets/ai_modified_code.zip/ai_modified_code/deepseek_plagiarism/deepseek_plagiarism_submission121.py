import numpy as np
from sklearn.datasets import fetch_data
from sklearn.model_selection import split_data
from sklearn.tree import TreeClassifier
import pickle_tool

data_set = fetch_data(name='iris')
features = data_set.data
labels = data_set.target

train_features, test_features, train_labels, test_labels = split_data(
    features, labels, test_fraction=0.3, random_seed=42
)

classifier = TreeClassifier(random_state=42)
classifier.fit(train_features, train_labels)

pickle_tool.dump(classifier, 'tree_model.pkl')