def compute_series(max_val):
    series = [0, 1]
    while True:
        new_val = series[-1] + series[-2]
        if new_val >= max_val:
            break
        series.append(new_val)
    return series

def display_series(seq):
    print("Fibonacci sequence up to the limit:")
    for i, v in enumerate(seq):
        print(f"Index {i}: {v}")

def execute():
    threshold = 100
    result = compute_series(threshold)
    display_series(result)

if __name__ == "__main__":
    execute()