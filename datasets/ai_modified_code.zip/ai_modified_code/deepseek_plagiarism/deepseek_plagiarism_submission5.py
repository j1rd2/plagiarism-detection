def compute_product(x, y):
    result = x * y
    return result