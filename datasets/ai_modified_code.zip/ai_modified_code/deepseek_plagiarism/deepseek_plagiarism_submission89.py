from collections import deque

def traverse_network(network, origin):
    explored = set()
    frontier = deque([origin])

    while frontier:
        node = frontier.popleft()
        if node not in explored:
            print(node, end=" ")
            explored.add(node)
            frontier.extend(network[node] - explored)

def execute():
    network = {
        'A': {'B', 'C'},
        'B': {'A', 'D', 'E'},
        'C': {'A', 'F'},
        'D': {'B'},
        'E': {'B', 'F'},
        'F': {'C', 'E'}
    }
    print("BFS starting from vertex A:")
    traverse_network(network, 'A')

if __name__ == "__main__":
    execute()