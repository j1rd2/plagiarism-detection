def process_data(sequence):
    if len(sequence) <= 1:
        return sequence
    else:
        center = sequence[0]
        left_part = [item for item in sequence[1:] if item <= center]
        right_part = [item for item in sequence[1:] if item > center]
        return process_data(left_part) + [center] + process_data(right_part)

def run_procedure():
    data = [10, 7, 8, 9, 1, 5]
    print("Initial array:", data)
    result = process_data(data)
    print("Sorted array:", result)

if __name__ == "__main__":
    run_procedure()