class Vehicle:
    def __init__(self, brand, name, production_year):
        self.brand = brand
        self.name = name
        self.production_year = production_year

    def show_details(self):
        print(f"Car Make: {self.brand}, Model: {self.name}, Year: {self.production_year}")

def insert_vehicle(garage, brand, name, production_year):
    new_vehicle = Vehicle(brand, name, production_year)
    garage.append(new_vehicle)

def display_vehicles(garage):
    for vehicle in garage:
        vehicle.show_details()

def execute():
    garage = []
    insert_vehicle(garage, "Toyota", "Corolla", 2018)
    insert_vehicle(garage, "Ford", "Mustang", 2021)

    print("Cars in the garage:")
    display_vehicles(garage)

if __name__ == "__main__":
    execute()