import sqlite3

def link_database(data_file):
    link = sqlite3.connect(data_file)
    return link

def build_staff_table(link):
    staff_table_sql = """CREATE TABLE IF NOT EXISTS employees (
                            employee_id integer PRIMARY KEY,
                            employee_name text NOT NULL,
                            employee_age integer
                         );"""
    try:
        executor = link.cursor()
        executor.execute(staff_table_sql)
    except sqlite3.Error as err:
        print(err)

def add_staff_member(link, staff_data):
    insert_command = ''' INSERT INTO employees(employee_name, employee_age)
                         VALUES(?,?) '''
    executor = link.cursor()
    executor.execute(insert_command, staff_data)
    link.commit()
    return executor.lastrowid

def fetch_all_staff(link):
    executor = link.cursor()
    executor.execute("SELECT * FROM employees")
    records = executor.fetchall()
    for record in records:
        print(record)

def execute_operations():
    data_file = "company.db"
    link = link_database(data_file)
    with link:
        build_staff_table(link)
        staff_info = ('Bob', 45)
        add_staff_member(link, staff_info)
        print("Employees in the database:")
        fetch_all_staff(link)

if __name__ == '__main__':
    execute_operations()