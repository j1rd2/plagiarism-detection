def sequence(num):
    a, b = 0, 1
    for j in range(num):
        a, b = b, a + b
    return a

output = sequence(10)
print("10th Fibonacci number:", output)