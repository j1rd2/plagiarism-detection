import pandas as pd

def load_data(path):
    data = pd.read_csv(path)
    return data

def compute_mean(dataframe):
    mean_value = dataframe['Score'].mean()
    return mean_value

def categorize_grades(dataframe, threshold):
    dataframe['Grade'] = dataframe['Score'].apply(lambda val: 'A' if val >= threshold else 'B')
    return dataframe

def export_results(dataframe, destination):
    dataframe.to_csv(destination, index=False)

def execute():
    source = 'students.csv'
    destination = 'graded_students.csv'
    loaded_data = load_data(source)
    mean_result = compute_mean(loaded_data)
    processed_data = categorize_grades(loaded_data, mean_result)
    export_results(processed_data, destination)
    print(f"Grades assigned and saved to {destination}")

if __name__ == "__main__":
    execute()