import psutil

def monitor_resources():
    cpu_load = psutil.cpu_percent(interval=1)
    print(f"CPU Usage: {cpu_load}%")
    
    ram_info = psutil.virtual_memory()
    print(f"Memory Usage: {ram_info.percent}%")
    
    storage_info = psutil.disk_usage('/')
    print(f"Disk Usage: {storage_info.percent}%")

def execute_monitoring():
    monitor_resources()

if __name__ == "__main__":
    execute_monitoring()