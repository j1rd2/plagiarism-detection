def compute_result(x):
    if x < 2:
        return 1
    else:
        return x * compute_result(x-1)

output = compute_result(5)
print(output)