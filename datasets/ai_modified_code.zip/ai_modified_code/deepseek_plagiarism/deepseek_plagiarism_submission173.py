class Vehicle:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year

    def display(self):
        print(f"Brand: {self.make}, Model: {self.model}, Year: {self.year}")

def add_vehicle(collection, make, model, year):
    new_vehicle = Vehicle(make, model, year)
    collection.append(new_vehicle)

def display_all(collection):
    for item in collection:
        item.display()

def main():
    vehicles = []
    add_vehicle(vehicles, "Tesla", "Model S", 2020)
    add_vehicle(vehicles, "Nissan", "Altima", 2019)
    print("Cars in the system:")
    display_all(vehicles)

if __name__ == "__main__":
    main()