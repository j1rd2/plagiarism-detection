items = {}
buyers = {}
transactions = []

def insert_item(item_code, title, cost, stock):
    items[item_code] = {"Title": title, "Cost": cost, "Stock": stock}

def register_buyer(buyer_code, title):
    buyers[buyer_code] = {"Title": title}

def execute_transaction(transaction_code, buyer_code, item_code, amount):
    if item_code in items and buyer_code in buyers:
        if items[item_code]["Stock"] >= amount:
            items[item_code]["Stock"] -= amount
            transactions.append({"TransactionCode": transaction_code, "BuyerCode": buyer_code, "ItemCode": item_code, "Amount": amount})
        else:
            print(f"Insufficient stock for item {item_code}")
    else:
        print("Invalid item or buyer code")

def display_items():
    for item_code, details in items.items():
        print(f"Code: {item_code}, Title: {details['Title']}, Cost: ${details['Cost']}, Stock: {details['Stock']}")

def display_buyers():
    for buyer_code, details in buyers.items():
        print(f"Code: {buyer_code}, Title: {details['Title']}")

def display_transactions():
    for transaction in transactions:
        print(f"Transaction Code: {transaction['TransactionCode']}, Buyer Code: {transaction['BuyerCode']}, Item Code: {transaction['ItemCode']}, Amount: {transaction['Amount']}")

def start():
    insert_item(1, "Eggs", 3.99, 100)
    insert_item(2, "Butter", 4.99, 50)

    register_buyer(201, "Charlie")
    register_buyer(202, "Daisy")

    execute_transaction(1, 201, 1, 12)
    execute_transaction(2, 202, 2, 5)

    print("Item List:")
    display_items()

    print("\nBuyer List:")
    display_buyers()

    print("\nTransaction List:")
    display_transactions()

if __name__ == "__main__":
    start()