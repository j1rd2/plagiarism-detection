import pickle
from sklearn.svm import SVC
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split

data = load_iris()
features = data.data
labels = data.target

train_features, test_features, train_labels, test_labels = train_test_split(features, labels, test_size=0.25, random_state=42)

classifier = SVC(kernel='linear', random_state=42)
classifier.fit(train_features, train_labels)

with open('svm_model.pkl', 'wb') as output_file:
    pickle.dump(classifier, output_file)