import random

def alter_sequence_with_log(original_seq, change_prob=0.01):
    bases = ['A', 'T', 'C', 'G']
    changed_seq = list(original_seq)
    change_log = []
    
    for position in range(len(changed_seq)):
        if random.random() < change_prob:
            original_base = changed_seq[position]
            new_base = random.choice(bases)
            changed_seq[position] = new_base
            change_log.append((position, original_base, new_base))
    
    return ''.join(changed_seq), change_log

def execute():
    initial_sequence = "ATGCTAGCTAGT"
    result_sequence, result_log = alter_sequence_with_log(initial_sequence, change_prob=0.05)
    print("Original DNA sequence:", initial_sequence)
    print("Mutated DNA sequence:", result_sequence)
    print("Mutation map:", result_log)

if __name__ == "__main__":
    execute()