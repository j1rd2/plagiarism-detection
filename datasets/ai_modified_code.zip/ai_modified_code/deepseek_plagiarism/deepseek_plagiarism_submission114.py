import sqlite3

def link_db(db_path):
    link = sqlite3.connect(db_path)
    return link

def make_table(link):
    table_sql = """CREATE TABLE IF NOT EXISTS users (
                        id integer PRIMARY KEY,
                        name text NOT NULL,
                        age integer
                   );"""
    try:
        cursor = link.cursor()
        cursor.execute(table_sql)
    except sqlite3.Error as err:
        print(err)

def add_person(link, person):
    insert_sql = ''' INSERT INTO users(name, age)
                     VALUES(?,?) '''
    cursor = link.cursor()
    cursor.execute(insert_sql, person)
    link.commit()
    return cursor.lastrowid

def remove_person(link, person_id):
    delete_sql = 'DELETE FROM users WHERE id=?'
    cursor = link.cursor()
    cursor.execute(delete_sql, (person_id,))
    link.commit()

def fetch_all_people(link):
    cursor = link.cursor()
    cursor.execute("SELECT * FROM users")
    records = cursor.fetchall()
    for record in records:
        print(record)

def execute():
    db_file = "test.db"
    connection = link_db(db_file)
    with connection:
        make_table(connection)
        person_data = ('John', 28)
        add_person(connection, person_data)
        remove_person(connection, 1)
        print("Users in the database:")
        fetch_all_people(connection)

if __name__ == '__main__':
    execute()