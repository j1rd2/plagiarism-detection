import xml.etree.ElementTree as ET

def parse_xml_books(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    result = []
    for item in root.findall('book'):
        result.append({
            'title': item.find('title').text,
            'author': item.find('author').text,
            'year': int(item.find('year').text),
            'price': float(item.find('price').text)
        })
    return result

def select_books_by_year(book_data, cutoff_year):
    return [entry for entry in book_data if entry['year'] > cutoff_year]

def compute_average_cost(book_data):
    if not book_data:
        return 0
    total_cost = sum(entry['price'] for entry in book_data)
    return total_cost / len(book_data)

def write_summary_xml(book_data, average_cost, output_path):
    summary_root = ET.Element('booksSummary')
    avg_element = ET.SubElement(summary_root, 'averagePrice')
    avg_element.text = str(average_cost)
    for entry in book_data:
        book_element = ET.SubElement(summary_root, 'book')
        ET.SubElement(book_element, 'title').text = entry['title']
        ET.SubElement(book_element, 'author').text = entry['author']
        ET.SubElement(book_element, 'year').text = str(entry['year'])
        ET.SubElement(book_element, 'price').text = str(entry['price'])
    xml_tree = ET.ElementTree(summary_root)
    xml_tree.write(output_path)

def execute():
    source_file = 'books.xml'
    target_file = 'filtered_books.xml'
    year_limit = 2000

    book_collection = parse_xml_books(source_file)
    filtered_collection = select_books_by_year(book_collection, year_limit)
    average_value = compute_average_cost(filtered_collection)
    write_summary_xml(filtered_collection, average_value, target_file)
    print(f"Filtered books written to {target_file}")

if __name__ == "__main__":
    execute()