import csv

def load_pupil_marks(filename):
    pupils = []
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            pupils.append({
                'name': row['Name'],
                'score': float(row['Score'])
            })
    return pupils

def calculate_mean(pupils):
    sum_marks = sum(p['score'] for p in pupils)
    return sum_marks / len(pupils)

def assign_marks(pupils, mean_mark):
    for p in pupils:
        if p['score'] >= mean_mark:
            p['grade'] = 'A'
        else:
            p['grade'] = 'B'
    return pupils

def write_output(pupils, outfile):
    with open(outfile, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['Name', 'Score', 'Grade'])
        writer.writeheader()
        writer.writerows(pupils)

def execute():
    source = 'students.csv'
    destination = 'graded_students.csv'
    pupil_list = load_pupil_marks(source)
    average = calculate_mean(pupil_list)
    graded = assign_marks(pupil_list, average)
    write_output(graded, destination)
    print(f"Graded data exported to {destination}")

if __name__ == "__main__":
    execute()