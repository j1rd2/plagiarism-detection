import psutil

def monitor_system():
    cpu_load = psutil.cpu_percent(interval=1)
    print(f"CPU Usage: {cpu_load}%")
    
    network_stats = psutil.net_io_counters()
    print(f"Bytes Sent: {network_stats.bytes_sent}, Bytes Received: {network_stats.bytes_recv}")

def execute():
    monitor_system()

if __name__ == "__main__":
    execute()