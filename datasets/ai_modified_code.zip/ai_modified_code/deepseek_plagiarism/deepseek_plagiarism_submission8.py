def sequence_generator(num):
    x, y = 0, 1
    for i in range(num):
        x, y = y, x + y
    return x

output = sequence_generator(10)
print("10th Fibonacci number is:", output)