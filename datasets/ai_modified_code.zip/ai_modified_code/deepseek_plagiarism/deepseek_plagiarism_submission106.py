import random

def alter_sequence(original_seq, change_prob=0.01):
    bases = ['A', 'T', 'C', 'G']
    bias = {
        'A': ['T', 'C'],
        'T': ['A', 'G'],
        'C': ['G', 'A'],
        'G': ['C', 'T']
    }
    new_seq = list(original_seq)
    
    for idx in range(len(new_seq)):
        if random.random() < change_prob:
            current = new_seq[idx]
            new_seq[idx] = random.choice(bias[current])
    
    return ''.join(new_seq)

def execute():
    sample = "ATGCTAGCTAGT"
    result = alter_sequence(sample, change_prob=0.05)
    print("Original DNA sequence:", sample)
    print("Mutated DNA sequence:", result)

if __name__ == "__main__":
    execute()