import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def create_dataset(years_count):
    years = np.arange(2000, 2000 + years_count)
    pop_vals = 300000000 + np.cumsum(np.random.normal(1000000, 500000, years_count))
    return pd.DataFrame({'Year': years, 'Population': pop_vals})

def compute_rolling_mean(df, window_size):
    return df['Population'].rolling(window=window_size).mean()

def plot_trends(df):
    plt.figure(figsize=(12, 6))
    plt.plot(df['Year'], df['Population'], label='Population')
    plt.plot(df['Year'], compute_rolling_mean(df, 5), label='5-Year Moving Avg', linestyle='--')
    plt.title('Population Trends with Moving Average')
    plt.xlabel('Year')
    plt.ylabel('Population')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    data = create_dataset(20)
    plot_trends(data)