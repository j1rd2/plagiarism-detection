from flask import Flask, jsonify

application = Flask(__name__)

@application.route('/')
def get_json():
    data = {
        'message': 'Hello, World!',
        'status': 'success'
    }
    return jsonify(data)

if __name__ == '__main__':
    application.run(debug=True)