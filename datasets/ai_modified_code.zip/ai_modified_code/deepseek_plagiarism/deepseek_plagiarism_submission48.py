def process_data(input_path, output_path):
    def fetch_values(source):
        with open(source, 'r') as src:
            for entry in src:
                yield int(entry.strip())
    
    def compute_squares(values):
        for val in values:
            yield val ** 2
    
    def store_results(results, destination):
        with open(destination, 'w') as dest:
            for res in results:
                dest.write(f"{res}\n")
    
    data_stream = fetch_values(input_path)
    squared_stream = compute_squares(data_stream)
    store_results(squared_stream, output_path)
    print(f"Squared numbers saved to {output_path}")

def execute():
    process_data('input.txt', 'output.txt')

if __name__ == "__main__":
    execute()