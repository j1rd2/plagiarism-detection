class Book:
    def __init__(self, title, author, price, genre):
        self.title = title
        self.author = author
        self.price = price
        self.genre = genre

    def display_info(self):
        print(f"Name: {self.title}, Writer: {self.author}, Cost: ${self.price}, Category: {self.genre}")

def add_book(library, title, author, price, genre):
    new_book = Book(title, author, price, genre)
    library.append(new_book)

def list_books(library):
    for book in library:
        book.display_info()

def manage_library():
    library = []
    add_book(library, "The Alchemist", "Paulo Coelho", 10.49, "Fiction")
    add_book(library, "Sapiens", "Yuval Noah Harari", 14.99, "Non-fiction")
    print("Novels available in the collection with category info:")
    list_books(library)

if __name__ == "__main__":
    manage_library()