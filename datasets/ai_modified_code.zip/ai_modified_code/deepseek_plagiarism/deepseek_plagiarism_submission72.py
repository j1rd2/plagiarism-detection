records = {}
sessions = {}
employees = {}
invoices = {}

def register_patient(pid, pname, page, pcondition):
    records[pid] = {"PatientName": pname, "PatientAge": page, "Condition": pcondition}

def book_session(sid, pid, physician, day):
    if pid in records:
        sessions[sid] = {
            "Client": records[pid]["PatientName"],
            "Physician": physician,
            "Day": day
        }

def hire_employee(eid, ename, position):
    employees[eid] = {"EmployeeName": ename, "Position": position}

def create_invoice(iid, pid, total, deadline):
    if pid in records:
        invoices[iid] = {
            "Client": records[pid]["PatientName"],
            "Total": total,
            "Deadline": deadline
        }

def display_patients():
    for pid, data in records.items():
        print(f"PID: {pid}, Name: {data['PatientName']}, Age: {data['PatientAge']}, Condition: {data['Condition']}")

def display_sessions():
    for sid, data in sessions.items():
        print(f"SID: {sid}, Client: {data['Client']}, Physician: {data['Physician']}, Day: {data['Day']}")

def display_employees():
    for eid, data in employees.items():
        print(f"EID: {eid}, Name: {data['EmployeeName']}, Position: {data['Position']}")

def display_invoices():
    for iid, data in invoices.items():
        print(f"IID: {iid}, Client: {data['Client']}, Total: ${data['Total']}, Deadline: {data['Deadline']}")

def execute():
    register_patient(1, "Robert Downey", 55, "Arthritis")
    register_patient(2, "Scarlett Johansson", 35, "Asthma")

    book_session(1, 1, "Dr. Strange", "2024-10-15")
    book_session(2, 2, "Dr. Banner", "2024-10-20")

    hire_employee(1, "Tony Stark", "Chief Surgeon")
    hire_employee(2, "Natasha Romanoff", "Head Nurse")

    create_invoice(1, 1, 1000.0, "2024-10-25")
    create_invoice(2, 2, 1500.0, "2024-10-30")

    print("Patients:")
    display_patients()

    print("\nSessions:")
    display_sessions()

    print("\nEmployees:")
    display_employees()

    print("\nInvoices:")
    display_invoices()

if __name__ == "__main__":
    execute()