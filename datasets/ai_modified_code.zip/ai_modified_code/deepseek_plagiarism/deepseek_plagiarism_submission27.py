import pandas as pd
import matplotlib.pyplot as plt

def load_file(file_path):
    df = pd.read_csv(file_path)
    return df

def calculate_increase(df):
    df['IncreasePercent'] = df['Population'].pct_change() * 100
    return df

def generate_charts(df):
    plt.figure(figsize=(10, 6))

    plt.subplot(2, 1, 1)
    plt.plot(df['Year'], df['Population'], marker='o', linestyle='-')
    plt.title('Yearly Population')
    plt.xlabel('Year')
    plt.ylabel('Population')

    plt.subplot(2, 1, 2)
    plt.plot(df['Year'], df['IncreasePercent'], marker='o', linestyle='-', color='orange')
    plt.title('Yearly Population Growth Rate')
    plt.xlabel('Year')
    plt.ylabel('Growth Rate (%)')

    plt.tight_layout()
    plt.show()

def execute():
    file_name = "population_data.csv"
    df = load_file(file_name)
    df = calculate_increase(df)
    generate_charts(df)

if __name__ == "__main__":
    execute()