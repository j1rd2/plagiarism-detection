import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def generate_yearly_info(num_years):
    year_list = np.arange(2000, 2000 + num_years)
    pop_values = 300000000 + np.cumsum(np.random.normal(1000000, 500000, num_years))
    return pd.DataFrame({'Year': year_list, 'Population': pop_values})

def compute_rolling_mean(df, window):
    return df['Population'].rolling(window=window).mean()

def visualize_trends(df):
    plt.figure(figsize=(12, 6))
    plt.plot(df['Year'], df['Population'], label='Population')
    plt.plot(df['Year'], compute_rolling_mean(df, 5), label='5-Year Moving Avg', linestyle='--')
    plt.title('Population Growth with Moving Average')
    plt.xlabel('Year')
    plt.ylabel('Population')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    data_frame = generate_yearly_info(20)
    visualize_trends(data_frame)