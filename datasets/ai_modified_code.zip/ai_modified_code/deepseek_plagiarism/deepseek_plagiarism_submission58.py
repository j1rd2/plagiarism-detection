import json

def load_staff_records(file_name):
    with open(file_name, 'r') as f:
        data = json.load(f)
    return data['employees']

def select_by_section(staff, section):
    return [person for person in staff if person['department'] == section]

def calculate_mean_pay(staff):
    if not staff:
        return 0
    sum_pay = sum(person['salary'] for person in staff)
    return sum_pay / len(staff)

def save_summary_to_file(summary, result_file):
    with open(result_file, 'w') as f:
        json.dump(summary, f, indent=4)

def execute():
    source_file = 'employees.json'
    destination_file = 'department_summary.json'
    target_section = 'Engineering'

    staff_list = load_staff_records(source_file)
    section_staff = select_by_section(staff_list, target_section)
    mean_pay = calculate_mean_pay(section_staff)
    report = {
        'department': target_section,
        'average_salary': mean_pay,
        'employee_count': len(section_staff)
    }

    save_summary_to_file(report, destination_file)
    print(f"Data written to {destination_file}")

if __name__ == "__main__":
    execute()