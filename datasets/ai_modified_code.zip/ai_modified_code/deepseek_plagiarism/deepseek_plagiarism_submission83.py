def reorder_sort(data):
    size = len(data)
    for start in range(size):
        smallest = start
        for compare in range(start+1, size):
            if data[compare] < data[smallest]:
                smallest = compare
        data[start], data[smallest] = data[smallest], data[start]

def execute():
    numbers = [29, 10, 14, 37, 13]
    print("Original array:", numbers)
    reorder_sort(numbers)
    print("Sorted array:", numbers)

if __name__ == "__main__":
    execute()