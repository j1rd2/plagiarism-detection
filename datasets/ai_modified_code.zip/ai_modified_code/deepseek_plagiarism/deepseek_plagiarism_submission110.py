from flask import Flask

application = Flask(__name__)

@application.route('/')
def greeting():
    return 'Hello, World!'

@application.route('/about')
def info():
    return 'This is the About page.'

if __name__ == '__main__':
    application.run(debug=True)