import json

def load_staff_records(path_to_file):
    with open(path_to_file, 'r') as f:
        content = json.load(f)
    return content['employees']

def select_staff_by_unit(staff_list, unit):
    return [person for person in staff_list if person['department'] == unit]

def compute_mean_income(personnel):
    total_income = sum(member['salary'] for member in personnel)
    return total_income / len(personnel) if personnel else 0

def write_output_to_file(output_data, destination_file):
    with open(destination_file, 'w') as f:
        json.dump(output_data, f, indent=4)

def execute():
    source_file = 'employees.json'
    result_file = 'department_summary.json'
    target_unit = 'Engineering'

    staff = load_staff_records(source_file)
    selected_staff = select_staff_by_unit(staff, target_unit)
    mean_income = compute_mean_income(selected_staff)
    summary = {
        'department': target_unit,
        'average_salary': mean_income,
        'employee_count': len(selected_staff)
    }

    write_output_to_file(summary, result_file)
    print(f"Results saved to {result_file}")

if __name__ == "__main__":
    execute()