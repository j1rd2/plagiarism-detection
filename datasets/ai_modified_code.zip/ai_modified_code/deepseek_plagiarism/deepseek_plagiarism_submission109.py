from flask import Flask

web = Flask(__name__)

@web.route('/')
def display_message():
    return '<h1 style="color:blue;">Hello, World!</h1>'

if __name__ == '__main__':
    web.run(debug=True)