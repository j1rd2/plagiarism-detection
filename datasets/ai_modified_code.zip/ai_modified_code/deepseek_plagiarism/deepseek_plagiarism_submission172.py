class Vehicle:
    def __init__(self, maker, model, year):
        self.maker = maker
        self.model = model
        self.year = year

    def show_details(self):
        print(f"Manufacturer: {self.maker}, Model: {self.model}, Year: {self.year}")

def insert_vehicle(collection, maker, model, year):
    new_vehicle = Vehicle(maker, model, year)
    collection.append(new_vehicle)

def list_vehicles(collection):
    for item in collection:
        item.show_details()

def manage_vehicles():
    vehicle_list = []
    insert_vehicle(vehicle_list, "BMW", "X5", 2017)
    insert_vehicle(vehicle_list, "Audi", "A4", 2022)

    print("Automobiles in the showroom:")
    list_vehicles(vehicle_list)

if __name__ == "__main__":
    manage_vehicles()