class VehicleRecord:
    def __init__(self, brand, model, year):
        self.brand = brand
        self.model = model
        self.year = year

    def display(self):
        print(f"Make: {self.brand}, Version: {self.model}, Year: {self.year}")

def add_vehicle(collection, brand, model, year):
    new_vehicle = VehicleRecord(brand, model, year)
    collection.append(new_vehicle)

def show_vehicles(collection):
    for vehicle in collection:
        vehicle.display()

def run_registry():
    registry = []
    add_vehicle(registry, "Mercedes", "C-Class", 2016)
    add_vehicle(registry, "Volvo", "XC90", 2018)
    print("Cars in the registry:")
    show_vehicles(registry)

if __name__ == "__main__":
    run_registry()