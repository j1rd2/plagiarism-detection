class TreeNode:
    def __init__(self, value):
        self.l = None
        self.r = None
        self.data = value

def add_node(tree, value):
    if tree is None:
        return TreeNode(value)
    else:
        if tree.data < value:
            tree.r = add_node(tree.r, value)
        else:
            tree.l = add_node(tree.l, value)
    return tree

def traverse_inorder(tree):
    if tree:
        traverse_inorder(tree.l)
        print(tree.data, end=" ")
        traverse_inorder(tree.r)

def execute():
    t = TreeNode(50)
    t = add_node(t, 30)
    t = add_node(t, 20)
    t = add_node(t, 40)
    t = add_node(t, 70)
    t = add_node(t, 60)
    t = add_node(t, 80)
    print("Inorder traversal of BST:")
    traverse_inorder(t)

if __name__ == "__main__":
    execute()