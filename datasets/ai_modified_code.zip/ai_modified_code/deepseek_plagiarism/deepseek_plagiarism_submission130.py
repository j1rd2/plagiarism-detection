class LibraryItem:
    def __init__(self, name, writer, cost):
        self.name = name
        self.writer = writer
        self.cost = cost

    def show_details(self):
        print(f"Title: {self.name}, Author: {self.writer}, Price: ${self.cost}")

    def change_cost(self, updated_cost):
        self.cost = updated_cost

def insert_item(collection, name, writer, cost):
    item = LibraryItem(name, writer, cost)
    collection.append(item)

def modify_item_cost(collection, name, updated_cost):
    for item in collection:
        if item.name == name:
            item.change_cost(updated_cost)

def display_collection(collection):
    for item in collection:
        item.show_details()

def execute():
    collection = []
    insert_item(collection, "War and Peace", "Leo Tolstoy", 12.99)
    insert_item(collection, "The Hobbit", "J.R.R. Tolkien", 9.99)
    
    print("Books available before price update:")
    display_collection(collection)
    
    modify_item_cost(collection, "The Hobbit", 7.99)
    
    print("\nBooks available after price update:")
    display_collection(collection)

if __name__ == "__main__":
    execute()