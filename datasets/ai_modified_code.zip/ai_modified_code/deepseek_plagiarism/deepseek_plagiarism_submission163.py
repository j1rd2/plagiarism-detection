class University:
    def __init__(self, university_name):
        self.university_name = university_name
        self.departments = []

    def include_department(self, department):
        self.departments.append(department)

    def display_departments(self):
        print(f"Departments in {self.university_name}:")
        for department in self.departments:
            print(f"-- {department}")


def run():
    university = University("Stanford College")
    university.include_department("Computer Engineering")
    university.include_department("Biology")
    university.include_department("History")

    university.display_departments()


if __name__ == "__main__":
    run()