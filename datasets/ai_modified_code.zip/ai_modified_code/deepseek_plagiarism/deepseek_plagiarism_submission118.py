import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split

data = load_iris()
features = data.data
labels = data.target

X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.25, random_state=42)

classifier = RandomForestClassifier(n_estimators=100, random_state=42)
classifier.fit(X_train, y_train)

with open('rf_model.pkl', 'wb') as f:
    pickle.dump(classifier, f)