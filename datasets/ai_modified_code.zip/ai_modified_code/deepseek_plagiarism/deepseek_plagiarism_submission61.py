import xml.etree.ElementTree as ET

def parse_xml_data(file_name):
    xml_tree = ET.parse(file_name)
    xml_root = xml_tree.getroot()
    data_list = []
    for item in xml_root.findall('book'):
        data_list.append({
            'title': item.find('title').text,
            'author': item.find('author').text,
            'year': int(item.find('year').text),
            'price': float(item.find('price').text)
        })
    return data_list

def select_by_year(data, threshold):
    return [entry for entry in data if entry['year'] > threshold]

def compute_mean_cost(items):
    if not items:
        return 0
    total = sum(entry['price'] for entry in items)
    return total / len(items)

def generate_output_xml(entries, mean_value, result_file):
    top = ET.Element('bookSummary')
    mean_elem = ET.SubElement(top, 'averagePrice')
    mean_elem.text = str(mean_value)
    for entry in entries:
        book_node = ET.SubElement(top, 'book')
        title_node = ET.SubElement(book_node, 'title')
        title_node.text = entry['title']
        author_node = ET.SubElement(book_node, 'author')
        author_node.text = entry['author']
        year_node = ET.SubElement(book_node, 'year')
        year_node.text = str(entry['year'])
        price_node = ET.SubElement(book_node, 'price')
        price_node.text = str(entry['price'])
    doc = ET.ElementTree(top)
    doc.write(result_file)

def execute():
    source = 'books.xml'
    destination = 'filtered_books.xml'
    cutoff = 2000

    collection = parse_xml_data(source)
    filtered = select_by_year(collection, cutoff)
    average = compute_mean_cost(filtered)
    generate_output_xml(filtered, average, destination)
    print(f"Processed books saved to {destination}")

if __name__ == "__main__":
    execute()