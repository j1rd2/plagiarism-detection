import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
import joblib

def load_dataset():
    from sklearn.datasets import load_iris
    data = load_iris()
    return data.data, data.target

def train_model(features, labels):
    classifier = LogisticRegression(max_iter=200, random_state=42)
    classifier.fit(features, labels)
    return classifier

def save_model(trained_model, filename):
    joblib.dump(trained_model, filename)

def main():
    X, y = load_dataset()
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    trained_classifier = train_model(X_train, y_train)
    save_model(trained_classifier, 'logistic_regression_model.pkl')

if __name__ == "__main__":
    main()