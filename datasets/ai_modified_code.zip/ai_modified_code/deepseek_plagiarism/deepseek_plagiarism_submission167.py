class HospitalSystem:
    def __init__(self, name, years, condition):
        self.name = name
        self.years = years
        self.condition = condition

    def show_info(self):
        print(f"Full Name: {self.name}, Age: {self.years}, Illness: {self.condition}")

def add_entry(records, name, years, condition):
    entry = HospitalSystem(name, years, condition)
    records.append(entry)

def display_records(records):
    for entry in records:
        entry.show_info()

def execute_system():
    records = []
    add_entry(records, "Alice Brown", 50, "Headache")
    add_entry(records, "Bob Johnson", 62, "Fever")
    print("Registered patients in the hospital:")
    display_records(records)

if __name__ == "__main__":
    execute_system()