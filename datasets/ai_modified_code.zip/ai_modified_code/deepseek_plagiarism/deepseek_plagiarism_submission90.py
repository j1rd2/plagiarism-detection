def traverse(graph, node, seen=None):
    if seen is None:
        seen = set()
    seen.add(node)
    print(node, end=" ")

    for neighbor in graph[node] - seen:
        traverse(graph, neighbor, seen)

def execute():
    graph = {
        'A': {'B', 'C'},
        'B': {'A', 'D', 'E'},
        'C': {'A', 'F'},
        'D': {'B'},
        'E': {'B', 'F'},
        'F': {'C', 'E'}
    }
    print("DFS starting from vertex A:")
    traverse(graph, 'A')

if __name__ == "__main__":
    execute()