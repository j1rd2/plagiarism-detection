class Client:
    def __init__(self, client_id, full_name, funds):
        self.client_id = client_id
        self.full_name = full_name
        self.funds = funds
        self.debts = 0

    def add_funds(self, value):
        self.funds += value

    def remove_funds(self, value):
        if value <= self.funds:
            self.funds -= value
        else:
            print("Insufficient funds.")

    def request_loan(self, value):
        self.debts += value
        self.funds += value

class Employee:
    def __init__(self, employee_id, full_name, role):
        self.employee_id = employee_id
        self.full_name = full_name
        self.role = role

class FinancialInstitution:
    def __init__(self):
        self.clients = {}
        self.employees = {}

    def register_client(self, client):
        self.clients[client.client_id] = client

    def register_employee(self, employee):
        self.employees[employee.employee_id] = employee

    def display_clients(self):
        for client in self.clients.values():
            print(f"ID: {client.client_id}, Name: {client.full_name}, Balance: ${client.funds}, Loans: ${client.debts}")

    def display_employees(self):
        for employee in self.employees.values():
            print(f"ID: {employee.employee_id}, Name: {employee.full_name}, Position: {employee.role}")

def execute():
    institution = FinancialInstitution()

    client_a = Client(1, "Michael", 5000)
    client_b = Client(2, "Sarah", 6000)

    institution.register_client(client_a)
    institution.register_client(client_b)

    employee_x = Employee(201, "David", "Manager")
    employee_y = Employee(202, "Emma", "Clerk")

    institution.register_employee(employee_x)
    institution.register_employee(employee_y)

    client_a.request_loan(1000)

    print("Customer List:")
    institution.display_clients()

    print("\nStaff List:")
    institution.display_employees()

if __name__ == "__main__":
    execute()