import random

def alter_sequence_with_count(original_seq, change_chance=0.02):
    nucleotides = ['A', 'T', 'C', 'G']
    seq_list = list(original_seq)
    changes_made = 0
    
    for position in range(len(seq_list)):
        if random.random() < change_chance:
            seq_list[position] = random.choice(nucleotides)
            changes_made += 1
    
    new_sequence = ''.join(seq_list)
    print(f"Total mutations: {changes_made}")
    return new_sequence

def execute():
    initial_seq = "ATGCTAGCTAGT"
    changed_seq = alter_sequence_with_count(initial_seq, change_chance=0.05)
    print("Original DNA sequence:", initial_seq)
    print("Mutated DNA sequence:", changed_seq)

if __name__ == "__main__":
    execute()