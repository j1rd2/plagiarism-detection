class Gadget:
    def __init__(self, maker, type, system):
        self.maker = maker
        self.type = type
        self.system = system

    def show_details(self):
        print(f"Maker: {self.maker}, Type: {self.type}, System: {self.system}")

def insert_gadget(collection, maker, type, system):
    new_gadget = Gadget(maker, type, system)
    collection.append(new_gadget)

def display_collection(collection):
    for item in collection:
        item.show_details()

def execute():
    collection = []
    insert_gadget(collection, "Apple", "iPhone 13", "iOS 15")
    insert_gadget(collection, "Samsung", "Galaxy S21", "Android 11")
    print("Collection of gadgets:")
    display_collection(collection)

if __name__ == "__main__":
    execute()